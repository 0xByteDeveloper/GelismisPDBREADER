# PDBScope — PDB/MAP/PE sembol ve RVA analiz aracı
# CMake derleme betiği (VS2019, MinGW, Linux derlemeleri için ortak)
#
#   cmake -B build && cmake --build build --config Release
#   (VS2019: cmake -B build -G "Visual Studio 16 2019" -A x64)

cmake_minimum_required(VERSION 3.15)
project(PDBScope CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)

if(MSVC)
    add_compile_options(/utf-8 /W4 /permissive-)
    add_compile_definitions(_CRT_SECURE_NO_WARNINGS _WIN32_WINNT=0x0601)
else()
    add_compile_options(-Wall -Wextra)
    if(WIN32)
        add_compile_definitions(_WIN32_WINNT=0x0601)
        # tam statik tek dosya exe
        add_link_options(-static -static-libgcc -static-libstdc++)
    endif()
endif()

add_executable(pdbscope
    src/cvconst.h
    src/demangle.h src/demangle.cpp
    src/lines.h src/lines.cpp
    src/main.cpp
    src/mapfile.h src/mapfile.cpp
    src/msf.h src/msf.cpp
    src/output.h src/output.cpp
    src/pdb.h src/pdb.cpp
    src/pdbless.h src/pdbless.cpp
    src/pe.h src/pe.cpp
    src/types.h src/types.cpp
    src/util.h src/util.cpp
)

if(WIN32 AND NOT MSVC)
    set_target_properties(pdbscope PROPERTIES LINK_FLAGS "-Wl,--subsystem,console")
endif()

# kurulum (opsiyonel)
include(GNUInstallDirs)
install(TARGETS pdbscope RUNTIME DESTINATION ${CMAKE_INSTALL_BINDIR})
