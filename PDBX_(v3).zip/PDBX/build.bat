; PDBX - Visual Studio ile derleme (x86 konsol)
; Kullanim: VS Developer Command Prompt acip "build.bat" calistirin
@echo off
cd /d "%~dp0"
if not exist src (
    echo src klasoru bulunamadi!
    pause
    exit /b 1
)
cl /nologo /O2 /EHsc /std:c++17 /W3 /Fe:pdbx_win32.exe src\*.cpp ws2_32.lib
if errorlevel 1 (
    echo Derleme HATASI
    pause
    exit /b 1
)
echo OK: pdbx_win32.exe hazir
