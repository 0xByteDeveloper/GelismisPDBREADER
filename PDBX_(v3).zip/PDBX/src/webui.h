// PDBX gomulu web arayuzu (tek sayfa HTML) - pdbx_server.cpp sunar
#pragma once

static const char WEBUI_HTML[] = R"WEBUI(<!doctype html>
<html lang="tr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>PDBX Web - Metin2 Offset Viewer</title>
<style>
:root{
  --bg:#f4f2fb; --card:#ffffff; --ink:#1d1a2e; --mut:#6f6a8a; --line:#e4e0f2;
  --pur:#7c3aed; --pur2:#5b21b6; --purSoft:#ede9fe; --ok:#059669;
  --codeBg:#14161d; --codeInk:#c8d0dc; --ad:#5d6779; --cm:#6b7280;
  --mn:#61afef; --fn:#c678dd; --str:#98c379; --num:#d19a66; --lbl:#e5c07b; --var:#56b6c2;
}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--ink);font:14px/1.45 "Segoe UI",system-ui,Arial,sans-serif}
button{font:inherit;cursor:pointer}
input{font:inherit}
.screen{min-height:100vh}
.banner{background:linear-gradient(135deg,#7c3aed 0%,#4c1d95 60%,#312e81 100%);color:#fff;padding:22px 26px;display:flex;gap:14px;align-items:center;box-shadow:0 4px 18px rgba(76,29,149,.25)}
.banner .logo{width:44px;height:44px;border-radius:12px;background:rgba(255,255,255,.14);display:flex;align-items:center;justify-content:center;flex:none}
.banner h1{margin:0;font-size:21px;letter-spacing:.2px}
.banner .sub{opacity:.85;font-size:12.5px;margin-top:3px}
.wrap{max-width:1080px;margin:0 auto;padding:0 18px 60px}
.stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(120px,1fr));gap:10px;margin:-2px 0 14px}
.scard{background:var(--card);border:1px solid var(--line);border-radius:12px;padding:12px 14px;cursor:pointer;transition:.15s}
.scard:hover{border-color:var(--pur);transform:translateY(-1px)}
.scard b{display:block;font-size:20px;color:var(--pur2)}
.scard span{font-size:11.5px;color:var(--mut)}
.searchrow{margin:6px 0 10px;position:relative}
.searchrow svg{position:absolute;left:12px;top:11px;opacity:.45}
#q{width:100%;padding:11px 14px 11px 38px;border:1.5px solid var(--line);border-radius:12px;background:var(--card);outline:none;font-size:14px}
#q:focus{border-color:var(--pur)}
.tabs{display:flex;flex-wrap:wrap;gap:8px;margin-bottom:12px}
.tab{padding:7px 14px;border-radius:999px;border:1.5px solid var(--line);background:var(--card);color:var(--mut);font-size:13px}
.tab.on{background:var(--pur);border-color:var(--pur);color:#fff;font-weight:600}
#list{display:flex;flex-direction:column;gap:7px}
.row{display:flex;align-items:center;gap:11px;background:var(--card);border:1px solid var(--line);border-radius:11px;padding:9px 12px;cursor:pointer;transition:.12s}
.row:hover{border-color:var(--pur);box-shadow:0 2px 10px rgba(124,58,237,.10)}
.chip{width:30px;height:30px;border-radius:9px;flex:none;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:12px;color:#fff}
.chip.func{background:#7c3aed}.chip.class{background:#0ea5e9}.chip.struct{background:#059669}
.chip.enum{background:#d97706}.chip.static{background:#64748b}.chip.string{background:#db2777}
.chip.xref{background:#4f46e5}.chip.ins{background:#0d9488}.chip.union{background:#334155}
.rmain{flex:1;min-width:0}
.rname{font-weight:600;font-size:13.5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-family:Consolas,monospace}
.rsub{font-size:11.5px;color:var(--mut);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-family:Consolas,monospace}
.badge{flex:none;font-size:11px;padding:3px 9px;border-radius:999px;background:var(--purSoft);color:var(--pur2);font-weight:600}
.copy{flex:none;font-size:11.5px;padding:5px 10px;border-radius:8px;border:1px solid #b7e0c8;background:#ecfdf5;color:var(--ok);font-weight:600}
.copy:hover{background:#d1fae5}
#more{display:block;margin:14px auto;padding:9px 22px;border-radius:10px;border:1.5px solid var(--line);background:var(--card);color:var(--pur2);font-weight:600}
#more:disabled{opacity:.4;cursor:default}
#neterr{display:none;background:#7f1d1d;color:#fff;text-align:center;padding:8px;font-size:13px}
/* ---- disassembly ekrani ---- */
#dis{display:none;flex-direction:column;height:100vh;background:#0e1015}
.dbar{display:flex;align-items:center;gap:12px;padding:8px 12px;background:#191c25;border-bottom:1px solid #262b38;color:#c8d0dc}
.dbar button{background:#242938;border:1px solid #333a4d;color:#c8d0dc;border-radius:8px;padding:6px 12px;font-size:12.5px;white-space:nowrap}
.dbar button:hover{border-color:#7c3aed;color:#fff}
#dname{font-weight:700;color:#e6d7ff;font-size:13.5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
#dmeta{font-size:11.5px;color:#8b93a7;font-family:Consolas,monospace;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.dwrap{flex:1;display:flex;min-height:0}
aside{width:300px;flex:none;background:#12141b;border-right:1px solid #232838;display:flex;flex-direction:column}
#flist{flex:1;overflow-y:auto;padding:6px}
.fitem{padding:5px 9px;border-radius:7px;cursor:pointer;color:#aab2c5;font-size:12px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.fitem .fva{color:#5d6779;font-family:Consolas,monospace;font-size:10.5px;margin-right:6px}
.fitem:hover{background:#1d2230;color:#fff}
.fitem.on{background:#2b2350;color:#e6d7ff}
.fsearch{flex:none;padding:8px;border-top:1px solid #232838}
.fsearch input{width:100%;background:#0e1015;border:1px solid #2b3143;border-radius:8px;color:#c8d0dc;padding:7px 10px;outline:none;font-size:12.5px}
.fsearch input:focus{border-color:#7c3aed}
#code{flex:1;overflow:auto;padding:10px 0 40vh;font:12.5px/1.5 Consolas,"Courier New",monospace;color:var(--codeInk)}
.ln{white-space:pre;padding:0 18px;min-height:19px}
.ln:hover{background:#171a23}
.ln.flash{animation:fl 1.6s ease-out}
@keyframes fl{0%{background:#3b2f63}100%{background:transparent}}
.ad{color:var(--ad)}
.mn{color:var(--mn)}
.fn{color:var(--fn);cursor:pointer}
.fn:hover{color:#e0a8ff;text-decoration:underline}
.loc{color:var(--lbl);cursor:pointer}
.loc:hover{color:#ffe9a8;text-decoration:underline}
.strl{color:var(--str)}
.strq{color:var(--str)}
.num{color:var(--num)}
.cm{color:var(--cm);font-style:italic}
.xrn{color:#79b8ff;cursor:pointer}
.xrn:hover{color:#a5d0ff;text-decoration:underline}
.ths{color:#ff9d5c;font-style:italic}
.mem{color:#7fd1e8}
.udtl{color:var(--var);cursor:pointer}
.udtl:hover{color:#8be9f5;text-decoration:underline}
.proc{color:#e6d7ff;font-weight:700}
.dim{color:#5d6779}
/* ---- modallar ---- */
.modal-bg{display:none;position:fixed;inset:0;background:rgba(10,8,20,.55);z-index:50;align-items:center;justify-content:center;padding:20px}
.modal{background:var(--card);border-radius:14px;max-width:760px;width:100%;max-height:82vh;display:flex;flex-direction:column;overflow:hidden;box-shadow:0 20px 60px rgba(20,10,60,.35)}
.mhead{display:flex;align-items:center;gap:10px;padding:14px 18px;border-bottom:1px solid var(--line)}
.mhead b{font-size:15px;font-family:Consolas,monospace}
.mhead .mx{margin-left:auto;background:none;border:none;font-size:20px;color:var(--mut)}
.mbody{padding:6px 18px 18px;overflow:auto}
table.mem{width:100%;border-collapse:collapse;font-size:12.5px}
table.mem td,table.mem th{padding:6px 8px;border-bottom:1px solid var(--line);text-align:left}
table.mem th{color:var(--mut);font-size:11px;text-transform:uppercase;letter-spacing:.5px}
td.off{font-family:Consolas,monospace;color:var(--pur2);white-space:nowrap}
td.tp{font-family:Consolas,monospace;color:#0f766e}
td.tp .udtl2{color:var(--pur2);cursor:pointer;text-decoration:underline}
td.tp .udtl2:hover{color:var(--pur)}
.gotoBox{background:#191c25;border:1px solid #333a4d;border-radius:12px;padding:16px;width:420px;max-width:92vw;color:#c8d0dc}
.gotoBox input{width:100%;margin-top:10px;background:#0e1015;border:1px solid #2b3143;border-radius:8px;color:#fff;padding:9px 12px;outline:none;font-size:14px;font-family:Consolas,monospace}
.gotoBox input:focus{border-color:#7c3aed}
.gotoBox .hint{font-size:11.5px;color:#6f7890;margin-top:8px}
.mtag{font-size:11px;padding:3px 9px;border-radius:999px;background:var(--purSoft);color:var(--pur2);font-weight:600}
.kv{font-size:13px;margin:4px 0}
.kv b{font-family:Consolas,monospace;color:var(--pur2)}
.msec{margin-top:14px;font-weight:700;font-size:12px;color:var(--mut);text-transform:uppercase;letter-spacing:.6px}
.meth{display:inline-block;margin:3px 6px 3px 0;padding:4px 10px;background:#f5f3ff;border:1px solid var(--line);border-radius:8px;font-size:12px;cursor:pointer;font-family:Consolas,monospace}
.meth:hover{border-color:var(--pur);color:var(--pur2)}
</style>
</head>
<body>
<div id="neterr">Sunucu baglantisi koptu - pdbx_win32.exe ... serve komutunun calistigindan emin olun</div>

<div id="home" class="screen">
  <div class="banner">
    <div class="logo">
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.2" stroke-linecap="round">
        <circle cx="10.5" cy="10.5" r="6.5"/><path d="M15.5 15.5 L21 21"/>
      </svg>
    </div>
    <div>
      <h1>PDBX Web &mdash; Metin2 Offset Viewer</h1>
      <div class="sub" id="hsub">PDB analizi yukleniyor...</div>
    </div>
  </div>
  <div class="wrap">
    <div class="stats" id="stats"></div>
    <div class="searchrow">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#1d1a2e" stroke-width="2.4" stroke-linecap="round"><circle cx="10.5" cy="10.5" r="6.5"/><path d="M15.5 15.5 L21 21"/></svg>
      <input id="q" placeholder="Ara: CInstanceBase, SendAttackPacket, command_attack, m_dwLevel, aSendBattle..." autocomplete="off">
    </div>
    <div class="tabs" id="tabs"></div>
    <div id="list"></div>
    <button id="more">Daha fazla goster</button>
  </div>
</div>

<div id="dis" class="screen">
  <div class="dbar">
    <button id="back">&#8592; Ana Ekran</button>
    <div style="min-width:0;flex:1">
      <div id="dname">-</div>
      <div id="dmeta"></div>
    </div>
    <button id="gotobtn">Ctrl+G &mdash; Adrese Git</button>
  </div>
  <div class="dwrap">
    <aside>
      <div id="flist"></div>
      <div class="fsearch"><input id="fq" placeholder="fonksiyon ara... (en altta)" autocomplete="off"></div>
    </aside>
    <div id="code"></div>
  </div>
</div>

<div id="modal" class="modal-bg"><div class="modal">
  <div class="mhead"><b id="mtitle">-</b><span class="mtag" id="mtag"></span><button class="mx" onclick="closeModal()">&times;</button></div>
  <div class="mbody" id="mbody"></div>
</div></div>

<div id="goto" class="modal-bg"><div class="gotoBox">
  <b>Adrese git</b>
  <input id="gotoInput" placeholder="0x4D7610  veya  4D7610  veya  fonksiyon adi" autocomplete="off">
  <div class="hint">Enter = git &middot; Esc = kapat &middot; ornek: .text:004D7610</div>
</div></div>

<script>
"use strict";
const $=id=>document.getElementById(id);
const CATS=[["all","T\u00fcm\u00fc"],["func","Fonksiyonlar"],["class","Class'lar"],["struct","Struct'lar"],["enum","Enum'lar"],["static","Static Variables"],["string","String Literals"],["xref","Function References"],["ins","Assembly Instructions"]];
const BADGE={func:"Fonksiyon",class:"S\u0131n\u0131f",struct:"Struct",enum:"Enum",static:"Statik",string:"String",xref:"\u00c7a\u011fr\u0131 Hedefi",ins:"Talimat",union:"Union"};
const CHIP={func:"F",class:"C",struct:"S",enum:"E",static:"G",string:"a",xref:"XR",ins:"ASM",union:"U"};
const S={cat:"all",q:"",o:0,total:0,stats:null,busy:false};
const F={q:"",o:0,total:0,loaded:false};
const PDBNAME=window.PDBNAME||"metin2client.pdb";

function esc(s){return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}
function hx(v){return "0x"+(v>>>0).toString(16).toUpperCase().padStart(8,"0")}
async function api(p){
  let r;
  try{ r=await fetch(p,{cache:"no-store"}); }
  catch(e){ $("neterr").style.display="block"; throw e; }
  $("neterr").style.display="none";
  if(!r.ok) throw new Error("HTTP "+r.status);
  return r.json();
}

/* ---------- ana ekran ---------- */
function drawStats(){
  const st=S.stats; if(!st) return;
  $("hsub").textContent=PDBNAME+" \u00b7 "+st.functions.toLocaleString("tr-TR")+" fonksiyon analiz edildi";
  const cards=[["functions","Fonksiyon","func"],["classes","S\u0131n\u0131f","class"],["structs","Struct","struct"],["enums","Enum","enum"],["statics","Statik De\u011fi\u015fken","static"],["strings","String Literal","string"],["calls","\u00c7a\u011fr\u0131 Talimat\u0131","xref"]];
  $("stats").innerHTML=cards.map(c=>'<div class="scard" onclick="setCat(\''+c[2]+'\')"><b>'+(st[c[0]]||0).toLocaleString("tr-TR")+'</b><span>'+c[1]+'</span></div>').join("");
}
function drawTabs(){
  $("tabs").innerHTML=CATS.map(c=>'<button class="tab'+(S.cat===c[0]?" on":"")+'" onclick="setCat(\''+c[0]+'\')">'+c[1]+'</button>').join("");
}
function setCat(c){ S.cat=c; S.o=0; drawTabs(); loadItems(true); }
function itemRow(it){
  const k=(it.kind==="cls")?"class":it.kind;
  let sub="";
  if(it.kind==="xref") sub=(it.count||0)+" \u00e7a\u011fr\u0131 \u00b7 "+hx(it.va);
  else if(it.kind==="ins") sub="\u00e7a\u011fr\u0131ran: "+(it.extra||"?")+" \u00b7 "+hx(it.va);
  else if(it.kind==="string") sub=it.extra||"";
  else if(it.kind==="static") sub=(it.extra?it.extra+" \u00b7 ":"")+hx(it.va);
  else if(it.kind==="func") sub=hx(it.va)+(it.size?" \u00b7 boyut "+it.size:"");
  else sub=(it.size?"boyut "+it.size+" bayt":"")+(it.extra?" \u00b7 "+it.extra:"");
  return '<div class="row" onclick="openItem(this)" data-kind="'+it.kind+'" data-name="'+esc(it.name)+'" data-va="'+(it.va||0)+'" data-udt="'+((it.kind==="struct"||it.kind==="class"||it.kind==="enum"||it.kind==="union")?esc(it.name):"")+'">'
    +'<div class="chip '+(k==="cls"?"class":k)+'">'+(CHIP[k]||"")+'</div>'
    +'<div class="rmain"><div class="rname">'+esc(it.name)+'</div><div class="rsub">'+esc(sub)+'</div></div>'
    +'<span class="badge">'+(BADGE[it.kind]||it.kind)+'</span>'
    +'<button class="copy" onclick="copyRva(event,'+(it.va||0)+')">RVA Kopyala</button></div>';
}
async function loadItems(reset){
  if(S.busy) return; S.busy=true;
  const more=$("more"); more.disabled=true;
  try{
    const q=S.q?("&q="+encodeURIComponent(S.q)):"";
    const d=await api("/api/items?cat="+S.cat+q+"&o="+S.o+"&n=100");
    S.total=d.total||0;
    const html=(d.items||[]).map(itemRow).join("");
    if(reset){ $("list").innerHTML=html; S.o=(d.items||[]).length; }
    else{ $("list").insertAdjacentHTML("beforeend",html); S.o+=(d.items||[]).length; }
    more.textContent=S.o<S.total?("Daha fazla goster ("+S.o+"/"+S.total+")"):"T\u00fcm\u00fc listelendi ("+S.total+")";
  }catch(e){}
  S.busy=false; more.disabled=false;
}
function openItem(el){
  const k=el.dataset.kind, name=el.dataset.name, va=+el.dataset.va, udt=el.dataset.udt;
  if(k==="func") return openDisasmName(name);
  if(k==="xref") return openDisasmAddr(va);
  if(k==="ins") return openDisasmAddr(va);
  if(k==="string"||k==="static") return showSimple(k,name,va,el.querySelector(".rsub").textContent);
  if(udt) return openStruct(udt);
}
function copyRva(ev,va){
  ev.stopPropagation();
  const t="0x"+(va>>>0).toString(16).toUpperCase().padStart(8,"0");
  const done=()=>{ ev.target.textContent="Kopyaland\u0131"; setTimeout(()=>{ev.target.textContent="RVA Kopyala";},1200); };
  if(navigator.clipboard&&navigator.clipboard.writeText) navigator.clipboard.writeText(t).then(done,()=>fallbackCopy(t,done));
  else fallbackCopy(t,done);
}
function fallbackCopy(t,done){
  const ta=document.createElement("textarea"); ta.value=t; document.body.appendChild(ta); ta.select();
  try{ document.execCommand("copy"); if(done)done(); }catch(e){} ta.remove();
}

/* ---------- modallar ---------- */
function showModal(title,tag,html){ $("mtitle").textContent=title; $("mtag").textContent=tag; $("mbody").innerHTML=html; $("modal").style.display="flex"; }
function closeModal(){ $("modal").style.display="none"; }
async function openStruct(name){
  try{
    const d=await api("/api/struct?name="+encodeURIComponent(name));
    if(!d.found){ showModal(name,"bulunamad\u0131","<p>B\u00f6yle bir tip yok.</p>"); return; }
    let h='<div class="kv">Boyut: <b>'+d.size+'</b> bayt</div>';
    if(d.enums&&d.enums.length){
      h+='<div class="msec">De\u011ferler ('+d.enums.length+')</div><table class="mem"><tr><th>De\u011fer</th><th>Ad</th></tr>';
      for(const e of d.enums) h+="<tr><td class='off'>"+e.val+"</td><td><b>"+esc(e.name)+"</b></td></tr>";
      h+="</table>";
    }
    if(d.members&&d.members.length){
      h+='<div class="msec">\u00dcyeler ('+d.members.length+')</div><table class="mem"><tr><th>Offset</th><th>Ad</th><th>Tip</th></tr>';
      for(const m of d.members){
        const offTxt=m.flag?"\u2014":("+"+(m.off>=0?("0x"+m.off.toString(16).toUpperCase()):("-0x"+(-m.off).toString(16).toUpperCase())));
        const fl=m.flag?(" <span class='mtag'>"+m.flag+"</span>"):"";
        let tp=esc(m.type);
        if(m.tu) tp="<span class='udtl2' onclick='openStruct(\""+esc(m.tu)+"\")'>"+esc(m.type)+"</span>";
        h+="<tr><td class='off'>"+offTxt+"</td><td><b>"+esc(m.name)+"</b>"+fl+"</td><td class='tp'>"+tp+"</td></tr>";
      }
      h+="</table>";
    }
    if(d.methods&&d.methods.length){
      h+='<div class="msec">Metotlar ('+d.methods.length+')</div>';
      h+=d.methods.map(m=>'<span class="meth" onclick=\'openDisasmName("'+esc(m.name)+'")\'>'+esc(m.name)+'</span>').join("");
    }
    showModal(d.name,d.kind,h);
  }catch(e){}
}
function showSimple(kind,name,va,sub){
  const html='<div class="kv">Adres: <b>'+hx(va)+'</b></div><div class="kv">'+esc(sub)+'</div>'
   +'<button class="copy" style="margin-top:10px" onclick="fallbackCopy(\''+hx(va)+'\');this.textContent=\'Kopyaland\u0131\'">Adresi Kopyala</button>';
  showModal(name,BADGE[kind]||kind,html);
}

/* ---------- disassembly ekrani ---------- */
function showDis(){
  $("home").style.display="none"; $("dis").style.display="flex";
  if(!F.loaded){ F.loaded=true; loadFuncs(true); }
}
function showHome(){ $("dis").style.display="none"; $("home").style.display="block"; }

async function loadFuncs(reset){
  try{
    const q=F.q?("&q="+encodeURIComponent(F.q)):"";
    const d=await api("/api/funcs?o="+F.o+"&n=300"+q);
    F.total=d.total||0;
    const html=(d.items||[]).map(f=>'<div class="fitem" data-name="'+esc(f.name)+'" onclick="openDisasmName(this.dataset.name)"><span class="fva">'+(f.va>>>0).toString(16).toUpperCase()+'</span>'+esc(f.name)+'</div>').join("");
    if(reset) $("flist").innerHTML=html; else $("flist").insertAdjacentHTML("beforeend",html);
    F.o+=(d.items||[]).length;
    if(F.o<F.total){
      const s=document.createElement("div"); s.id="fsentinel"; s.style.height="1px"; $("flist").appendChild(s);
      new IntersectionObserver(es=>{ if(es[0].isIntersecting){ const sn=$("fsentinel"); if(sn){sn.remove(); loadFuncs(false);} } },{root:$("flist")}).observe(s);
    }
  }catch(e){}
}

/* IDA tarzi renklendirme - siralama kritik: once tirnaklar, sonra diger spanlar
   (yoksa class="mn" icindeki tirnaklar string-vurgusuyla bozulur).
   Tiklanabilir ogeler class ile isaretlenir, tiklamada textContent okunur. */
function colorize(raw){
  let t=esc(raw);
  // yorum bolumunu ayir (tirnak disindaki ilk ;)
  let inQ=false, cut=-1;
  for(let i=0;i<t.length;i++){ const ch=t[i]; if(ch==='"') inQ=!inQ; else if(ch===';'&&!inQ){ cut=i; break; } }
  let code=(cut>=0)?t.slice(0,cut):t;
  let com=(cut>=0)?t.slice(cut):"";
  const sq=s=>s.replace(/("[^"]*")/g,'<span class="strq">$1</span>');
  // adres on eki
  let body=code, pre="";
  const am=code.match(/^(\.?[\w]*:[0-9A-F]{8}|[0-9A-F]{8})(\s+)([\s\S]*)$/);
  if(am){ pre='<span class="ad">'+am[1]+'</span>'+am[2]; body=am[3]; }
  const isVar=/^\S+\s+= /.test(body);
  const isProc=/proc near|endp/.test(body);
  let out;
  if(isProc) out='<span class="proc">'+sq(body)+'</span>';
  else if(isVar) out=sq(body);
  else{
    const bm=body.match(/^([a-z][a-z0-9]*)(\s+)([\s\S]*)$/);
    out=bm?('<span class="mn">'+bm[1]+'</span>'+bm[2]+sq(bm[3])):sq(body);
  }
  out=out.replace(/\boffset (a[A-Za-z0-9_]+)/g,'offset <span class="strl">$1</span>');
  out=out.replace(/(<span class="mn">(?:call|jmp)<\/span>(?:\s+))(\?[^\s<]+)/g,(m,a,b)=>a+'<span class="fn">'+b+'</span>');
  out=out.replace(/\b(loc|sub)_([0-9A-F]+)/g,'<span class="loc">$1_$2</span>');
  if(isVar) out=out.replace(/=\s*([A-Za-z_]\w*)\s+ptr/,(m,ty)=>(" dword byte word qword tbyte fword ".indexOf(" "+ty+" ")>=0)?m:('= <span class="udtl">'+ty+'</span> ptr'));
  out=out.replace(/\bthis\b/g,'<span class="ths">this</span>');
  out=out.replace(/\b(dword|byte|word|qword|tbyte|fword) ptr\b/g,'<span class="dim">$1 ptr</span>');
  out=out.replace(/(\[[^\[\]]*\])/g,'<span class="mem">$1</span>');
  out=out.replace(/(?<![\w"])([0-9A-F]{1,8}h|\d+)(?![\w"])/g,'<span class="num">$1</span>');
  // yorumlar
  if(com){
    const xr=com.match(/^;\s*CODE XREF:\s*([^\s+]+)(\+[0-9A-F]+[pj])?/);
    if(xr) com='<span class="cm">; CODE XREF: </span><span class="xrn">'+xr[1]+'</span>'+(xr[2]?'<span class="cm">'+xr[2]+'</span>':'');
    else com=('<span class="cm">'+com.replace(/("[^"]*")/g,'\u0001$1\u0002')+'</span>').replace(/\u0001/g,'</span><span class="strq">').replace(/\u0002/g,'</span><span class="cm">');
  }
  return pre+out+com;
}

async function openDisasmName(name,focus){ return openDisasm("name="+encodeURIComponent(name),focus); }
async function openDisasmAddr(va,focus){ return openDisasm("addr=0x"+(va>>>0).toString(16),focus||va); }
async function openDisasm(qs,focus){
  try{
    const d=await api("/api/disasm?"+qs);
    if(!d.found) return;
    const f=(typeof focus==="number"&&focus)?focus:(d.focus||0);
    $("dname").textContent=d.name;
    $("dmeta").textContent=hx(d.va)+" \u00b7 boyut "+d.size+" \u00b7 "+d.proto;
    const lines=d.text.split("\n");
    let html="";
    for(const ln of lines){
      if(!ln){ html+='<div class="ln">&nbsp;</div>'; continue; }
      let va=""; const m=ln.match(/:([0-9A-F]{8})/)||ln.match(/^([0-9A-F]{8})\s/);
      if(m) va=(m[1]||"").toLowerCase().padStart(8,"0");
      html+='<div class="ln" data-va="'+va+'">'+colorize(ln)+'</div>';
    }
    $("code").innerHTML=html;
    showDis();
    $("code").scrollTop=0;
    if(f){
      const key=(f>>>0).toString(16).toLowerCase().padStart(8,"0");
      const el=$("code").querySelector('[data-va="'+key+'"]');
      if(el){ el.classList.add("flash"); el.scrollIntoView({block:"center"}); }
    }
  }catch(e){}
}

/* kod alaninda tiklama: cagri hedefleri, xref, loc_, struct tipleri */
$("code").addEventListener("click",e=>{
  const cl=e.target.classList;
  if(cl.contains("udtl")){ openStruct(e.target.textContent.trim()); return; }
  if(cl.contains("fn")||cl.contains("xrn")){ openDisasmName(e.target.textContent.trim()); return; }
  if(cl.contains("loc")){
    const a=e.target.textContent.trim().replace(/^(loc|sub)_/,"");
    const va=parseInt(a,16); if(va) openDisasmAddr(va);
  }
});

/* sol liste aramasi (en altta) + sonsuz kaydirma */
let fqt=null;
$("fq").addEventListener("input",()=>{ clearTimeout(fqt); fqt=setTimeout(()=>{ F.q=$("fq").value.trim(); F.o=0; loadFuncs(true); },250); });
$("back").onclick=showHome;
$("gotobtn").onclick=()=>{ $("goto").style.display="flex"; $("gotoInput").focus(); $("gotoInput").select(); };
$("gotoInput").addEventListener("keydown",e=>{
  if(e.key==="Enter") doGoto();
  if(e.key==="Escape") $("goto").style.display="none";
});
$("goto").addEventListener("click",e=>{ if(e.target===$("goto")) $("goto").style.display="none"; });
async function doGoto(){
  const v=$("gotoInput").value.trim(); if(!v) return;
  const hexish=v.replace(/^\.[\w]+:/,"").replace(/^0x/i,"");
  if(/^[0-9A-Fa-f]{4,8}$/.test(hexish)){
    try{
      const d=await api("/api/goto?addr=0x"+parseInt(hexish,16).toString(16));
      if(d.found){ $("goto").style.display="none"; return openDisasmAddr(d.funcVa,parseInt(hexish,16)); }
    }catch(e){}
  }
  try{
    const d=await api("/api/goto?name="+encodeURIComponent(v));
    if(d.found){ $("goto").style.display="none"; return openDisasmName(d.name); }
  }catch(e){}
}
document.addEventListener("keydown",e=>{
  const disOpen=$("dis").style.display==="flex";
  if(disOpen&&(e.ctrlKey||e.metaKey)&&(e.key==="g"||e.key==="G")){ e.preventDefault(); $("goto").style.display="flex"; $("gotoInput").focus(); $("gotoInput").select(); }
  if(e.key==="Escape"){ $("goto").style.display="none"; closeModal(); }
});
$("modal").addEventListener("click",e=>{ if(e.target===$("modal")) closeModal(); });
let qT=null;
$("q").addEventListener("input",()=>{ clearTimeout(qT); qT=setTimeout(()=>{ S.q=$("q").value.trim(); S.o=0; loadItems(true); },250); });
$("more").onclick=()=>loadItems(false);

/* baslangic */
drawTabs();
(async()=>{
  try{
    const st=await api("/api/stats");
    S.stats=st; drawStats(); loadItems(true);
  }catch(e){ $("hsub").textContent="Sunucuya baglanilamadi"; }
})();
</script>
</body>
</html>)WEBUI";
