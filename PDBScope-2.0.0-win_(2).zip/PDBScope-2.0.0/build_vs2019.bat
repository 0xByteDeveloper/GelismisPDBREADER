@echo off
rem ============================================================
rem  PDBScope - VS2019 (MSVC v142) komut satiri derleme betigi
rem  Kullanim:
rem    build_vs2019.bat              (Release x64)
rem    build_vs2019.bat Debug x64
rem    build_vs2019.bat Release Win32
rem  Not: "x64 Native Tools Command Prompt for VS 2019" icinden
rem  calistirin ya da asagidaki yollari duzenleyin.
rem ============================================================
setlocal
set CONF=%1
if "%CONF%"=="" set CONF=Release
set PLAT=%2
if "%PLAT%"=="" set PLAT=x64

set VSPATH=
if exist "%ProgramFiles(x86)%\Microsoft Visual Studio\2019\Community\VC\Auxiliary\Build\vcvarsall.bat" set VSPATH=%ProgramFiles(x86)%\Microsoft Visual Studio\2019\Community\VC\Auxiliary\Build\vcvarsall.bat
if exist "%ProgramFiles(x86)%\Microsoft Visual Studio\2019\Professional\VC\Auxiliary\Build\vcvarsall.bat" set VSPATH=%ProgramFiles(x86)%\Microsoft Visual Studio\2019\Professional\VC\Auxiliary\Build\vcvarsall.bat
if exist "%ProgramFiles(x86)%\Microsoft Visual Studio\2019\Enterprise\VC\Auxiliary\Build\vcvarsall.bat" set VSPATH=%ProgramFiles(x86)%\Microsoft Visual Studio\2019\Enterprise\VC\Auxiliary\Build\vcvarsall.bat
if exist "%ProgramFiles%\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvarsall.bat" set VSPATH=%ProgramFiles%\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvarsall.bat

if "%VSPATH%"=="" (
    echo [HATA] Visual Studio 2019/2022 vcvarsall.bat bulunamadi.
    echo msbuild dogrudan da kullanilabilir:
    echo   msbuild vs\PDBScope.vcxproj /p:Configuration=%CONF% /p:Platform=%PLAT%
    exit /b 1
)

call "%VSPATH%" %PLAT%
msbuild "%~dp0vs\PDBScope.vcxproj" /p:Configuration=%CONF% /p:Platform=%PLAT% /m /nologo
if errorlevel 1 (
    echo [HATA] derleme basarisiz
    exit /b 1
)
echo.
echo Derleme tamam: vs\%PLAT%\%CONF%\pdbscope.exe
endlocal
