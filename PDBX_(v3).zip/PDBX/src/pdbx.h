// PDBX - Metin2 PDB okuyucu + disassembler
// Bolum 1: ortak tipler, MSF 7.00 konteyner, PE32 yukleyici
#pragma once
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <string>
#include <vector>
#include <map>
#include <unordered_map>
#include <unordered_set>
#include <set>
#include <algorithm>
#include <functional>

typedef uint8_t  u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
typedef int8_t   i8;
typedef int16_t  i16;
typedef int32_t  i32;
typedef int64_t  i64;

static inline u16 rd16(const u8* p) { return (u16)(p[0] | (p[1] << 8)); }
static inline u32 rd32(const u8* p) { return (u32)p[0] | ((u32)p[1] << 8) | ((u32)p[2] << 16) | ((u32)p[3] << 24); }
static inline u64 rd64(const u8* p) { return (u64)rd32(p) | ((u64)rd32(p + 4) << 32); }
static inline i32 rdi32(const u8* p) { return (i32)rd32(p); }

// ---------------- MSF 7.00 ----------------
struct MsfStream { u32 size = 0; std::vector<u32> blocks; };
struct Msf {
    std::vector<u8> data;
    u32 blockSize = 0, numBlocks = 0;
    std::vector<MsfStream> streams;
    bool load(const std::vector<u8>& raw, std::string& err);
    bool streamBytes(size_t idx, std::vector<u8>& out) const;
};

// ---------------- PE32 ----------------
struct PESection {
    std::string name;
    u32 va = 0, vsz = 0, raw = 0, rsz = 0, chars = 0;
};
struct PE {
    u32 imageBase = 0, sizeOfImage = 0, entryRva = 0;
    std::vector<PESection> secs;
    std::vector<u8> image;   // bellek goruntusu (RVA = offset)
    bool load(const std::vector<u8>& raw, std::string& err);
    // VA -> image buffer okuma
    const u8* ptr(u32 va, u32 len) const {
        if (!image.size() || va < imageBase) return nullptr;
        u64 rva = (u64)va - imageBase;
        if (rva + len > image.size()) return nullptr;
        return &image[(size_t)rva];
    }
    bool read(u32 va, void* dst, u32 len) const {
        const u8* p = ptr(va, len);
        if (!p) return false;
        memcpy(dst, p, len);
        return true;
    }
    u32 secRva(int seg) const { // pdb segment no (1 tabanli) -> RVA
        if (seg < 1 || (size_t)seg > secs.size()) return 0;
        return secs[seg - 1].va;
    }
};

// ---------------- Tip veritabani ----------------
struct Member { std::string name; i64 off = 0; u32 tidx = 0; u32 attr = 0; };
struct EnumVal { std::string name; i64 val = 0; };
struct TypeRec {
    u16 leaf = 0;
    std::string name;
    u64 size = 0; bool sizeKnown = false;
    u32 fieldlist = 0;
    std::vector<Member> members;
    std::vector<EnumVal> evals;
    u32 a = 0, b = 0;         // genel amacli: utype/elem vs
    u32 clsType = 0, thisType = 0, arglist = 0;
    u32 rvType = 0, baseType = 0;
    u16 callconv = 0, attr16 = 0;
    u32 nparams = 0;
    u32 bitLen = 0, bitPos = 0;
    std::vector<u32> args;
    bool valid = false;
};

struct LocalVar {
    std::string name;
    i32 off = 0x7FFFFFFF;    // ebp goreli (arg: >0, local: <=0)
    u32 tidx = 0;
    i32 reg = -1;            // CV reg no (18=ecx)
    bool isReg = false;
    bool isArg = false;
};

struct FuncInfo {
    std::string name;        // decorli (PROC kaydindan)
    std::string shortName;   // Class::Fonk (dekorasyon islemesinden)
    std::string mangled;     // pub32
    u32 seg = 0, off = 0, size = 0;
    u32 tidx = 0;
    bool hasType = false;
    std::vector<LocalVar> locals;
    // doldurulur:
    u32 va = 0;
    std::string proto;       // prototip satiri
    bool isThiscall = false;
    u32 thisClassIdx = 0;    // class tip index (pointer deref sonrasi)
    std::vector<std::string> argNames;  // sirali
};

struct GlobalSym { std::string name; std::string mangled; u32 tidx = 0; u32 seg = 0, off = 0; u32 va = 0; bool isFunc = false; };

// exe icindeki ASCII string literali ("String Literals" sekmesi)
struct StrLit { u32 va = 0; std::string text; std::string label; };

struct PdbData {
    Msf msf;
    std::string guidStr, pdbPath;
    u32 age = 0, sigTime = 0;
    std::unordered_map<u32, TypeRec> types;
    std::unordered_map<std::string, u32> completeByName; // isim -> en tam kayit
    u32 tpiBegin = 0x1000, tpiEnd = 0;
    std::vector<FuncInfo> funcs;
    std::unordered_map<u32, int> funcByVa;      // va -> funcs index
    std::unordered_map<u32, std::string> pubMangled;  // va -> mangled
    std::unordered_map<u64, std::string> pubSegOff;   // (seg<<32|off) -> mangled
    std::vector<GlobalSym> globals;
    std::unordered_map<u32, int> globByVa;
    std::vector<std::pair<std::string, i64>> consts;  // sabitler

    bool parse(const std::vector<u8>& raw, std::string& err);
    const TypeRec* type(u32 idx) const {
        auto it = types.find(idx);
        return it == types.end() ? nullptr : &it->second;
    }
    // fwdref ise ayni isimli tam kaydi dondurur
    const TypeRec* completeType(u32 idx) const {
        const TypeRec* t = type(idx);
        if (!t) return nullptr;
        if (!t->members.empty() || t->name.empty()) return t;
        auto it = completeByName.find(t->name);
        if (it == completeByName.end()) return t;
        const TypeRec* c = type(it->second);
        return (c && !c->members.empty()) ? c : t;
    }
    // yardimcilar
    std::string typeName(u32 idx, int depth = 0) const;
    std::string fullProto(const FuncInfo& f, bool withThis = true) const;
    bool resolveMemberPath(u32 tidx, i64 delta, std::string& out, int depth = 0) const;
    const FuncInfo* findFuncByNameSub(const std::string& sub, int* count = nullptr) const;
};

// PE yukleyip VA hesaplama
void resolveVAs(PdbData& pdb, const PE* pe);

// PE bolumlerini tarayip ASCII string literallerini toplar (label: aXxx)
std::vector<StrLit> scanStrings(const PE& pe, size_t maxResults);
// IDA tarzi string etiketi: alnum al, 14 harf, 'a' oneki
std::string strLabel14(const std::string& s);

// web GUI sunucusu (pdbx_server.cpp) - donmeye yatik dongu, Ctrl+C ile durur
int serveWeb(PdbData& pdb, const PE* pe, const std::string& pdbPath, const std::string& exeName, u16 port);

// dosya okuma
bool readFile(const char* path, std::vector<u8>& out, std::string& err);
// kucuk yardimcilar
std::string lowerDup(const std::string& s);
std::string hexU32(u32 v);
std::string hexU64(u64 v);
