// PDBX x86 32-bit disassembler (IDA tarzi sembolizasyon)
#include "pdbx.h"
#include "disasm.h"
#include <cctype>

namespace disasm {

static const char* REG32[8] = { "eax", "ecx", "edx", "ebx", "esp", "ebp", "esi", "edi" };
static const char* REG16[8] = { "ax", "cx", "dx", "bx", "sp", "bp", "si", "di" };
static const char* REG8[8] = { "al", "cl", "dl", "bl", "ah", "ch", "dh", "bh" };
static const char* CCN[16] = { "o", "no", "b", "ae", "z", "nz", "be", "a", "s", "ns", "p", "np", "l", "ge", "le", "g" };
static const char* SHIFTN[8] = { "rol", "ror", "rcl", "rcr", "shl", "shr", "sal", "sar" };
static const char* ALUN[8] = { "add", "or", "adc", "sbb", "and", "sub", "xor", "cmp" };

static std::string xmmName(int r) { char b[16]; snprintf(b, sizeof b, "xmm%d", r); return b; }
static std::string mmName(int r) { char b[16]; snprintf(b, sizeof b, "mm%d", r); return b; }

struct Ctx {
    const PdbData* pdb;
    const PE* pe;
    const FuncInfo* fn = nullptr;
    u32 thisClass = 0;                    // class tip index (pointer sonrasi)
    std::unordered_set<int> thisRegs;     // 'this' tutan x86 yazmac indeksleri
    std::unordered_set<int> thisNameRegs; // metinde 'this' yazilacaklar (sadece ecx)

    const FuncInfo* funcAt(u32 va) const {
        auto it = pdb->funcByVa.find(va);
        return it == pdb->funcByVa.end() ? nullptr : &pdb->funcs[it->second];
    }
    const GlobalSym* globAt(u32 va) const {
        auto it = pdb->globByVa.find(va);
        return it == pdb->globByVa.end() ? nullptr : &pdb->globals[it->second];
    }
    std::string addrName(u32 va) const {
        char b[16]; snprintf(b, sizeof b, "%X", va); return b;
    }
    std::string immHex(u32 v) const {
        char b[24]; snprintf(b, sizeof b, "%Xh", v); return b;
    }
    static std::string immNum(u32 v) {
        char b[24];
        if (v < 10) snprintf(b, sizeof b, "%u", v);
        else snprintf(b, sizeof b, "%Xh", v);
        return b;
    }
    static std::string strLabel(const std::string& s) {
        std::string r = "a";
        int k = 0;
        for (char ch : s) {
            if (isalnum((unsigned char)ch)) { r += ch; if (++k >= 14) break; }
        }
        return r;
    }
    bool readStrAt(u32 va, std::string& out) const {
        if (!pe) return false;
        std::string s;
        for (u32 k = 0; k < 96; k++) {
            u8 ch;
            if (!pe->read(va + k, &ch, 1)) return false;
            if (ch == 0) break;
            if (ch < 0x20 || ch > 0x7E) return false;
            s += (char)ch;
        }
        if (s.size() < 4) return false;
        out = s;
        return true;
    }
    // ebp goreli degiskenin kendi boyutu (0 = bilinmiyor) - IDA size ipucu bastirmak icin
    u32 ebpVarSize(i32 off) const {
        if (!fn) return 0;
        for (auto& v : fn->locals) {
            if (v.isReg || v.off == 0x7FFFFFFF) continue;
            if (v.off == off) {
                u32 t = v.tidx;
                if (t < 0x1000) {
                    if ((t >> 8) & 0xFF) return 4;
                    switch (t & 0xFF) {
                    case 0x10: case 0x20: case 0x30: case 0x68: case 0x69: case 0x70: return 1;
                    case 0x11: case 0x21: case 0x71: case 0x72: case 0x73: return 2;
                    case 0x13: case 0x23: case 0x41: case 0x76: case 0x77: return 8;
                    default: return 4;
                    }
                }
                const TypeRec* ct = pdb->completeType(t);
                if (ct && ct->sizeKnown && ct->size) return (u32)ct->size;
                return 0;
            }
        }
        return 0;
    }
    std::string ebpName(i32 off, bool allowMember) const {
        if (fn) {
            if (allowMember) {
                for (auto& v : fn->locals) {
                    if (v.isReg || v.off == 0x7FFFFFFF) continue;
                    i64 delta = (i64)off - v.off;
                    if (delta < 0) continue;
                    std::string path;
                    if (pdb->resolveMemberPath(v.tidx, delta, path))
                        return "ebp+" + v.name + "." + path;
                }
            }
            for (auto& v : fn->locals) {
                if (v.isReg || v.off == 0x7FFFFFFF) continue;
                if (v.off == off) return "ebp+" + v.name;
            }
        }
        char b[32];
        if (off >= 0) snprintf(b, sizeof b, "ebp+%Xh", off);
        else snprintf(b, sizeof b, "ebp-%Xh", -off);
        return std::string(b);
    }
    bool memberName(u32 classIdx, i64 disp, std::string& out) const {
        if (!classIdx) return false;
        return pdb->resolveMemberPath(classIdx, disp, out);
    }
};

struct ModRM {
    u8 mod = 0, reg = 0, rm = 0;
    bool hasSib = false;
    u8 sibScale = 0, sibIndex = 0, sibBase = 0;
    bool hasDisp = false;
    i32 disp = 0;
    bool absOnly = false; // [disp32] tek basina
};

static bool parseModRM(const u8* p, size_t avail, bool a16, ModRM& m, size_t& consumed) {
    if (avail < 1) return false;
    m.mod = (p[0] >> 6) & 3;
    m.reg = (p[0] >> 3) & 7;
    m.rm = p[0] & 7;
    consumed = 1;
    m.absOnly = false;
    if (a16) {
        if (m.mod == 1) { if (avail < 2) return false; m.disp = (i8)p[1]; m.hasDisp = true; consumed = 2; }
        else if (m.mod == 2) { if (avail < 3) return false; m.disp = (i16)rd16(p + 1); m.hasDisp = true; consumed = 3; }
        return true;
    }
    if (m.mod == 3) return true;
    if (m.rm == 4) {
        if (avail < 2) return false;
        m.hasSib = true;
        m.sibScale = (p[1] >> 6) & 3;
        m.sibIndex = (p[1] >> 3) & 7;
        m.sibBase = p[1] & 7;
        consumed = 2;
        if (m.sibBase == 5 && m.mod == 0) {
            if (avail < 6) return false;
            m.disp = rdi32(p + 2);
            m.hasDisp = true;
            m.absOnly = true; // [idx*scale + disp]
            consumed = 6;
            return true;
        }
        if (m.mod == 1) { if (avail < 3) return false; m.disp = (i8)p[2]; m.hasDisp = true; consumed = 3; }
        else if (m.mod == 2) { if (avail < 6) return false; m.disp = rdi32(p + 2); m.hasDisp = true; consumed = 6; }
        return true;
    }
    if (m.mod == 0) {
        if (m.rm == 5) {
            if (avail < 5) return false;
            m.disp = rdi32(p + 1);
            m.hasDisp = true;
            m.absOnly = true; // [disp32]
            consumed = 5;
            return true;
        }
        return true;
    }
    if (m.mod == 1) { if (avail < 2) return false; m.disp = (i8)p[1]; m.hasDisp = true; consumed = 2; }
    else { if (avail < 5) return false; m.disp = rdi32(p + 1); m.hasDisp = true; consumed = 5; }
    return true;
}

static std::string memText(const Ctx& c, const ModRM& m, bool segFS, const char* sizeHint) {
    std::string s;
    const char* hint = (sizeHint && *sizeHint) ? sizeHint : nullptr;
    bool ebpRel = false;
    if (!m.hasSib && !m.absOnly) ebpRel = (m.rm == 5 && m.mod != 0);
    // 1) ebp goreli: args/locals
    if (ebpRel && m.hasDisp) {
        // IDA: ipucu degiskenin kendi boyutuysa gostermaz (mov bl, [ebp+isPress])
        u32 vsz = c.ebpVarSize(m.disp);
        bool drop = hint && vsz &&
            ((hint[0] == 'b' && hint[1] == 'y' && vsz == 1) ||   // byte ptr
             (hint[0] == 'w' && vsz == 2) ||                     // word ptr
             (hint[0] == 'd' && vsz == 4) ||                     // dword ptr
             (hint[0] == 'q' && vsz == 8));                      // qword ptr
        if (hint && !drop) { s += hint; s += " "; }
        if (segFS) s += "fs:";
        s += "[";
        s += c.ebpName(m.disp, true);
        s += "]";
        return s;
    }
    if (hint) { s += hint; s += " "; }
    if (segFS) s += "fs:";
    s += "[";
    // 2) mutlak disp32: global / string
    if (m.absOnly && m.hasDisp) {
        u32 va = (u32)m.disp;
        std::string sym;
        bool named = false;
        if (!m.hasSib) {
            const GlobalSym* g = c.globAt(va);
            if (g) { sym = g->name; named = true; }
            if (!named) {
                std::string str;
                if (c.readStrAt(va, str)) {
                    sym = Ctx::strLabel(str);
                    named = true;
                }
            }
        } else {
            const GlobalSym* g = c.globAt(va);
            if (g) { sym = g->name; named = true; }
        }
        if (named) s += sym;
        else s += c.immHex((u32)m.disp);
        if (m.hasSib && m.sibIndex != 4) {
            char sc[8];
            snprintf(sc, sizeof sc, "+%s*%d", REG32[m.sibIndex], 1 << m.sibScale);
            s += sc;
        }
        s += "]";
        return s;
    }
    // 3) register tabanli
    std::string base, idx;
    u8 effBase = m.hasSib ? m.sibBase : m.rm;
    base = REG32[effBase];
    if (m.hasSib && m.sibIndex != 4) {
        char sc[8];
        snprintf(sc, sizeof sc, "*%d", 1 << m.sibScale);
        idx = std::string(REG32[m.sibIndex]) + sc;
    }
    // this->uye denemesi
    int baseIdx = (int)effBase;
    if (c.thisRegs.count(baseIdx) && c.thisClass && m.hasDisp) {
        std::string mn;
        if (c.memberName(c.thisClass, m.disp, mn)) {
            s += mn;
            s += "]";
            return s;
        }
    }
    s += base;
    if (!idx.empty()) { s += "+"; s += idx; }
    if (m.hasDisp) {
        char b[32];
        if (m.disp >= 0) snprintf(b, sizeof b, "+%Xh", m.disp);
        else snprintf(b, sizeof b, "-%Xh", -m.disp);
        s += b;
    }
    s += "]";
    return s;
}

static std::string rm8Text(const Ctx& c, const ModRM& m, bool segFS) {
    return (m.mod == 3) ? std::string(REG8[m.rm]) : memText(c, m, segFS, "byte ptr");
}
static std::string rm32Text(const Ctx& c, const ModRM& m, bool segFS) {
    return (m.mod == 3) ? std::string(REG32[m.rm]) : memText(c, m, segFS, "dword ptr");
}
static std::string rm16Text(const Ctx& c, const ModRM& m, bool segFS) {
    return (m.mod == 3) ? std::string(REG16[m.rm]) : memText(c, m, segFS, "word ptr");
}

static std::string substituteThis(const std::string& in, const std::unordered_set<int>& thisRegs) {
    if (thisRegs.empty()) return in;
    std::string r;
    r.reserve(in.size());
    size_t i = 0;
    while (i < in.size()) {
        bool matched = false;
        for (int reg = 0; reg < 8; reg++) {
            if (!thisRegs.count(reg)) continue;
            const char* nm = REG32[reg];
            size_t l = strlen(nm);
            if (in.compare(i, l, nm) == 0) {
                bool okBefore = (i == 0) || !(isalnum((unsigned char)in[i-1]) || in[i-1] == '_');
                size_t j = i + l;
                bool okAfter = (j >= in.size()) || !(isalnum((unsigned char)in[j]) || in[j] == '_');
                if (okBefore && okAfter) {
                    r += "this";
                    i = j;
                    matched = true;
                    break;
                }
            }
        }
        if (!matched) { r += in[i]; i++; }
    }
    return r;
}

struct InsMeta {
    int dstReg32 = -1, srcReg32 = -1;
    bool isMov = false;
    u32 callTarget = 0;      // 0 = yok
    u32 branchTarget = 0;
    bool isJmp = false, isRet = false, isCall = false;
    std::string comment;
};

// bir talimat coz; uzunluk dondurur (>=1). out != null ise metin uretilir.
static size_t decode(const Ctx& c, const u8* p, size_t avail, u32 va,
                     std::string* out, InsMeta* meta) {
    size_t start = 0;
    bool o16 = false, a16 = false, segFS = false;
    std::string prefixes;
    size_t i = 0;
    while (i < avail) {
        u8 b = p[i];
        if (b == 0x66) { o16 = true; i++; prefixes = "word "; continue; }
        if (b == 0x67) { a16 = true; i++; continue; }
        if (b == 0x64) { segFS = true; i++; continue; }
        if (b == 0x65 || b == 0x2E || b == 0x36 || b == 0x3E || b == 0x26) { i++; continue; }
        if (b == 0xF0) { i++; prefixes = "lock "; continue; }
        if (b == 0xF2) { i++; prefixes = "repne "; continue; }
        if (b == 0xF3) { i++; prefixes = "rep "; continue; }
        break;
    }
#define FAIL_UNKNOWN() do { if (out) *out = "db " + c.immHex(p[0]); return 1; } while (0)
    if (i >= avail) FAIL_UNKNOWN();
    u8 op = p[i]; i++;

    ModRM m; bool hasMod = false;
    auto modrm = [&]() -> bool {
        if (hasMod) return true;
        size_t mc = 0;
        if (!parseModRM(p + i, avail - i, a16, m, mc)) return false;
        i += mc;
        hasMod = true;
        return true;
    };
    auto imm8s = [&](int& v) -> bool {
        if (i + 1 > avail) return false;
        v = (i8)p[i]; i++; return true;
    };
    auto imm32v = [&](u32& v) -> bool {
        if (i + 4 > avail) return false;
        v = rd32(p + i); i += 4; return true;
    };
    std::string s;
    u32 branchTgt = 0;
    bool hasBranch = false;

    // ALU 00-3D
    if (op <= 0x3D && (op & 7) <= 5 && (op & 0x38) % 8 == 0 && (op & 0xC0) == 0) {
        u8 kind = (op >> 3) & 7;
        u8 form = op & 7;
        if (out) {
            if (form <= 3) {
                if (!modrm()) FAIL_UNKNOWN();
                bool w8 = (form & 1) == 0;
                if (form <= 1)
                    s = std::string(ALUN[kind]) + " " + (w8 ? rm8Text(c, m, segFS) : rm32Text(c, m, segFS)) + ", " + (w8 ? REG8[m.reg] : REG32[m.reg]);
                else
                    s = std::string(ALUN[kind]) + " " + (w8 ? REG8[m.reg] : REG32[m.reg]) + ", " + (w8 ? rm8Text(c, m, segFS) : rm32Text(c, m, segFS));
                if (meta) { meta->dstReg32 = (int)m.reg; if (m.mod == 3) meta->srcReg32 = (int)m.rm; }
            } else if (form == 4) {
                int v; if (!imm8s(v)) FAIL_UNKNOWN();
                s = std::string(ALUN[kind]) + " al, " + c.immHex((u32)(v & 0xFF));
            } else {
                u32 v; if (!imm32v(v)) FAIL_UNKNOWN();
                s = std::string(ALUN[kind]) + " eax, " + c.immHex(v);
            }
        } else {
            if (form <= 3) { if (!modrm()) FAIL_UNKNOWN(); }
            else if (form == 4) { if (i + 1 > avail) FAIL_UNKNOWN(); i++; }
            else { if (i + 4 > avail) FAIL_UNKNOWN(); i += 4; }
        }
        goto emit;
    }

    switch (op) {
    case 0x06: s = "push es"; break;
    case 0x07: s = "pop es"; break;
    case 0x0E: s = "push cs"; break;
    case 0x16: s = "push ss"; break;
    case 0x17: s = "pop ss"; break;
    case 0x1E: s = "push ds"; break;
    case 0x1F: s = "pop ds"; break;
    case 0x27: s = "daa"; break;
    case 0x2F: s = "das"; break;
    case 0x37: s = "aaa"; break;
    case 0x3F: s = "aas"; break;
    case 0x40: case 0x41: case 0x42: case 0x43: case 0x44: case 0x45: case 0x46: case 0x47:
        s = std::string("inc ") + REG32[op - 0x40]; if (meta) meta->dstReg32 = op - 0x40; break;
    case 0x48: case 0x49: case 0x4A: case 0x4B: case 0x4C: case 0x4D: case 0x4E: case 0x4F:
        s = std::string("dec ") + REG32[op - 0x48]; if (meta) meta->dstReg32 = op - 0x48; break;
    case 0x50: case 0x51: case 0x52: case 0x53: case 0x54: case 0x55: case 0x56: case 0x57:
        s = std::string("push ") + REG32[op - 0x50]; if (meta) meta->srcReg32 = op - 0x50; break;
    case 0x58: case 0x59: case 0x5A: case 0x5B: case 0x5C: case 0x5D: case 0x5E: case 0x5F:
        s = std::string("pop ") + REG32[op - 0x58]; if (meta) meta->dstReg32 = op - 0x58; break;
    case 0x60: s = "pushad"; break;
    case 0x61: s = "popad"; break;
    case 0x62: if (!modrm()) FAIL_UNKNOWN(); s = "bound " + std::string(REG32[m.reg]) + ", " + memText(c, m, segFS, nullptr); break;
    case 0x63: if (!modrm()) FAIL_UNKNOWN(); s = "arpl " + rm16Text(c, m, segFS) + ", " + REG16[m.reg]; break;
    case 0x68: {
        u32 v; if (!imm32v(v)) FAIL_UNKNOWN();
        if (out) {
            const GlobalSym* g = c.globAt(v);
            std::string str;
            if (g) s = "push offset " + g->name;
            else if (c.readStrAt(v, str)) {
                s = "push offset " + Ctx::strLabel(str);
                if (meta) meta->comment = "\"" + str + "\"";
            }
            else s = "push " + c.immHex(v);
        }
        break;
    }
    case 0x69: { if (!modrm()) FAIL_UNKNOWN(); u32 v; if (!imm32v(v)) FAIL_UNKNOWN(); if (out) s = "imul " + std::string(REG32[m.reg]) + ", " + rm32Text(c, m, segFS) + ", " + c.immHex(v); if (meta) meta->dstReg32 = (int)m.reg; break; }
    case 0x6A: { int v; if (!imm8s(v)) FAIL_UNKNOWN(); if (out) s = "push " + std::to_string(v); break; }
    case 0x6B: { if (!modrm()) FAIL_UNKNOWN(); int v; if (!imm8s(v)) FAIL_UNKNOWN(); if (out) s = "imul " + std::string(REG32[m.reg]) + ", " + rm32Text(c, m, segFS) + ", " + std::to_string(v); if (meta) meta->dstReg32 = (int)m.reg; break; }
    case 0x6C: s = "insb"; break;
    case 0x6D: s = "insd"; break;
    case 0x6E: s = "outsb"; break;
    case 0x6F: s = "outsd"; break;
    case 0x70: case 0x71: case 0x72: case 0x73: case 0x74: case 0x75: case 0x76: case 0x77:
    case 0x78: case 0x79: case 0x7A: case 0x7B: case 0x7C: case 0x7D: case 0x7E: case 0x7F: {
        int v; if (!imm8s(v)) FAIL_UNKNOWN();
        branchTgt = va + i + v; hasBranch = true;
        if (out) s = std::string("j") + CCN[op - 0x70] + " short loc_" + c.addrName(branchTgt);
        break;
    }
    case 0x80: case 0x82: {
        if (!modrm()) FAIL_UNKNOWN();
        int v; if (!imm8s(v)) FAIL_UNKNOWN();
        if (out) s = std::string(ALUN[m.reg]) + " " + rm8Text(c, m, segFS) + ", " + c.immHex((u32)(v & 0xFF));
        break;
    }
    case 0x81: {
        if (!modrm()) FAIL_UNKNOWN();
        u32 v; if (!imm32v(v)) FAIL_UNKNOWN();
        if (out) s = std::string(ALUN[m.reg]) + " " + rm32Text(c, m, segFS) + ", " + c.immHex(v);
        break;
    }
    case 0x83: {
        if (!modrm()) FAIL_UNKNOWN();
        int v; if (!imm8s(v)) FAIL_UNKNOWN();
        if (out) s = std::string(ALUN[m.reg]) + " " + rm32Text(c, m, segFS) + ", " + Ctx::immNum((u32)(i32)v);
        break;
    }
    case 0x84: if (!modrm()) FAIL_UNKNOWN(); if (out) s = "test " + rm8Text(c, m, segFS) + ", " + REG8[m.reg]; break;
    case 0x85: if (!modrm()) FAIL_UNKNOWN(); if (out) s = "test " + rm32Text(c, m, segFS) + ", " + REG32[m.reg]; break;
    case 0x86: if (!modrm()) FAIL_UNKNOWN(); if (out) s = "xchg " + rm8Text(c, m, segFS) + ", " + REG8[m.reg]; break;
    case 0x87: if (!modrm()) FAIL_UNKNOWN(); if (out) s = "xchg " + rm32Text(c, m, segFS) + ", " + REG32[m.reg]; break;
    case 0x88: if (!modrm()) FAIL_UNKNOWN(); if (out) s = "mov " + rm8Text(c, m, segFS) + ", " + REG8[m.reg]; break;
    case 0x89: if (!modrm()) FAIL_UNKNOWN(); if (out) s = "mov " + rm32Text(c, m, segFS) + ", " + REG32[m.reg]; if (meta) { if (m.mod == 3) { meta->isMov = true; meta->dstReg32 = (int)m.rm; meta->srcReg32 = (int)m.reg; } } break;
    case 0x8A: if (!modrm()) FAIL_UNKNOWN(); if (out) s = "mov " + std::string(REG8[m.reg]) + ", " + rm8Text(c, m, segFS); break;
    case 0x8B: if (!modrm()) FAIL_UNKNOWN(); if (out) s = "mov " + std::string(REG32[m.reg]) + ", " + rm32Text(c, m, segFS); if (meta && m.mod == 3) { meta->isMov = true; meta->dstReg32 = (int)m.reg; meta->srcReg32 = (int)m.rm; } break;
    case 0x8C: if (!modrm()) FAIL_UNKNOWN(); if (out) s = "mov " + rm16Text(c, m, segFS) + ", sreg"; break;
    case 0x8D: if (!modrm()) FAIL_UNKNOWN(); if (out) s = "lea " + std::string(REG32[m.reg]) + ", " + memText(c, m, segFS, nullptr); if (meta) meta->dstReg32 = (int)m.reg; break;
    case 0x8E: if (!modrm()) FAIL_UNKNOWN(); if (out) s = "mov sreg, " + rm16Text(c, m, segFS); break;
    case 0x8F: if (!modrm()) FAIL_UNKNOWN(); if (out) s = "pop " + rm32Text(c, m, segFS); break;
    case 0x90: s = "nop"; break;
    case 0x91: case 0x92: case 0x93: case 0x94: case 0x95: case 0x96: case 0x97:
        if (out) s = std::string("xchg eax, ") + REG32[op - 0x90]; break;
    case 0x98: s = o16 ? "cbw" : "cwde"; break;
    case 0x99: s = o16 ? "cwd" : "cdq"; break;
    case 0x9B: s = "wait"; break;
    case 0x9C: s = o16 ? "pushfw" : "pushfd"; break;
    case 0x9D: s = o16 ? "popfw" : "popfd"; break;
    case 0x9E: s = "sahf"; break;
    case 0x9F: s = "lahf"; break;
    case 0xA0: case 0xA1: case 0xA2: case 0xA3: {
        u32 v; if (!imm32v(v)) FAIL_UNKNOWN();
        if (!out) break;
        ModRM ab; ab.mod = 0; ab.rm = 5; ab.hasDisp = true; ab.disp = (i32)v; ab.absOnly = true; ab.reg = 0;
        if (op == 0xA0) s = "mov al, " + memText(c, ab, segFS, nullptr);
        else if (op == 0xA1) s = "mov eax, " + memText(c, ab, segFS, nullptr);
        else if (op == 0xA2) s = "mov " + memText(c, ab, segFS, "byte ptr") + ", al";
        else s = "mov " + memText(c, ab, segFS, "dword ptr") + ", eax";
        break;
    }
    case 0xA4: s = prefixes.empty() ? "movsb" : prefixes + "movsb"; break;
    case 0xA5: s = prefixes.empty() ? (o16 ? "movsw" : "movsd") : prefixes + (o16 ? "movsw" : "movsd"); break;
    case 0xA6: s = prefixes.empty() ? "cmpsb" : prefixes + "cmpsb"; break;
    case 0xA7: s = prefixes.empty() ? (o16 ? "cmpsw" : "cmpsd") : prefixes + (o16 ? "cmpsw" : "cmpsd"); break;
    case 0xA8: { int v; if (!imm8s(v)) FAIL_UNKNOWN(); if (out) s = "test al, " + c.immHex((u32)(v & 0xFF)); break; }
    case 0xA9: { u32 v; if (!imm32v(v)) FAIL_UNKNOWN(); if (out) s = "test eax, " + c.immHex(v); break; }
    case 0xAA: s = prefixes.empty() ? "stosb" : prefixes + "stosb"; break;
    case 0xAB: s = prefixes.empty() ? (o16 ? "stosw" : "stosd") : prefixes + (o16 ? "stosw" : "stosd"); break;
    case 0xAC: s = prefixes.empty() ? "lodsb" : prefixes + "lodsb"; break;
    case 0xAD: s = prefixes.empty() ? (o16 ? "lodsw" : "lodsd") : prefixes + (o16 ? "lodsw" : "lodsd"); break;
    case 0xAE: s = prefixes.empty() ? "scasb" : prefixes + "scasb"; break;
    case 0xAF: s = prefixes.empty() ? (o16 ? "scasw" : "scasd") : prefixes + (o16 ? "scasw" : "scasd"); break;
    case 0xB0: case 0xB1: case 0xB2: case 0xB3: case 0xB4: case 0xB5: case 0xB6: case 0xB7: {
        if (i + 1 > avail) FAIL_UNKNOWN();
        u8 v = p[i]; i++;
        if (out) s = "mov " + std::string(REG8[op - 0xB0]) + ", " + Ctx::immNum((u32)v);
        break;
    }
    case 0xB8: case 0xB9: case 0xBA: case 0xBB: case 0xBC: case 0xBD: case 0xBE: case 0xBF: {
        u32 v; if (!imm32v(v)) FAIL_UNKNOWN();
        if (out) {
            const GlobalSym* g = c.globAt(v);
            std::string str;
            if (g) s = std::string("mov ") + REG32[op - 0xB8] + ", " + g->name;
            else if (c.readStrAt(v, str)) s = std::string("mov ") + REG32[op - 0xB8] + ", offset " + Ctx::strLabel(str);
            else s = std::string("mov ") + REG32[op - 0xB8] + ", " + c.immHex(v);
        }
        break;
    }
    case 0xC0: case 0xC1: {
        if (!modrm()) FAIL_UNKNOWN();
        int v; if (!imm8s(v)) FAIL_UNKNOWN();
        if (out) {
            bool w8 = (op == 0xC0);
            s = std::string(SHIFTN[m.reg]) + " " + (w8 ? rm8Text(c, m, segFS) : rm32Text(c, m, segFS)) + ", " + c.immHex((u32)(v & 0xFF));
        }
        break;
    }
    case 0xC2: { u32 v; if (i + 2 > avail) FAIL_UNKNOWN(); v = rd16(p + i); i += 2; if (out) s = "retn " + std::to_string(v); if (meta) meta->isRet = true; break; }
    case 0xC3: if (out) s = "retn"; if (meta) meta->isRet = true; break;
    case 0xC4: if (!modrm()) FAIL_UNKNOWN(); if (out) s = "les " + std::string(REG32[m.reg]) + ", " + memText(c, m, segFS, "dword ptr"); break;
    case 0xC5: if (!modrm()) FAIL_UNKNOWN(); if (out) s = "lds " + std::string(REG32[m.reg]) + ", " + memText(c, m, segFS, "dword ptr"); break;
    case 0xC6: { if (!modrm()) FAIL_UNKNOWN(); int v; if (!imm8s(v)) FAIL_UNKNOWN(); if (out) s = "mov " + rm8Text(c, m, segFS) + ", " + Ctx::immNum((u32)(v & 0xFF)); break; }
    case 0xC7: { if (!modrm()) FAIL_UNKNOWN(); u32 v; if (!imm32v(v)) FAIL_UNKNOWN(); if (out) s = "mov " + rm32Text(c, m, segFS) + ", " + Ctx::immNum(v); break; }
    case 0xC8: { if (i + 3 > avail) FAIL_UNKNOWN(); i += 3; if (out) s = "enter"; break; }
    case 0xC9: if (out) s = "leave"; if (meta) meta->isRet = true; break;
    case 0xCA: { if (i + 2 > avail) FAIL_UNKNOWN(); i += 2; if (out) s = "retf"; if (meta) meta->isRet = true; break; }
    case 0xCB: if (out) s = "retf"; if (meta) meta->isRet = true; break;
    case 0xCC: if (out) s = "int3"; break;
    case 0xCD: { if (i + 1 > avail) FAIL_UNKNOWN(); u8 v = p[i]; i++; if (out) s = "int " + c.immHex(v); break; }
    case 0xCE: if (out) s = "into"; break;
    case 0xCF: if (out) s = "iretd"; break;
    case 0xD0: case 0xD1: case 0xD2: case 0xD3: {
        if (!modrm()) FAIL_UNKNOWN();
        if (out) {
            bool w8 = (op == 0xD0 || op == 0xD2);
            s = std::string(SHIFTN[m.reg]) + " " + (w8 ? rm8Text(c, m, segFS) : rm32Text(c, m, segFS)) + ((op >= 0xD2) ? ", cl" : ", 1");
        }
        break;
    }
    case 0xD4: { if (i + 1 > avail) FAIL_UNKNOWN(); i++; if (out) s = "aam"; break; }
    case 0xD5: { if (i + 1 > avail) FAIL_UNKNOWN(); i++; if (out) s = "aad"; break; }
    case 0xD6: if (out) s = "salc"; break;
    case 0xD7: if (out) s = "xlat"; break;
    case 0xD8: case 0xD9: case 0xDA: case 0xDB: case 0xDC: case 0xDD: case 0xDE: case 0xDF: {
        if (!modrm()) FAIL_UNKNOWN();
        if (!out) break;
        u8 mop = op & 7;
        if (m.mod == 3) {
            u8 tail = m.reg * 8 + m.rm;
            // ozel register formlari
            if (mop == 1 && m.reg == 4 && m.rm == 0) { s = "fchs"; break; }
            if (mop == 1 && m.reg == 4 && m.rm == 1) { s = "fabs"; break; }
            if (mop == 1 && m.reg == 4 && m.rm == 2) { s = "ftst"; break; }
            if (mop == 1 && m.reg == 4 && m.rm == 3) { s = "fxam"; break; }
            if (mop == 1 && m.reg == 4 && m.rm == 7) { s = "fnstsw ax"; break; }
            if (mop == 1 && m.reg == 5 && m.rm == 0) { s = "fld1"; break; }
            if (mop == 1 && m.reg == 5 && m.rm == 1) { s = "fldl2t"; break; }
            if (mop == 1 && m.reg == 5 && m.rm == 2) { s = "fldl2e"; break; }
            if (mop == 1 && m.reg == 5 && m.rm == 3) { s = "fldpi"; break; }
            if (mop == 1 && m.reg == 5 && m.rm == 4) { s = "fldlg2"; break; }
            if (mop == 1 && m.reg == 5 && m.rm == 5) { s = "fldln2"; break; }
            if (mop == 1 && m.reg == 5 && m.rm == 6) { s = "fldz"; break; }
            if (mop == 1 && m.reg == 6 && m.rm == 0) { s = "f2xm1"; break; }
            if (mop == 1 && m.reg == 6 && m.rm == 1) { s = "fyl2x"; break; }
            if (mop == 1 && m.reg == 6 && m.rm == 2) { s = "fptan"; break; }
            if (mop == 1 && m.reg == 6 && m.rm == 3) { s = "fpatan"; break; }
            if (mop == 1 && m.reg == 6 && m.rm == 4) { s = "fxtract"; break; }
            if (mop == 1 && m.reg == 6 && m.rm == 5) { s = "fprem1"; break; }
            if (mop == 1 && m.reg == 6 && m.rm == 6) { s = "fdecstp"; break; }
            if (mop == 1 && m.reg == 6 && m.rm == 7) { s = "fincstp"; break; }
            if (mop == 1 && m.reg == 7 && m.rm == 0) { s = "fprem"; break; }
            if (mop == 1 && m.reg == 7 && m.rm == 1) { s = "fyl2xp1"; break; }
            if (mop == 1 && m.reg == 7 && m.rm == 2) { s = "fsqrt"; break; }
            if (mop == 1 && m.reg == 7 && m.rm == 3) { s = "fsincos"; break; }
            if (mop == 1 && m.reg == 7 && m.rm == 4) { s = "frndint"; break; }
            if (mop == 1 && m.reg == 7 && m.rm == 5) { s = "fscale"; break; }
            if (mop == 1 && m.reg == 7 && m.rm == 6) { s = "fsin"; break; }
            if (mop == 1 && m.reg == 7 && m.rm == 7) { s = "fcos"; break; }
            if (mop == 1 && m.reg == 2 && m.rm == 0) { s = "fnop"; break; }
            if (mop == 2 && m.reg == 5 && m.rm == 1) { s = "fucompp"; break; }
            if (mop == 3 && m.reg == 4 && m.rm == 2) { s = "fnclex"; break; }
            if (mop == 3 && m.reg == 4 && m.rm == 3) { s = "fninit"; break; }
            if (mop == 4 && m.reg == 4 && m.rm == 0) { s = "fnstsw ax"; break; }
            if (mop == 7 && m.reg == 4 && m.rm == 0) { s = "fnstsw ax"; break; }
            if (mop == 0 || mop == 4) {
                if (mop == 0 && m.reg == 2) { s = "fcom st(" + std::to_string(m.rm) + ")"; break; }
                if (mop == 0 && m.reg == 3) { s = "fcomp st(" + std::to_string(m.rm) + ")"; break; }
                if (mop == 0 && m.reg == 1) { s = "fmul st, st(" + std::to_string(m.rm) + ")"; break; }
                if (mop == 0) { s = "fadd st, st(" + std::to_string(m.rm) + ")"; break; }
                if (mop == 4 && m.reg == 0) { s = "fadd st(" + std::to_string(m.rm) + "), st"; break; }
                if (mop == 4 && m.reg == 1) { s = "fmul st(" + std::to_string(m.rm) + "), st"; break; }
                if (mop == 4 && m.reg == 2) { s = "fcom st(" + std::to_string(m.rm) + "), st"; break; }
                if (mop == 4 && m.reg == 3) { s = "fcomp st(" + std::to_string(m.rm) + ")"; break; }
                if (mop == 4) { s = "fop st(" + std::to_string(m.rm) + "), st"; break; }
            }
            if (mop == 1) {
                if (m.reg == 0) { s = "fld st(" + std::to_string(m.rm) + ")"; break; }
                if (m.reg == 1) { s = "fxch st(" + std::to_string(m.rm) + ")"; break; }
                if (m.reg == 2) { s = "fst st(" + std::to_string(m.rm) + ")"; break; }
                if (m.reg == 3) { s = "fstp st(" + std::to_string(m.rm) + ")"; break; }
            }
            if (mop == 5) {
                if (m.reg == 0) { s = "ffree st(" + std::to_string(m.rm) + ")"; break; }
                if (m.reg == 1) { s = "fxch st(" + std::to_string(m.rm) + ")"; break; }
                if (m.reg == 2) { s = "fst st(" + std::to_string(m.rm) + ")"; break; }
                if (m.reg == 3) { s = "fstp st(" + std::to_string(m.rm) + ")"; break; }
            }
            if (mop == 6) {
                if (m.reg == 0) { s = "faddp st(" + std::to_string(m.rm) + "), st"; break; }
                if (m.reg == 1) { s = "fmulp st(" + std::to_string(m.rm) + "), st"; break; }
                if (m.reg == 2) { s = "fcomp st(" + std::to_string(m.rm) + ")"; break; }
                if (m.reg == 3) { s = "fcompp"; break; }
                if (m.reg == 4) { s = "fsubp st(" + std::to_string(m.rm) + "), st"; break; }
                if (m.reg == 5) { s = "fsubrp st(" + std::to_string(m.rm) + "), st"; break; }
                if (m.reg == 6) { s = "fdivp st(" + std::to_string(m.rm) + "), st"; break; }
                if (m.reg == 7) { s = "fdivrp st(" + std::to_string(m.rm) + "), st"; break; }
            }
            s = "fpu";
        } else {
            switch (mop) {
            case 0: s = "fadd " + memText(c, m, segFS, "dword ptr"); break;
            case 1:
                if (m.reg == 0) s = "fld " + memText(c, m, segFS, "dword ptr");
                else if (m.reg == 2) s = "fst " + memText(c, m, segFS, "dword ptr");
                else if (m.reg == 3) s = "fstp " + memText(c, m, segFS, "dword ptr");
                else if (m.reg == 4) s = "fldenv " + memText(c, m, segFS, nullptr);
                else if (m.reg == 5) s = "fldcw " + memText(c, m, segFS, "word ptr");
                else if (m.reg == 6) s = "fnstenv " + memText(c, m, segFS, nullptr);
                else if (m.reg == 7) s = "fnstcw " + memText(c, m, segFS, "word ptr");
                else s = "fpu";
                break;
            case 2: case 6: s = "fimul " + memText(c, m, segFS, "word ptr"); s = std::string(mop == 2 ? "fi" : "fi") + (m.reg == 0 ? "add" : m.reg == 1 ? "mul" : m.reg == 2 ? "com" : m.reg == 3 ? "comp" : m.reg == 4 ? "sub" : m.reg == 5 ? "subr" : m.reg == 6 ? "div" : "divr") + " " + memText(c, m, segFS, "word ptr"); break;
            case 3:
                if (m.reg == 0) s = "fild " + memText(c, m, segFS, "dword ptr");
                else if (m.reg == 2) s = "fist " + memText(c, m, segFS, "dword ptr");
                else if (m.reg == 3) s = "fistp " + memText(c, m, segFS, "dword ptr");
                else if (m.reg == 5) s = "fld " + memText(c, m, segFS, "tbyte ptr");
                else if (m.reg == 7) s = "fstp " + memText(c, m, segFS, "tbyte ptr");
                else s = "fpu";
                break;
            case 4: {
                static const char* DC[8] = { "fadd", "fmul", "fcom", "fcomp", "fsub", "fsubr", "fdiv", "fdivr" };
                s = std::string(DC[m.reg]) + " " + memText(c, m, segFS, "qword ptr");
                break;
            }
            case 5:
                if (m.reg == 0) s = "fld " + memText(c, m, segFS, "qword ptr");
                else if (m.reg == 2) s = "fst " + memText(c, m, segFS, "qword ptr");
                else if (m.reg == 3) s = "fstp " + memText(c, m, segFS, "qword ptr");
                else if (m.reg == 4) s = "frstor " + memText(c, m, segFS, nullptr);
                else if (m.reg == 6) s = "fnsave " + memText(c, m, segFS, nullptr);
                else if (m.reg == 7) s = "fnstsw " + memText(c, m, segFS, "word ptr");
                else s = "fpu";
                break;
            case 7:
                if (m.reg == 0) s = "fild " + memText(c, m, segFS, "word ptr");
                else if (m.reg == 2) s = "fist " + memText(c, m, segFS, "word ptr");
                else if (m.reg == 3) s = "fistp " + memText(c, m, segFS, "word ptr");
                else if (m.reg == 5) s = "fild " + memText(c, m, segFS, "qword ptr");
                else if (m.reg == 7) s = "fistp " + memText(c, m, segFS, "qword ptr");
                else s = "fpu";
                break;
            default: s = "fpu";
            }
        }
        break;
    }
    case 0xE0: case 0xE1: case 0xE2: case 0xE3: {
        int v; if (!imm8s(v)) FAIL_UNKNOWN();
        branchTgt = va + i + v; hasBranch = true;
        if (out) s = std::string(op == 0xE0 ? "loopnz" : op == 0xE1 ? "loopz" : op == 0xE2 ? "loop" : "jecxz") + " short loc_" + c.addrName(branchTgt);
        break;
    }
    case 0xE4: { if (i + 1 > avail) FAIL_UNKNOWN(); u8 v = p[i]; i++; if (out) s = "in al, " + c.immHex(v); break; }
    case 0xE5: { if (i + 1 > avail) FAIL_UNKNOWN(); u8 v = p[i]; i++; if (out) s = "in eax, " + c.immHex(v); break; }
    case 0xE6: { if (i + 1 > avail) FAIL_UNKNOWN(); u8 v = p[i]; i++; if (out) s = "out " + c.immHex(v) + ", al"; break; }
    case 0xE7: { if (i + 1 > avail) FAIL_UNKNOWN(); u8 v = p[i]; i++; if (out) s = "out " + c.immHex(v) + ", eax"; break; }
    case 0xE8: {
        u32 v; if (!imm32v(v)) FAIL_UNKNOWN();
        u32 tgt = va + i + (i32)v;
        if (meta) { meta->isCall = true; meta->callTarget = tgt; }
        if (out) {
            const FuncInfo* tf = c.funcAt(tgt);
            if (tf && !tf->mangled.empty()) s = "call " + tf->mangled;
            else if (tf) s = "call " + tf->name;
            else s = "call sub_" + c.addrName(tgt);
        }
        break;
    }
    case 0xE9: {
        u32 v; if (!imm32v(v)) FAIL_UNKNOWN();
        u32 tgt = va + i + (i32)v;
        if (meta) { meta->isJmp = true; meta->branchTarget = tgt; }
        if (out) {
            const FuncInfo* tf = c.funcAt(tgt);
            if (tf) s = "jmp " + (!tf->mangled.empty() ? tf->mangled : tf->name);
            else s = "jmp loc_" + c.addrName(tgt);
        }
        break;
    }
    case 0xEA: { if (i + 6 > avail) FAIL_UNKNOWN(); i += 6; if (out) s = "jmp far"; break; }
    case 0xEB: {
        int v; if (!imm8s(v)) FAIL_UNKNOWN();
        u32 tgt = va + i + v;
        if (meta) { meta->isJmp = true; meta->branchTarget = tgt; }
        if (out) s = "jmp short loc_" + c.addrName(tgt);
        break;
    }
    case 0xEC: if (out) s = "in al, dx"; break;
    case 0xED: if (out) s = "in eax, dx"; break;
    case 0xEE: if (out) s = "out dx, al"; break;
    case 0xEF: if (out) s = "out dx, eax"; break;
    case 0xF4: if (out) s = "hlt"; break;
    case 0xF5: if (out) s = "cmc"; break;
    case 0xF6: case 0xF7: {
        if (!modrm()) FAIL_UNKNOWN();
        bool w8 = (op == 0xF6);
        if (m.reg == 0 || m.reg == 1) {
            if (w8) { int v; if (!imm8s(v)) FAIL_UNKNOWN(); if (out) s = "test " + rm8Text(c, m, segFS) + ", " + c.immHex((u32)(v & 0xFF)); }
            else { u32 v; if (!imm32v(v)) FAIL_UNKNOWN(); if (out) s = "test " + rm32Text(c, m, segFS) + ", " + c.immHex(v); }
        } else {
            static const char* G3[8] = { "test", "test", "not", "neg", "mul", "imul", "div", "idiv" };
            if (out) s = std::string(G3[m.reg]) + " " + (w8 ? rm8Text(c, m, segFS) : rm32Text(c, m, segFS));
        }
        break;
    }
    case 0xF8: if (out) s = "clc"; break;
    case 0xF9: if (out) s = "stc"; break;
    case 0xFA: if (out) s = "cli"; break;
    case 0xFB: if (out) s = "sti"; break;
    case 0xFC: if (out) s = "cld"; break;
    case 0xFD: if (out) s = "std"; break;
    case 0xFE: { if (!modrm()) FAIL_UNKNOWN(); if (out) s = std::string(m.reg == 0 ? "inc " : "dec ") + rm8Text(c, m, segFS); break; }
    case 0xFF: {
        if (!modrm()) FAIL_UNKNOWN();
        if (!out) break;
        switch (m.reg) {
        case 0: s = "inc " + rm32Text(c, m, segFS); break;
        case 1: s = "dec " + rm32Text(c, m, segFS); break;
        case 2:
            if (m.mod == 3) s = std::string("call ") + REG32[m.rm];
            else s = "call " + memText(c, m, segFS, "dword ptr");
            break;
        case 3: s = "call far " + memText(c, m, segFS, "fword ptr"); break;
        case 4:
            if (m.mod == 3) s = std::string("jmp ") + REG32[m.rm];
            else s = "jmp " + memText(c, m, segFS, "dword ptr");
            break;
        case 5: s = "jmp far " + memText(c, m, segFS, "fword ptr"); break;
        case 6: s = "push " + rm32Text(c, m, segFS); break;
        default: FAIL_UNKNOWN();
        }
        break;
    }
    case 0x0F: {
        if (i >= avail) FAIL_UNKNOWN();
        u8 op2 = p[i]; i++;
        bool rep = (prefixes == "rep ");
        bool repne = (prefixes == "repne ");
        switch (op2) {
        case 0x0B: if (out) s = "ud2"; break;
        case 0x10: case 0x11: {
            if (!modrm()) FAIL_UNKNOWN();
            if (!out) break;
            const char* mn2 = rep ? (o16 ? "movsd" : "movss") : repne ? "movsd" : (o16 ? "movupd" : "movups");
            std::string a1 = (m.mod == 3) ? xmmName(m.reg) : memText(c, m, segFS, nullptr);
            std::string a2 = (m.mod == 3) ? xmmName(m.rm) : memText(c, m, segFS, nullptr);
            s = std::string(mn2) + ((op2 == 0x10) ? " " + a1 + ", " + a2 : " " + a2 + ", " + a1);
            break;
        }
        case 0x28: case 0x29: {
            if (!modrm()) FAIL_UNKNOWN();
            if (!out) break;
            const char* mn2 = o16 ? "movapd" : "movaps";
            std::string a1 = (m.mod == 3) ? xmmName(m.reg) : memText(c, m, segFS, nullptr);
            std::string a2 = (m.mod == 3) ? xmmName(m.rm) : memText(c, m, segFS, nullptr);
            s = std::string(mn2) + ((op2 == 0x28) ? " " + a1 + ", " + a2 : " " + a2 + ", " + a1);
            break;
        }
        case 0x2A: { if (!modrm()) FAIL_UNKNOWN(); if (!out) break; s = std::string(rep ? "cvtsi2ss" : repne ? "cvtsi2sd" : "cvtsi2ss") + " " + xmmName(m.reg) + ", " + ((m.mod == 3) ? REG32[m.rm] : memText(c, m, segFS, "dword ptr")); break; }
        case 0x2C: { if (!modrm()) FAIL_UNKNOWN(); if (!out) break; s = std::string(rep ? "cvttss2si" : repne ? "cvttsd2si" : "cvttps2pi") + " " + REG32[m.reg] + ", " + ((m.mod == 3) ? xmmName(m.rm) : memText(c, m, segFS, nullptr)); break; }
        case 0x2D: { if (!modrm()) FAIL_UNKNOWN(); if (!out) break; s = std::string(rep ? "cvtss2si" : repne ? "cvtsd2si" : "cvtps2pi") + " " + REG32[m.reg] + ", " + ((m.mod == 3) ? xmmName(m.rm) : memText(c, m, segFS, nullptr)); break; }
        case 0x2E: case 0x2F: { if (!modrm()) FAIL_UNKNOWN(); if (!out) break; s = std::string(o16 ? (op2 == 0x2E ? "ucomisd" : "comisd") : (op2 == 0x2E ? "ucomiss" : "comiss")) + " " + xmmName(m.reg) + ", " + ((m.mod == 3) ? xmmName(m.rm) : memText(c, m, segFS, nullptr)); break; }
        case 0x31: if (out) s = "rdtsc"; break;
        case 0x40: case 0x41: case 0x42: case 0x43: case 0x44: case 0x45: case 0x46: case 0x47:
        case 0x48: case 0x49: case 0x4A: case 0x4B: case 0x4C: case 0x4D: case 0x4E: case 0x4F: {
            if (!modrm()) FAIL_UNKNOWN();
            if (out) s = std::string("cmov") + CCN[op2 - 0x40] + " " + REG32[m.reg] + ", " + rm32Text(c, m, segFS);
            break;
        }
        case 0x51: { if (!modrm()) FAIL_UNKNOWN(); if (!out) break; s = std::string(rep ? "sqrtss" : repne ? "sqrtsd" : o16 ? "sqrtpd" : "sqrtps") + " " + xmmName(m.reg) + ", " + ((m.mod == 3) ? xmmName(m.rm) : memText(c, m, segFS, nullptr)); break; }
        case 0x54: case 0x55: case 0x56: case 0x57: {
            if (!modrm()) FAIL_UNKNOWN();
            if (!out) break;
            const char* mn2 = op2 == 0x54 ? (o16 ? "andpd" : "andps") : op2 == 0x55 ? (o16 ? "andnpd" : "andnps") : op2 == 0x56 ? (o16 ? "orpd" : "orps") : (o16 ? "xorpd" : "xorps");
            s = std::string(mn2) + " " + xmmName(m.reg) + ", " + ((m.mod == 3) ? xmmName(m.rm) : memText(c, m, segFS, nullptr));
            break;
        }
        case 0x58: case 0x59: case 0x5A: case 0x5B: case 0x5C: case 0x5D: case 0x5E: case 0x5F: {
            if (!modrm()) FAIL_UNKNOWN();
            if (!out) break;
            static const char* SSE[8] = { "add", "mul", "cvt", "cvt", "sub", "min", "div", "max" };
            std::string mn2;
            if (op2 == 0x5A) mn2 = rep ? "cvtss2sd" : repne ? "cvtsd2ss" : o16 ? "cvtpd2ps" : "cvtps2pd";
            else if (op2 == 0x5B) mn2 = o16 ? "cvtdq2pd" : "cvtdq2ps";
            else {
                mn2 = std::string(SSE[op2 - 0x58]) + (rep ? "ss" : repne ? "sd" : o16 ? "pd" : "ps");
                if (!rep && !repne && !o16 && (op2 == 0x5A || op2 == 0x5B)) mn2 = "cvtops";
            }
            s = mn2 + " " + xmmName(m.reg) + ", " + ((m.mod == 3) ? xmmName(m.rm) : memText(c, m, segFS, nullptr));
            break;
        }
        case 0x6E: { if (!modrm()) FAIL_UNKNOWN(); if (!out) break; s = "movd " + xmmName(m.reg) + ", " + ((m.mod == 3) ? REG32[m.rm] : memText(c, m, segFS, "dword ptr")); break; }
        case 0x6F: { if (!modrm()) FAIL_UNKNOWN(); if (!out) break; s = std::string(rep ? "movdqu" : o16 ? "movdqa" : "movq") + " " + xmmName(m.reg) + ", " + ((m.mod == 3) ? mmName(m.rm) : memText(c, m, segFS, nullptr)); break; }
        case 0x7E: { if (!modrm()) FAIL_UNKNOWN(); if (!out) break; s = std::string(rep ? "movq" : "movd") + " " + ((m.mod == 3) ? xmmName(m.rm) : memText(c, m, segFS, "dword ptr")) + ", " + ((m.mod == 3) ? xmmName(m.reg) : REG32[m.reg]); break; }
        case 0x7F: { if (!modrm()) FAIL_UNKNOWN(); if (!out) break; s = std::string(rep ? "movdqu" : o16 ? "movdqa" : "movq") + " " + ((m.mod == 3) ? mmName(m.rm) : memText(c, m, segFS, nullptr)) + ", " + xmmName(m.reg); break; }
        case 0x80: case 0x81: case 0x82: case 0x83: case 0x84: case 0x85: case 0x86: case 0x87:
        case 0x88: case 0x89: case 0x8A: case 0x8B: case 0x8C: case 0x8D: case 0x8E: case 0x8F: {
            u32 v; if (!imm32v(v)) FAIL_UNKNOWN();
            u32 tgt = va + i + (i32)v;
            if (meta) { meta->isJmp = (op2 == 0xE9 || op2 == 0x80 + 4); meta->branchTarget = tgt; }
            if (out) {
                if (op2 == 0xE9) s = "jmp loc_" + c.addrName(tgt);
                else s = std::string("j") + CCN[op2 - 0x80] + " loc_" + c.addrName(tgt);
            }
            break;
        }
        case 0x90: case 0x91: case 0x92: case 0x93: case 0x94: case 0x95: case 0x96: case 0x97:
        case 0x98: case 0x99: case 0x9A: case 0x9B: case 0x9C: case 0x9D: case 0x9E: case 0x9F: {
            if (!modrm()) FAIL_UNKNOWN();
            if (out) s = std::string("set") + CCN[op2 - 0x90] + " " + rm8Text(c, m, segFS);
            break;
        }
        case 0xA2: if (out) s = "cpuid"; break;
        case 0xA3: { if (!modrm()) FAIL_UNKNOWN(); if (out) s = "bt " + rm32Text(c, m, segFS) + ", " + REG32[m.reg]; break; }
        case 0xA4: { if (!modrm()) FAIL_UNKNOWN(); int v; if (!imm8s(v)) FAIL_UNKNOWN(); if (out) s = "shld " + rm32Text(c, m, segFS) + ", " + REG32[m.reg] + ", " + c.immHex((u32)(v & 0xFF)); break; }
        case 0xA5: { if (!modrm()) FAIL_UNKNOWN(); if (out) s = "shld " + rm32Text(c, m, segFS) + ", " + REG32[m.reg] + ", cl"; break; }
        case 0xA8: if (out) s = "push gs"; break;
        case 0xA9: if (out) s = "pop gs"; break;
        case 0xAB: { if (!modrm()) FAIL_UNKNOWN(); if (out) s = "bts " + rm32Text(c, m, segFS) + ", " + REG32[m.reg]; break; }
        case 0xAC: { if (!modrm()) FAIL_UNKNOWN(); int v; if (!imm8s(v)) FAIL_UNKNOWN(); if (out) s = "shrd " + rm32Text(c, m, segFS) + ", " + REG32[m.reg] + ", " + c.immHex((u32)(v & 0xFF)); break; }
        case 0xAD: { if (!modrm()) FAIL_UNKNOWN(); if (out) s = "shrd " + rm32Text(c, m, segFS) + ", " + REG32[m.reg] + ", cl"; break; }
        case 0xAF: { if (!modrm()) FAIL_UNKNOWN(); if (out) s = "imul " + std::string(REG32[m.reg]) + ", " + rm32Text(c, m, segFS); if (meta) meta->dstReg32 = (int)m.reg; break; }
        case 0xB0: { if (!modrm()) FAIL_UNKNOWN(); if (out) s = "cmpxchg " + rm8Text(c, m, segFS) + ", " + REG8[m.reg]; break; }
        case 0xB1: { if (!modrm()) FAIL_UNKNOWN(); if (out) s = "cmpxchg " + rm32Text(c, m, segFS) + ", " + REG32[m.reg]; break; }
        case 0xB2: { if (!modrm()) FAIL_UNKNOWN(); if (out) s = "lss " + std::string(REG32[m.reg]) + ", " + memText(c, m, segFS, "fword ptr"); break; }
        case 0xB3: { if (!modrm()) FAIL_UNKNOWN(); if (out) s = "btr " + rm32Text(c, m, segFS) + ", " + REG32[m.reg]; break; }
        case 0xB4: { if (!modrm()) FAIL_UNKNOWN(); if (out) s = "lfs " + std::string(REG32[m.reg]) + ", " + memText(c, m, segFS, "fword ptr"); break; }
        case 0xB5: { if (!modrm()) FAIL_UNKNOWN(); if (out) s = "lgs " + std::string(REG32[m.reg]) + ", " + memText(c, m, segFS, "fword ptr"); break; }
        case 0xB6: { if (!modrm()) FAIL_UNKNOWN(); if (out) s = "movzx " + std::string(REG32[m.reg]) + ", " + rm8Text(c, m, segFS); break; }
        case 0xB7: { if (!modrm()) FAIL_UNKNOWN(); if (out) s = "movzx " + std::string(REG32[m.reg]) + ", " + rm16Text(c, m, segFS); break; }
        case 0xBA: {
            if (!modrm()) FAIL_UNKNOWN();
            int v; if (!imm8s(v)) FAIL_UNKNOWN();
            static const char* BT[8] = { "", "", "", "", "bt", "bts", "btr", "btc" };
            if (m.reg >= 4) { if (out) s = std::string(BT[m.reg]) + " " + rm32Text(c, m, segFS) + ", " + c.immHex((u32)(v & 0xFF)); }
            else FAIL_UNKNOWN();
            break;
        }
        case 0xBB: { if (!modrm()) FAIL_UNKNOWN(); if (out) s = "btc " + rm32Text(c, m, segFS) + ", " + REG32[m.reg]; break; }
        case 0xBC: { if (!modrm()) FAIL_UNKNOWN(); if (out) s = "bsf " + std::string(REG32[m.reg]) + ", " + rm32Text(c, m, segFS); break; }
        case 0xBD: { if (!modrm()) FAIL_UNKNOWN(); if (out) s = "bsr " + std::string(REG32[m.reg]) + ", " + rm32Text(c, m, segFS); break; }
        case 0xBE: { if (!modrm()) FAIL_UNKNOWN(); if (out) s = "movsx " + std::string(REG32[m.reg]) + ", " + rm8Text(c, m, segFS); break; }
        case 0xBF: { if (!modrm()) FAIL_UNKNOWN(); if (out) s = "movsx " + std::string(REG32[m.reg]) + ", " + rm16Text(c, m, segFS); break; }
        case 0xC0: { if (!modrm()) FAIL_UNKNOWN(); if (out) s = "xadd " + rm8Text(c, m, segFS) + ", " + REG8[m.reg]; break; }
        case 0xC1: { if (!modrm()) FAIL_UNKNOWN(); if (out) s = "xadd " + rm32Text(c, m, segFS) + ", " + REG32[m.reg]; break; }
        case 0xC2: case 0xC6: { if (!modrm()) FAIL_UNKNOWN(); int v; if (!imm8s(v)) FAIL_UNKNOWN(); if (out) s = std::string(op2 == 0xC2 ? (rep ? "cmpss" : repne ? "cmpsd" : o16 ? "cmppd" : "cmpps") : (o16 ? "shufpd" : "shufps")) + " " + xmmName(m.reg) + ", " + ((m.mod == 3) ? xmmName(m.rm) : memText(c, m, segFS, nullptr)) + ", " + c.immHex((u32)(v & 0xFF)); break; }
        case 0xC8: case 0xC9: case 0xCA: case 0xCB: case 0xCC: case 0xCD: case 0xCE: case 0xCF:
            if (out) s = std::string("bswap ") + REG32[op2 - 0xC8]; break;
        case 0xEF: { if (!modrm()) FAIL_UNKNOWN(); if (out) s = "pxor " + mmName(m.reg) + ", " + ((m.mod == 3) ? mmName(m.rm) : memText(c, m, segFS, nullptr)); break; }
        default: FAIL_UNKNOWN();
        }
        break;
    }
    default: FAIL_UNKNOWN();
    }

emit:
    if (meta && hasBranch) meta->branchTarget = branchTgt;
    if (out) {
        if (!prefixes.empty() && op != 0xA4 && op != 0xA5 && op != 0xA6 && op != 0xA7 &&
            op != 0xAA && op != 0xAB && op != 0xAC && op != 0xAD && op != 0xAE && op != 0xAF &&
            !(op == 0x0F)) {
            // string talimatlari icinde prefix zaten birlesti
            bool isStrOp = (op >= 0xA4 && op <= 0xAF);
            if (!isStrOp && !s.empty()) s = prefixes + s;
        }
        *out = s.empty() ? std::string("db ") + c.immHex(p[0]) : substituteThis(s, c.thisNameRegs);
        if (s.empty()) return 1;
    }
    return (i > 0) ? i : 1;
#undef FAIL_UNKNOWN
}

// bayt gostermesi (--bytes ile acilir)
static bool g_showBytes = false;
void setShowBytes(bool b) { g_showBytes = b; }

// va -> ".text:004D7610" biciminde adres etiketi
static std::string addrLine(const PE* pe, u32 va) {
    std::string sec;
    if (pe) {
        u32 base = pe->imageBase;
        for (auto& s : pe->secs) {
            u32 hi = s.va + (s.vsz > s.rsz ? s.vsz : s.rsz);
            if (va >= base + s.va && va < base + hi) { sec = s.name; break; }
        }
    }
    char b[24];
    snprintf(b, sizeof b, "%08X", va);
    if (!sec.empty()) return sec + ":" + b;
    return std::string(b);
}

// IDA tarzi etiket: shortName (yoksa decorli isim)
static std::string labelOf(const FuncInfo& f) {
    if (!f.shortName.empty()) return f.shortName;
    return !f.name.empty() ? f.name : f.mangled;
}

// cagri yorumu: "Cls::Fn(int,void *)" (IDA tarzi kisa bicim)
static std::string callComment(const PdbData& pdb, const FuncInfo& tf) {
    if (!tf.hasType) return labelOf(tf);
    const TypeRec* t = pdb.type(tf.tidx);
    if (!t || (t->leaf != 0x1009 && t->leaf != 0x1008)) return labelOf(tf);
    const TypeRec* al = pdb.type(t->arglist);
    std::vector<u32> ats;
    if (al && al->leaf == 0x1201) ats = al->args;
    size_t start = (t->leaf == 0x1009 && ats.size() == (size_t)t->nparams + 1) ? 1 : 0;
    std::string args;
    for (size_t i = start; i < ats.size(); i++) {
        if (i > start) args += ",";
        args += pdb.typeName(ats[i]);
    }
    if (ats.empty()) args = "void";
    return labelOf(tf) + "(" + args + ")";
}

struct XrefHit { u32 from = 0; char kind = 'p'; };

// calistirilabilir kesimlerde E8/E9 taramasi -> hedefe giden xref listesi
static void collectXrefs(const PdbData& pdb, const PE& pe, u32 target, std::vector<XrefHit>& out) {
    (void)pdb;
    out.clear();
    for (auto& s : pe.secs) {
        if (!(s.chars & 0x20000000)) continue;      // IMAGE_SCN_MEM_EXECUTE
        u32 n = s.rsz < s.vsz ? s.rsz : s.vsz;
        if (n < 5) continue;
        const u8* p = pe.ptr(pe.imageBase + s.va, n);
        if (!p) continue;
        u32 base = pe.imageBase + s.va;
        for (u32 i = 0; i + 5 <= n; i++) {
            if (p[i] != 0xE8 && p[i] != 0xE9) continue;
            i32 rel = rdi32(p + i + 1);
            u32 tgt = base + i + 5 + (u32)rel;
            if (tgt == target) {
                XrefHit h; h.from = base + i; h.kind = (p[i] == 0xE8) ? 'p' : 'j';
                out.push_back(h);
                if (out.size() >= 16) return;
            }
        }
    }
}

// verilen VA'yi iceren fonksiyon (funcs va'ya gore sirali)
static const FuncInfo* funcContaining(const PdbData& pdb, u32 va) {
    size_t lo = 0, hi = pdb.funcs.size();
    while (lo < hi) {
        size_t mid = (lo + hi) / 2;
        if (pdb.funcs[mid].va <= va) lo = mid + 1;
        else hi = mid;
    }
    if (lo == 0) return nullptr;
    const FuncInfo& f = pdb.funcs[lo - 1];
    if (va < f.va + (f.size ? f.size : 1)) return &f;
    return nullptr;
}

// stack var tipi: UDT adi ya da byte/word/dword/qword
static std::string ptrTypeFor(const PdbData& pdb, u32 tidx, std::string& udtName) {
    udtName.clear();
    const TypeRec* ct = pdb.completeType(tidx);
    if (ct && ct->valid && !ct->name.empty() &&
        (ct->leaf == 0x1504 || ct->leaf == 0x1505 || ct->leaf == 0x1506 || ct->leaf == 0x1507)) {
        udtName = ct->name;
        return "";
    }
    u64 sz = 4;
    if (ct && ct->sizeKnown && ct->size) sz = ct->size;
    else if (tidx < 0x1000) {
        u32 mode = (tidx >> 8) & 0xFF;
        if (mode) sz = 4;
        else {
            switch (tidx & 0xFF) {
            case 0x10: case 0x20: case 0x30: case 0x68: case 0x69: case 0x70: sz = 1; break;
            case 0x11: case 0x21: case 0x71: case 0x72: case 0x73: sz = 2; break;
            case 0x12: case 0x22: case 0x40: case 0x74: case 0x75: sz = 4; break;
            case 0x13: case 0x23: case 0x41: case 0x76: case 0x77: sz = 8; break;
            default: sz = 4;
            }
        }
    }
    return sz == 1 ? "byte" : sz == 2 ? "word" : sz == 8 ? "qword" : "dword";
}

// mnemonic kolonu: ilk sozcugu 7 genislikte padle, gerisi tek boslukla gelir
static std::string padMnem(const std::string& t) {
    size_t sp = t.find(' ');
    if (sp == std::string::npos) {
        std::string r = t;
        while (r.size() < 8) r += ' ';
        return r;
    }
    std::string mn = t.substr(0, sp);
    std::string rest = t.substr(sp);
    while (mn.size() < 7) mn += ' ';
    return mn + rest;
}

// fonksiyonun tamamini cozup IDA benzeri metin uretir
std::string disassemble(const PdbData& pdb, const PE* pe, const FuncInfo& fn) {
    Ctx c;
    c.pdb = &pdb;
    c.pe = pe;
    c.fn = &fn;
    if (fn.isThiscall && fn.thisClassIdx) {
        c.thisClass = fn.thisClassIdx;
        c.thisRegs.insert(1); // ecx (x86 indeks) - CV reg 18 = ecx
        c.thisNameRegs.insert(1);
    }
    u32 va = fn.va, sz = fn.size;
    if (!pe || !sz || !pe->read(va, nullptr, 0) || sz > (4 << 20)) return "; kod okunamadi (exe gerekli)\n";
    std::vector<u8> code(sz);
    if (!pe->read(va, code.data(), sz)) return "; kod okunamadi\n";

    std::string label = !fn.mangled.empty() ? fn.mangled : fn.name;
    std::string addr0 = addrLine(pe, va);

    // XREF'ler (baska fonksiyonlardan gelen call/jmp)
    std::vector<XrefHit> xr;
    collectXrefs(pdb, *pe, va, xr);

    // 1. gecis: uzunluklar + etiketler + this takibi
    std::vector<std::pair<u32, size_t>> insns; // va, len
    std::set<u32> labels;
    {
        std::unordered_set<int> thisRegs = c.thisRegs;
        size_t q = 0;
        int guard = 0;
        while (q < sz && guard++ < 1000000) {
            u32 ia = va + (u32)q;
            std::string tmp;
            InsMeta meta;
            size_t len = decode(c, code.data() + q, sz - q, ia, &tmp, &meta);
            if (len == 0) len = 1;
            insns.push_back({ ia, len });
            if (meta.branchTarget >= va && meta.branchTarget < va + sz)
                labels.insert(meta.branchTarget);
            if (meta.isMov && meta.srcReg32 >= 0 && thisRegs.count((unsigned)meta.srcReg32) && meta.dstReg32 >= 0)
                thisRegs.insert((unsigned)meta.dstReg32);
            q += len;
        }
        c.thisRegs = thisRegs;
    }

    // ---- metin uretimi (IDA bicimi) ----
    std::string out;
    out += addr0 + " ; " + fn.proto + "\n";
    out += addr0 + " " + label + " proc near\n";
    for (auto& x : xr) {
        const FuncInfo* cf = funcContaining(pdb, x.from);
        if (!cf) continue;
        char xb[200];
        snprintf(xb, sizeof xb, "%s+%X%c", labelOf(*cf).c_str(), x.from - cf->va, x.kind);
        out += addr0 + "                                        ; CODE XREF: " + xb + "\n";
    }
    // degisken bildirimleri (IDA tarzi)
    {
        std::vector<const LocalVar*> vs;
        std::set<i32> seenOff;
        for (auto& v : fn.locals) {
            if (v.isReg || v.off == 0x7FFFFFFF) continue;
            if (!seenOff.insert(v.off).second) continue;
            vs.push_back(&v);
        }
        std::sort(vs.begin(), vs.end(), [](const LocalVar* a, const LocalVar* b) {
            if ((a->off < 0) != (b->off < 0)) return a->off < 0;
            return a->off < b->off;
        });
        for (auto* pv : vs) {
            const LocalVar& v = *pv;
            std::string udt;
            std::string tn = ptrTypeFor(pdb, v.tidx, udt);
            char offB[16];
            if (v.off >= 0) snprintf(offB, sizeof offB, "%X", (u32)v.off);
            else snprintf(offB, sizeof offB, "-%X", (u32)(-v.off));
            std::string offS = offB;
            while (offS.size() < 3) offS = " " + offS;
            std::string nm = v.name;
            if (nm.size() < 16) nm += std::string(16 - nm.size(), ' ');
            const char* tp = udt.empty() ? tn.c_str() : udt.c_str();
            out += addr0 + " " + nm + "= " + tp + " ptr " + offS + "\n";
        }
        if (fn.isThiscall) {
            out += addr0 + " this            = ecx\n";
        }
        out += addr0 + "\n";
    }
    {
        std::unordered_set<int> thisRegs = c.thisRegs;
        size_t q = 0;
        int guard = 0;
        for (size_t k = 0; k < insns.size() && guard++ < 1000000; k++) {
            u32 ia = insns[k].first;
            size_t len = insns[k].second;
            if (labels.count(ia))
                out += addrLine(pe, ia) + " loc_" + c.addrName(ia) + ":\n";
            std::string text;
            InsMeta meta;
            if (q + len <= sz)
                decode(c, code.data() + q, len, ia, &text, &meta);
            else
                text = "db ?";
            if (meta.isMov && meta.srcReg32 >= 0 && thisRegs.count((unsigned)meta.srcReg32) && meta.dstReg32 >= 0)
                thisRegs.insert((unsigned)meta.dstReg32);
            if (g_showBytes) {
                // eski bicim: adres + baytlar + metin
                char line[64];
                snprintf(line, sizeof line, "%08X  ", ia);
                out += line;
                char by[80]; int bo = 0;
                for (size_t z = 0; z < len && z < 8 && q + z < sz; z++) bo += snprintf(by + bo, sizeof by - bo, "%02X ", code[q + z]);
                if (len > 8) bo += snprintf(by + bo, sizeof by - bo, "...  ");
                out += std::string(by, (size_t)bo);
                for (int zz = bo; zz < 26; zz++) out += ' ';
                out += text;
                if (!meta.comment.empty()) out += "   ; " + meta.comment;
                if (meta.isCall && meta.callTarget) {
                    auto it = pdb.funcByVa.find(meta.callTarget);
                    if (it != pdb.funcByVa.end())
                        out += "   ; " + pdb.fullProto(pdb.funcs[it->second], false);
                }
                out += "\n";
            } else {
                // IDA bicimi: .text:004D7610                  push    ebp
                std::string line = addrLine(pe, ia) + std::string(18, ' ') + padMnem(text);
                if (!meta.comment.empty()) line += " ; " + meta.comment;
                if (meta.isCall && meta.callTarget) {
                    auto it = pdb.funcByVa.find(meta.callTarget);
                    if (it != pdb.funcByVa.end())
                        line += " ; " + callComment(pdb, pdb.funcs[it->second]);
                }
                out += line + "\n";
            }
            q += len;
        }
        (void)thisRegs;
    }
    out += addrLine(pe, va + sz - 1) + " " + label + " endp\n";
    return out;
}

// ------------------------------------------------ tum-program cagri haritasi
std::string funcLabel(const FuncInfo& f) {
    if (!f.shortName.empty()) return f.shortName;
    return !f.name.empty() ? f.name : f.mangled;
}

const FuncInfo* findFuncContaining(const PdbData& pdb, u32 va) {
    return funcContaining(pdb, va);
}

// her fonksiyonu dogru cozumleme ile gezip call/jmp siteleri toplar (tek thread, onbellekli)
const std::vector<CallSite>& callSites(const PdbData& pdb, const PE& pe) {
    static std::vector<CallSite> g_sites;
    static const PdbData* g_pdb = nullptr;
    static const PE* g_pe = nullptr;
    if (g_pdb == &pdb && g_pe == &pe) return g_sites;
    g_pdb = &pdb; g_pe = &pe;
    g_sites.clear();
    g_sites.reserve(1 << 16);

    Ctx c;
    c.pdb = &pdb;
    c.pe = &pe;
    c.fn = nullptr;

    std::vector<u8> code;
    for (auto& f : pdb.funcs) {
        if (!f.size || f.size > (4 << 20)) continue;
        code.resize(f.size);
        if (!pe.read(f.va, code.data(), f.size)) continue;
        size_t q = 0;
        int guard = 0;
        while (q < f.size && guard++ < 400000) {
            InsMeta meta;
            size_t len = decode(c, code.data() + q, f.size - q, f.va + (u32)q, nullptr, &meta);
            if (len == 0) len = 1;
            if (meta.isCall && meta.callTarget) {
                CallSite s; s.site = f.va + (u32)q; s.target = meta.callTarget; s.kind = 'p';
                g_sites.push_back(s);
            } else if (meta.isJmp && meta.branchTarget && pdb.funcByVa.count(meta.branchTarget)) {
                CallSite s; s.site = f.va + (u32)q; s.target = meta.branchTarget; s.kind = 'j';
                g_sites.push_back(s);
            }
            q += len;
        }
    }
    return g_sites;
}

} // namespace disasm
