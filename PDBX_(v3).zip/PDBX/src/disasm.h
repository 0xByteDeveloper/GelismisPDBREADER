// PDBX disassembler arayuzu
#pragma once
#include "pdbx.h"
#include <utility>
namespace disasm {
std::string disassemble(const PdbData& pdb, const PE* pe, const FuncInfo& fn);
void setShowBytes(bool b);   // --bytes: satirlarda makine kodu baytlarini da goster

// dogru cozumleme ile cikarilan cagri/ziplama siteleri (web GUI icin)
struct CallSite { u32 site = 0; u32 target = 0; char kind = 'p'; };  // kind: 'p'=call, 'j'=jmp (kuyruk cagri)
// tembel kurulan, onbelleklenen tum-program cagri haritasi (tek thread!)
const std::vector<CallSite>& callSites(const PdbData& pdb, const PE& pe);

// va'yi iceren fonksiyon (yoksa nullptr)
const FuncInfo* findFuncContaining(const PdbData& pdb, u32 va);

// gosterim etiketi: shortName > name > mangled
std::string funcLabel(const FuncInfo& f);
}
