// PDBX web sunucusu: localhost HTTP + JSON API (gomulu arayuz webui.h)
// Windows: winsock2 | Linux: POSIX socket (test icin)
#include "pdbx.h"
#include "disasm.h"
#include "webui.h"
#include <cstdio>
#include <cctype>

#ifdef _WIN32
#  define WIN32_LEAN_AND_MEAN
#  include <winsock2.h>
#  include <ws2tcpip.h>
#  pragma comment(lib, "ws2_32.lib")
#else
#  include <sys/socket.h>
#  include <netinet/in.h>
#  include <arpa/inet.h>
#  include <unistd.h>
#  include <signal.h>
#  include <sys/time.h>
typedef int SOCKET;
#  define INVALID_SOCKET (-1)
#  define SOCKET_ERROR   (-1)
#  define closesocket(s) close(s)
#endif

// ------------------------------------------------- JSON yardimcilari
static void jesc(std::string& o, const std::string& s) {
    for (unsigned char c : s) {
        switch (c) {
        case '"':  o += "\\\""; break;
        case '\\': o += "\\\\"; break;
        case '\n': o += "\\n";  break;
        case '\r': o += "\\r";  break;
        case '\t': o += "\\t";  break;
        default:
            if (c < 0x20) { char b[8]; snprintf(b, sizeof b, "\\u%04X", c); o += b; }
            else o += (char)c;
        }
    }
}
static std::string Jstr(const std::string& s) { std::string r = "\""; jesc(r, s); r += "\""; return r; }
static std::string Jnum(long long v) { char b[32]; snprintf(b, sizeof b, "%lld", v); return b; }

// ------------------------------------------------- sunucu durumu
namespace {
struct UdtEntry {
    const TypeRec* t = nullptr;
    const char* kind = "struct";
};
struct SrvState {
    PdbData* pdb = nullptr;
    const PE* pe = nullptr;
    std::string pdbName, exeName;
    std::vector<StrLit> strings;
    bool stringsDone = false;
    std::vector<UdtEntry> udts;
    bool udtsDone = false;
    // hedef bazinda toplu cagri sayilari
    struct XrefAgg { u32 target; u32 count; };
    std::vector<XrefAgg> xagg;
    bool xaggDone = false;

    void ensureUdts() {
        if (udtsDone) return;
        udtsDone = true;
        std::unordered_map<std::string, size_t> byName;
        for (auto& kv : pdb->types) {
            const TypeRec& t = kv.second;
            if (t.name.empty()) continue;
            if (t.leaf != 0x1504 && t.leaf != 0x1505 && t.leaf != 0x1506 && t.leaf != 0x1507) continue;
            bool bad = false;
            for (unsigned char c : t.name) if (c < 0x20) { bad = true; break; }
            if (bad) continue;                                    // bozuk/kontrol karakterli ad
            auto it = byName.find(t.name);
            if (it == byName.end()) {
                byName[t.name] = udts.size();
                UdtEntry e; e.t = &t;
                e.kind = t.leaf == 0x1504 ? "class" : t.leaf == 0x1505 ? "struct" : t.leaf == 0x1506 ? "union" : "enum";
                udts.push_back(e);
            } else {
                const TypeRec* cur = udts[it->second].t;
                if (t.members.size() > cur->members.size()) udts[it->second].t = &t;
            }
        }
        std::sort(udts.begin(), udts.end(), [](const UdtEntry& a, const UdtEntry& b) {
            int c = lowerDup(a.t->name).compare(lowerDup(b.t->name));
            if (c) return c < 0;
            return a.t < b.t;
        });
    }
    void ensureStrings() {
        if (stringsDone) return;
        stringsDone = true;
        if (pe) strings = scanStrings(*pe, 60000);
    }
    void ensureXagg() {
        if (xaggDone) return;
        xaggDone = true;
        if (!pe) return;
        const auto& cs = disasm::callSites(*pdb, *pe);
        std::unordered_map<u32, u32> cnt;
        for (auto& s : cs) if (s.kind == 'p') cnt[s.target]++;
        xagg.reserve(cnt.size());
        for (auto& kv : cnt) xagg.push_back({ kv.first, kv.second });
        std::sort(xagg.begin(), xagg.end(), [](const XrefAgg& a, const XrefAgg& b) {
            if (a.count != b.count) return a.count > b.count;
            return a.target < b.target;
        });
    }
    size_t countKinds(const char* k) {
        size_t n = 0;
        for (auto& u : udts) if (!strcmp(u.kind, k)) n++;
        return n;
    }
};
} // namespace

static std::string lowerCopy(const std::string& s) { return lowerDup(s); }

// ------------------------------------------------- liste ucretlendirici
// jenerik satir: {"kind","name","va","size","extra","count"}
typedef std::function<void(const std::string& kind, const std::string& name, u32 va, u32 size, const std::string& extra, u32 count)> ItemSink;

struct Pager {
    size_t skip, limit;
    size_t total = 0;
    std::string body;
    bool first = true;
    ItemSink emit;
    Pager(size_t o, size_t n) : skip(o), limit(n) {
        emit = [this](const std::string& kind, const std::string& name, u32 va, u32 size, const std::string& extra, u32 count) {
            total++;
            if (total - 1 < skip) return;
            if (total - 1 >= skip + limit) return;
            if (!first) body += ",";
            first = false;
            body += "{\"kind\":" + Jstr(kind) + ",\"name\":" + Jstr(name) + ",\"va\":" + Jnum(va) +
                    ",\"size\":" + Jnum(size) + ",\"extra\":" + Jstr(extra) + ",\"count\":" + Jnum(count) + "}";
        };
    }
};

static bool matchQ(const std::string& q, const std::string& a, const std::string& b = "", const std::string& c = "") {
    if (q.empty()) return true;
    return lowerDup(a).find(q) != std::string::npos ||
           (!b.empty() && lowerDup(b).find(q) != std::string::npos) ||
           (!c.empty() && lowerDup(c).find(q) != std::string::npos);
}

static void collectItems(SrvState& st, const std::string& cat, const std::string& q, Pager& pg) {
    PdbData& pdb = *st.pdb;
    if (cat == "func" || cat == "all") {
        for (auto& f : pdb.funcs) {
            std::string lbl = disasm::funcLabel(f);
            if (!matchQ(q, lbl, f.name, f.mangled)) continue;
            pg.emit("func", lbl, f.va, f.size, f.proto, 0);
        }
    }
    if (cat == "class" || cat == "struct" || cat == "enum" || cat == "all") {
        st.ensureUdts();
        bool wantAll = (cat == "all");
        for (auto& u : st.udts) {
            if (!wantAll && strcmp(u.kind, cat.c_str()) != 0) continue;
            if (!matchQ(q, u.t->name)) continue;
            char ex[64];
            snprintf(ex, sizeof ex, "%zu uye", u.t->members.size() + u.t->evals.size());
            pg.emit(strcmp(u.kind, "class") == 0 ? "class" : u.kind, u.t->name, 0, (u32)u.t->size, ex, 0);
        }
    }
    if (cat == "static" || cat == "all") {
        for (auto& g : pdb.globals) {
            if (!matchQ(q, g.name)) continue;
            pg.emit("static", g.name, g.va, 0, pdb.typeName(g.tidx), 0);
        }
    }
    if (cat == "string") {
        st.ensureStrings();
        for (auto& s : st.strings) {
            if (!matchQ(q, s.label, s.text)) continue;
            pg.emit("string", s.label, s.va, (u32)s.text.size(), s.text, 0);
        }
    }
    if (cat == "xref") {
        st.ensureXagg();
        for (auto& x : st.xagg) {
            const FuncInfo* tf = nullptr;
            auto it = pdb.funcByVa.find(x.target);
            if (it != pdb.funcByVa.end()) tf = &pdb.funcs[it->second];
            std::string lbl = tf ? disasm::funcLabel(*tf) : ("sub_" + hexU32(x.target));
            if (!matchQ(q, lbl)) continue;
            pg.emit("xref", lbl, x.target, 0, "", x.count);
        }
    }
    if (cat == "ins") {
        st.ensureXagg();
        if (st.pe) {
            const auto& cs = disasm::callSites(*st.pdb, *st.pe);
            for (auto& s : cs) {
                const FuncInfo* tf = nullptr;
                auto it = pdb.funcByVa.find(s.target);
                if (it != pdb.funcByVa.end()) tf = &pdb.funcs[it->second];
                std::string lbl = tf ? disasm::funcLabel(*tf) : ("sub_" + hexU32(s.target));
                const FuncInfo* cf = disasm::findFuncContaining(pdb, s.site);
                char ex[256];
                if (cf) snprintf(ex, sizeof ex, "%s+%X", disasm::funcLabel(*cf).c_str(), s.site - cf->va);
                else snprintf(ex, sizeof ex, "%X", s.site);
                std::string text = std::string(s.kind == 'j' ? "jmp " : "call ") + lbl;
                if (!matchQ(q, text, lbl, ex)) continue;
                pg.emit("ins", text, s.site, 0, ex, 0);
            }
        }
    }
}

// ------------------------------------------------- endpoint'ler
static std::string apiStats(SrvState& st) {
    st.ensureUdts();
    st.ensureStrings();
    st.ensureXagg();
    u32 calls = 0;
    if (st.pe) for (auto& s : disasm::callSites(*st.pdb, *st.pe)) if (s.kind == 'p') calls++;
    std::string o = "{\"functions\":" + Jnum(st.pdb->funcs.size());
    o += ",\"classes\":" + Jnum(st.countKinds("class"));
    o += ",\"structs\":" + Jnum(st.countKinds("struct"));
    o += ",\"enums\":" + Jnum(st.countKinds("enum"));
    o += ",\"statics\":" + Jnum(st.pdb->globals.size());
    o += ",\"strings\":" + Jnum(st.strings.size());
    o += ",\"calls\":" + Jnum(calls);
    o += "}";
    return o;
}

static std::string apiItems(SrvState& st, const std::string& cat, const std::string& q, size_t off, size_t n) {
    Pager pg(off, n);
    collectItems(st, cat, q, pg);
    return "{\"total\":" + Jnum(pg.total) + ",\"items\":" + (pg.body.empty() ? "[]" : "[" + pg.body + "]") + "}";
}

// tip adini ve (varsa) UDT adini donduren yardimci
static std::string memberType(SrvState& st, u32 tidx, std::string& udt) {
    udt.clear();
    std::string s = st.pdb->typeName(tidx);
    const TypeRec* t = st.pdb->completeType(tidx);
    if (t && t->valid && !t->name.empty() &&
        (t->leaf == 0x1504 || t->leaf == 0x1505 || t->leaf == 0x1506 || t->leaf == 0x1507)) {
        udt = t->name;
        s = t->name;
    }
    return s;
}

static std::string apiStruct(SrvState& st, const std::string& name) {
    st.ensureUdts();
    std::string want = lowerDup(name);
    const UdtEntry* found = nullptr;
    const UdtEntry* partial = nullptr;
    for (auto& u : st.udts) {
        std::string ln = lowerDup(u.t->name);
        if (ln == want) { if (!found || u.t->members.size() > found->t->members.size()) found = &u; }
        else if (!partial && ln.find(want) != std::string::npos) partial = &u;
    }
    if (!found) found = partial;
    if (!found) return "{\"found\":0}";
    const TypeRec& t = *found->t;
    std::string o = "{\"found\":1,\"name\":" + Jstr(t.name) + ",\"kind\":" + Jstr(found->kind) +
                   ",\"size\":" + Jnum((long long)t.size) + ",\"members\":[";
    bool f1 = true;
    for (auto& m : t.members) {
        const char* flag = m.attr == 0xFFFD ? "static" : m.attr == 0xFFFF ? "nested" : m.attr == 0xFFFE ? "vftable" : "";
        std::string udt, ty = (m.attr == 0xFFFF || m.attr == 0xFFFD || m.attr == 0xFFFE) ? st.pdb->typeName(m.tidx) : memberType(st, m.tidx, udt);
        if (!f1) o += ",";
        f1 = false;
        o += "{\"off\":" + Jnum((long long)m.off) + ",\"name\":" + Jstr(m.name) +
             ",\"type\":" + Jstr(ty) + ",\"tu\":" + Jstr(udt) + ",\"flag\":" + Jstr(flag) + "}";
    }
    o += "],\"enums\":[";
    bool f2 = true;
    for (auto& e : t.evals) {
        if (!f2) o += ",";
        f2 = false;
        o += "{\"val\":" + Jnum((long long)e.val) + ",\"name\":" + Jstr(e.name) + "}";
    }
    o += "],\"methods\":[";
    // ayni sinifin metotlari (Class:: ile baslayanlar)
    std::string prefix = t.name + "::";
    bool f3 = true;
    u32 lim = 0;
    for (auto& fn : st.pdb->funcs) {
        if (fn.shortName.rfind(prefix, 0) != 0) continue;
        if (++lim > 400) break;
        if (!f3) o += ",";
        f3 = false;
        o += "{\"name\":" + Jstr(fn.shortName) + ",\"va\":" + Jnum(fn.va) + "}";
    }
    o += "]}";
    return o;
}

static std::string apiDisasm(SrvState& st, const std::string& name, u32 addr) {
    const FuncInfo* f = nullptr;
    u32 focus = 0;
    if (addr) {
        f = st.pe ? disasm::findFuncContaining(*st.pdb, addr) : nullptr;
        focus = addr;
    }
    if (!f && !name.empty()) {
        int cnt = 0;
        f = st.pdb->findFuncByNameSub(name, &cnt);
    }
    if (!f) return "{\"found\":0}";
    if (!st.pe) return "{\"found\":0,\"err\":\"exe gerekli\"}";
    std::string text = disasm::disassemble(*st.pdb, st.pe, *f);
    return "{\"found\":1,\"name\":" + Jstr(disasm::funcLabel(*f)) +
           ",\"proto\":" + Jstr(f->proto) +
           ",\"va\":" + Jnum(f->va) + ",\"size\":" + Jnum(f->size) +
           ",\"focus\":" + Jnum(focus) +
           ",\"text\":" + Jstr(text) + "}";
}

static std::string apiGoto(SrvState& st, const std::string& name, u32 addr) {
    const FuncInfo* f = nullptr;
    if (addr) f = st.pe ? disasm::findFuncContaining(*st.pdb, addr) : nullptr;
    if (!f && !name.empty()) {
        int cnt = 0;
        f = st.pdb->findFuncByNameSub(name, &cnt);
    }
    if (!f) return "{\"found\":0}";
    return "{\"found\":1,\"va\":" + Jnum(f->va) + ",\"funcVa\":" + Jnum(f->va) +
           ",\"name\":" + Jstr(disasm::funcLabel(*f)) + "}";
}

static std::string apiFuncs(SrvState& st, const std::string& q, size_t off, size_t n) {
    Pager pg(off, n);
    for (auto& f : st.pdb->funcs) {
        std::string lbl = disasm::funcLabel(f);
        if (!matchQ(q, lbl, f.name, f.mangled)) continue;
        pg.emit("func", lbl, f.va, f.size, "", 0);
    }
    return "{\"total\":" + Jnum(pg.total) + ",\"items\":" + (pg.body.empty() ? "[]" : "[" + pg.body + "]") + "}";
}

// ------------------------------------------------- HTTP katmani
static void sendAll(SOCKET s, const char* d, size_t n) {
    size_t off = 0;
    while (off < n) {
        int k = (int)send(s, d + off, (int)(n - off), 0);
        if (k <= 0) return;
        off += (size_t)k;
    }
}

static void sendRes(SOCKET s, const char* ctype, const std::string& body, int code = 200) {
    char h[256];
    snprintf(h, sizeof h,
             "HTTP/1.1 %d %s\r\nContent-Type: %s; charset=utf-8\r\nContent-Length: %zu\r\n"
             "Cache-Control: no-store\r\nConnection: close\r\n\r\n",
             code, code == 200 ? "OK" : "Not Found", ctype, body.size());
    sendAll(s, h, strlen(h));
    sendAll(s, body.data(), body.size());
}

static std::string urlDecode(const std::string& s) {
    std::string r; r.reserve(s.size());
    for (size_t i = 0; i < s.size(); i++) {
        if (s[i] == '+' ) { r += ' '; continue; }
        if (s[i] == '%' && i + 2 < s.size() && isxdigit((unsigned char)s[i+1]) && isxdigit((unsigned char)s[i+2])) {
            auto hv = [](char c) { return c <= '9' ? c - '0' : (c | 32) - 'a' + 10; };
            r += (char)(hv(s[i+1]) * 16 + hv(s[i+2]));
            i += 2;
            continue;
        }
        r += s[i];
    }
    return r;
}

static std::unordered_map<std::string, std::string> parseQuery(const std::string& q) {
    std::unordered_map<std::string, std::string> m;
    size_t p = 0;
    while (p < q.size()) {
        size_t e = q.find('&', p);
        if (e == std::string::npos) e = q.size();
        size_t eq = q.find('=', p);
        if (eq != std::string::npos && eq < e) {
            m[urlDecode(q.substr(p, eq - p))] = urlDecode(q.substr(eq + 1, e - eq - 1));
        } else if (e > p) {
            m[urlDecode(q.substr(p, e - p))] = "";
        }
        p = e + 1;
    }
    return m;
}

// "0x4D7610" / "4D7610" / ".text:004D7610" -> VA (0 = cozulemedi)
static u32 parseAddr(const std::string& s) {
    std::string t = s;
    size_t c = t.rfind(':');
    if (c != std::string::npos) t = t.substr(c + 1);
    if (t.rfind("0x", 0) == 0 || t.rfind("0X", 0) == 0) t = t.substr(2);
    if (t.empty() || t.size() > 8) return 0;
    for (char ch : t) if (!isxdigit((unsigned char)ch)) return 0;
    return (u32)strtoul(t.c_str(), nullptr, 16);
}

static void route(SrvState& st, SOCKET s, const std::string& path, const std::string& query) {
    auto qp = parseQuery(query);
    auto gi = [&](const char* k) { auto it = qp.find(k); return it == qp.end() ? std::string() : it->second; };
    auto gn = [&](const char* k, size_t def) {
        auto it = qp.find(k);
        if (it == qp.end() || it->second.empty()) return def;
        return (size_t)strtoull(it->second.c_str(), nullptr, 10);
    };

    if (path == "/" || path == "/index.html") {
        sendRes(s, "text/html", WEBUI_HTML);
        return;
    }
    try {
        if (path == "/api/stats") { sendRes(s, "application/json", apiStats(st)); return; }
        if (path == "/api/items") { size_t nn = gn("n", 100); if (!nn || nn > 1000) nn = 1000; sendRes(s, "application/json", apiItems(st, gi("cat").empty() ? "all" : gi("cat"), lowerDup(gi("q")), gn("o", 0), nn)); return; }
        if (path == "/api/struct" || path == "/api/enum") { sendRes(s, "application/json", apiStruct(st, gi("name"))); return; }
        if (path == "/api/disasm") { sendRes(s, "application/json", apiDisasm(st, gi("name"), parseAddr(gi("addr")))); return; }
        if (path == "/api/goto") { sendRes(s, "application/json", apiGoto(st, gi("name"), parseAddr(gi("addr")))); return; }
        if (path == "/api/funcs") { size_t nn = gn("n", 300); if (!nn || nn > 2000) nn = 2000; sendRes(s, "application/json", apiFuncs(st, lowerDup(gi("q")), gn("o", 0), nn)); return; }
    } catch (std::bad_alloc&) {
        sendRes(s, "application/json", "{\"err\":\"bellek yetersiz\"}", 500);
        return;
    } catch (...) {
        sendRes(s, "application/json", "{\"err\":\"sunucu hatasi\"}", 500);
        return;
    }
    sendRes(s, "application/json", "{\"err\":\"bilinmeyen yol\"}", 404);
}

int serveWeb(PdbData& pdb, const PE* pe, const std::string& pdbPath, const std::string& exeName, u16 port) {
#ifdef _WIN32
    WSADATA wsa;
    if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0) { printf("HATA: WSAStartup\n"); return 2; }
#else
    signal(SIGPIPE, SIG_IGN);
#endif
    static SrvState st;
    st.pdb = &pdb;
    st.pe = pe;
    {
        size_t a = pdbPath.find_last_of("/\\");
        st.pdbName = a == std::string::npos ? pdbPath : pdbPath.substr(a + 1);
    }
    st.exeName = exeName;

    SOCKET ls = socket(AF_INET, SOCK_STREAM, 0);
    if (ls == INVALID_SOCKET) { printf("HATA: socket acilamadi\n"); return 2; }
    int one = 1;
    setsockopt(ls, SOL_SOCKET, SO_REUSEADDR, (const char*)&one, sizeof one);
    sockaddr_in ad{};
    ad.sin_family = AF_INET;
    ad.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
    ad.sin_port = htons(port);
    if (bind(ls, (sockaddr*)&ad, sizeof ad) == SOCKET_ERROR) {
        printf("HATA: port %u kullanilamiyor (baska bir program kullaniyor olabilir)\n", (unsigned)port);
        closesocket(ls);
        return 2;
    }
    if (listen(ls, 16) == SOCKET_ERROR) { printf("HATA: listen\n"); closesocket(ls); return 2; }

    printf("Web GUI hazir : http://127.0.0.1:%u\n", (unsigned)port);
    printf("Tarayicida bu adresi ac. Durdurmak icin Ctrl+C\n");
    fflush(stdout);

    for (;;) {
        sockaddr_in ca{};
#ifdef _WIN32
        int cl = (int)sizeof ca;
#else
        socklen_t cl = sizeof ca;
#endif
        SOCKET cs = accept(ls, (sockaddr*)&ca, &cl);
        if (cs == INVALID_SOCKET) continue;
        // ozel istemciyi engellememek icin kisa alma zamani asimi
#ifdef _WIN32
        DWORD to = 10000;
        setsockopt(cs, SOL_SOCKET, SO_RCVTIMEO, (const char*)&to, sizeof to);
#else
        timeval tv{ 10, 0 };
        setsockopt(cs, SOL_SOCKET, SO_RCVTIMEO, (const char*)&tv, sizeof tv);
#endif
        std::string req;
        req.reserve(4096);
        char buf[4096];
        while (req.size() < 65536) {
            int k = (int)recv(cs, buf, sizeof buf, 0);
            if (k <= 0) break;
            req.append(buf, (size_t)k);
            if (req.find("\r\n\r\n") != std::string::npos) break;
        }
        if (!req.empty()) {
            size_t l1 = req.find("\r\n");
            std::string line = l1 == std::string::npos ? req : req.substr(0, l1);
            size_t p1 = line.find(' ');
            size_t p2 = line.find(' ', p1 + 1);
            std::string method = p1 == std::string::npos ? "" : line.substr(0, p1);
            std::string target = (p1 == std::string::npos || p2 == std::string::npos) ? "/" : line.substr(p1 + 1, p2 - p1 - 1);
            if (method == "GET" || method == "HEAD") {
                std::string path = target, query;
                size_t qm = target.find('?');
                if (qm != std::string::npos) { path = target.substr(0, qm); query = target.substr(qm + 1); }
                route(st, cs, path, query);
            } else {
                sendRes(cs, "application/json", "{\"err\":\"sadece GET\"}", 405);
            }
        }
        closesocket(cs);
    }
    return 0;
}
