# PDBX v2.0 — PDB Okuyucu + IDA Tarzı Disassembler + Web GUI (Metin2 PVP)

`metin2client.pdb` gibi Microsoft PDB dosyalarını **hiçbir ek kütüphane olmadan**
(DIA SDK / dbghelp / capstone YOK) okuyup fonksiyon isimlerini, struct
tanımlarını, global değişkenleri ve **IDA Pro tarzı disassembly** üreten konsol
aracı. Exe'yi belleğe "process gibi" map edip (i4MConsoleLoader yaklaşımı)
üzerinden disassembly yapar.

**v2.0 yenilikleri:**
- **Web GUI** (`serve` komutu): tarayıcıda çalışan IDA benzeri arayüz,
  localhost üzerinden C++ arka uca bağlanır
- **Struct üyeleri**: `kPacketAtk = command_attack ptr -8` satırındaki tipin
  tüm elemanları (offset + tip) hem konsolda hem web'de görülebilir
- `strings`, `xrefs` konsol komutları
- Çağrı talimatı haritası (52k+ call), Function References / Assembly
  Instructions sekmeleri

## Neler bulunuyor

```
pdbx_win32.exe      -> hazır Windows (x86, statik) exe — kopyala çalıştır
pdbx_x64.exe        -> 64-bit Windows sürümü
src/                -> tüm C++ kaynak kodu (dış bağımlılık yok)
build.bat           -> Visual Studio ile kendin derlemek için
build_mingw.bat     -> mingw-w64 ile derlemek için
web/arayuz.html     -> web arayüzünün ayrık kopyası (bilgi amaçlı)
```

## WEB GUI (yeni!)

```
pdbx_win32.exe metin2client.pdb --exe metin2client.exe serve
```

Sonra tarayıcıda **http://127.0.0.1:27042** adresini aç. (Farklı port:
`serve 8080`)

**Ana ekran:** istatistik kartları (Fonksiyon / Sınıf / Struct / Enum /
Statik Değişken / String / Çağrı Talimatı) + arama kutusu + sekmeler:
`Tümü, Fonksiyonlar, Class'lar, Struct'lar, Enum'lar, Static Variables,
String Literals, Function References, Assembly Instructions`

- Her satırda **RVA Kopyala** düğmesi var
- Struct/Class/Enum satırına tıkla → üyeler offset ve tipiyle tablo halinde
  açılır (`command_attack`: `+0x0 header`, `+0x1 bType`, `+0x2 dwVictimVID`...)
- Fonksiyon satırına tıkla → disassembly ekranı
- Statik değişkenler adres + tipleriyle listelenir

**Disassembly ekranı:**

- Solda fonksiyon listesi, en altta **fonksiyon arama çubuğu**
- Sağda IDA tarzı döküm: `proc near`/`endp`, stack değişkenleri
  (`kPacketAtk = command_attack ptr -8`), XREF'ler, sembollü call'lar,
  string referansları (`push offset aSendBattleAtta ; "..."`),
  `[ebp+kPacketAtk.bType]` biçiminde struct üye erişimleri
- **Ctrl+G** → adres kutusu açılır: `0x4D7610`, `4D7610`,
  `.text:004D7610` ya da fonksiyon adı yazıp Enter → o adresin
  fonksiyonuna gidip satırı vurgular
- Kod içi tıklama: `call ?SendSpecial@...` → o fonksiyona gider,
  XREF satırındaki çağıran isim → çağıran fonksiyona gider,
  `command_attack ptr` gibi tip adları → struct modalını açar

## Konsol komutları

```
pdbx_win32.exe metin2client.pdb --exe metin2client.exe info
pdbx_win32.exe metin2client.pdb --exe metin2client.exe funcs
pdbx_win32.exe metin2client.pdb --exe metin2client.exe funcs SendAttackPacket
pdbx_win32.exe metin2client.pdb --exe metin2client.exe func CPythonNetworkStream::SendAttackPacket
pdbx_win32.exe metin2client.pdb --exe metin2client.exe struct command_attack
pdbx_win32.exe metin2client.pdb --exe metin2client.exe structs Player
pdbx_win32.exe metin2client.pdb --exe metin2client.exe globals kPacket
pdbx_win32.exe metin2client.pdb --exe metin2client.exe strings SendBattle
pdbx_win32.exe metin2client.pdb --exe metin2client.exe xrefs SendAttackPacket
pdbx_win32.exe metin2client.pdb --exe metin2client.exe find kPacket
pdbx_win32.exe metin2client.pdb --exe metin2client.exe disasm CPythonNetworkStream::SendAttackPacket
pdbx_win32.exe metin2client.pdb --exe metin2client.exe disasm 0x4D7610
pdbx_win32.exe metin2client.pdb --exe metin2client.exe dump hepsi.txt
pdbx_win32.exe metin2client.pdb --exe metin2client.exe serve 27042
```

`--exe` verilmezse adresler `seg:off` gösterilir; `disasm` için exe şarttır.
Çıktıyı dosyaya almak için normal yönlendirme kullanın:
`pdbx_win32.exe ... disasm SendAttackPacket > fonksiyon.asm`

## Disassembly örneği (gerçek metin2client çıktısı)

```
.text:004D7610 ; bool __thiscall CPythonNetworkStream::SendAttackPacket(CPythonNetworkStream *this, unsigned int uMotAttack, unsigned int dwVIDVictim)
.text:004D7610 ?SendAttackPacket@CPythonNetworkStream@@QAE_NIK@Z proc near
.text:004D7610                                        ; CODE XREF: CPythonPlayerEventHandler::OnHit+38p
.text:004D7610 kPacketAtk      = command_attack ptr  -8
.text:004D7610 uMotAttack      = dword ptr   8
.text:004D7610 dwVIDVictim     = dword ptr   C
.text:004D7610 this            = ecx
.text:004D7610
.text:004D7610                  push    ebp
.text:004D7611                  mov     ebp, esp
.text:004D7613                  sub     esp, 8
...
.text:004D762E                  mov     byte ptr [ebp+kPacketAtk.bType], al
.text:004D7634                  mov     dword ptr [ebp+kPacketAtk.dwVictimVID], eax
.text:004D7642                  call    ?SendSpecial@CPythonNetworkStream@@QAE_NHPAX@Z ; CPythonNetworkStream::SendSpecial(int,void *)
.text:004D764B                  push    offset aSendBattleAtta ; "Send Battle Attack Packet Error"
```

## Kendin derlemek istersen

**Visual Studio:** VS Developer Command Prompt'ta `build.bat`
(veya: `cl /nologo /O2 /EHsc /std:c++17 /Fe:pdbx_win32.exe src\*.cpp ws2_32.lib`)

**mingw-w64:** `build_mingw.bat`
(veya: `i686-w64-mingw32-g++ -O2 -std:c++17 -static -o pdbx_win32.exe src/*.cpp -lws2_32`)

## Sık sorulanlar

- **Port meşgul:** `serve 8080` gibi başka bir port ver
- **Web açılmıyor:** sunucu penceresi açık kalmalı; `http://127.0.0.1:PORT` doğru mu?
- **`dosya cok buyuk` yok:** 47 MB'lık metin2client.pdb sorunsuz açılıyor (1 TB'a kadar destek)
- Web GUI yalnızca localhost'u dinler (dışarıya açık değildir)
