// PDBX cekirdek: MSF 7.00 + PE32 + PDB (TPI/DBI/semboller) + tip bicimlendirme
#include "pdbx.h"

// ------------------------------------------------ dosya
bool readFile(const char* path, std::vector<u8>& out, std::string& err) {
    FILE* f = fopen(path, "rb");
    if (!f) { err = std::string("dosya acilamadi: ") + path; return false; }
#ifdef _WIN32
    if (_fseeki64(f, 0, SEEK_END) != 0) { fclose(f); err = "boyut alinamadi"; return false; }
    long long sz = _ftelli64(f);
    if (_fseeki64(f, 0, SEEK_SET) != 0) { fclose(f); err = "konum hatasi"; return false; }
#else
    if (fseek(f, 0, SEEK_END) != 0) { fclose(f); err = "boyut alinamadi"; return false; }
    long long sz = (long long)ftell(f);
    rewind(f);
#endif
    // 32-bit long tasma hatasi giderildi: sinir 1 TB (sanal ust sinir)
    if (sz < 0 || sz > (1LL << 40)) { fclose(f); err = "dosya boyutu okunamadi"; return false; }
    try {
        out.resize((size_t)sz);
    } catch (...) { fclose(f); err = "bellek yetersiz (dosya cok buyuk)"; return false; }
    if (sz > 0 && fread(out.data(), 1, (size_t)sz, f) != (size_t)sz) {
        fclose(f); err = "dosya okunamadi"; return false;
    }
    fclose(f);
    return true;
}

std::string lowerDup(const std::string& s) {
    std::string r = s;
    for (auto& c : r) if (c >= 'A' && c <= 'Z') c = (char)(c - 'A' + 'a');
    return r;
}
std::string hexU32(u32 v) { char b[16]; snprintf(b, sizeof b, "%Xh", v); return b; }
std::string hexU64(u64 v) { char b[32]; snprintf(b, sizeof b, "%llXh", (unsigned long long)v); return b; }

// ------------------------------------------------ MSF
bool Msf::load(const std::vector<u8>& raw, std::string& err) {
    if (raw.size() < 0x40) { err = "dosya cok kucuk"; return false; }
    if (memcmp(raw.data(), "Microsoft C/C++ MSF 7.00", 24) != 0) {
        err = "MSF 7.00 imzasi yok (bu surum desteklenmiyor)";
        return false;
    }
    blockSize = rd32(raw.data() + 0x20);
    numBlocks = rd32(raw.data() + 0x28);
    u32 dirBytes = rd32(raw.data() + 0x2C);
    u32 dirMapAddr = rd32(raw.data() + 0x34);
    if (blockSize < 512 || blockSize > (1 << 16) || (blockSize & (blockSize - 1))) {
        err = "gecersiz blok boyutu"; return false;
    }
    data = raw;
    if ((u64)numBlocks * blockSize > raw.size()) numBlocks = (u32)(raw.size() / blockSize);
    u32 nDirBlocks = (dirBytes + blockSize - 1) / blockSize;
    if ((u64)dirMapAddr * blockSize + (u64)nDirBlocks * 4 > raw.size()) {
        err = "dizin adresi tasma"; return false;
    }
    std::vector<u8> dir;
    dir.reserve(dirBytes);
    const u8* mapBase = raw.data() + (size_t)dirMapAddr * blockSize;
    for (u32 i = 0; i < nDirBlocks; i++) {
        u32 b = rd32(mapBase + i * 4);
        if (b >= numBlocks) { err = "dizin blogu gecersiz"; return false; }
        size_t off = (size_t)b * blockSize;
        size_t take = blockSize;
        if (dir.size() + take > dirBytes) take = dirBytes - dir.size();
        dir.insert(dir.end(), data.begin() + off, data.begin() + off + take);
    }
    if (dir.size() < 4) { err = "dizin bos"; return false; }
    u32 nStreams = rd32(dir.data());
    size_t p = 4;
    std::vector<u32> sizes(nStreams);
    for (u32 i = 0; i < nStreams; i++) {
        if (p + 4 > dir.size()) { err = "dizin bozuk (1)"; return false; }
        sizes[i] = rd32(dir.data() + p); p += 4;
    }
    streams.resize(nStreams);
    for (u32 i = 0; i < nStreams; i++) {
        u32 s = sizes[i];
        streams[i].size = s;
        if (s == 0xFFFFFFFF || s == 0) continue;
        u32 nb = (s + blockSize - 1) / blockSize;
        for (u32 k = 0; k < nb; k++) {
            if (p + 4 > dir.size()) { err = "dizin bozuk (2)"; return false; }
            u32 b = rd32(dir.data() + p); p += 4;
            if (b >= numBlocks) { err = "stream blogu gecersiz"; return false; }
            streams[i].blocks.push_back(b);
        }
    }
    return true;
}

bool Msf::streamBytes(size_t idx, std::vector<u8>& out) const {
    out.clear();
    if (idx >= streams.size()) return false;
    const MsfStream& s = streams[idx];
    if (s.size == 0xFFFFFFFF || s.size == 0) return true;
    out.reserve(s.size);
    for (u32 b : s.blocks) {
        if (b >= numBlocks) return false;
        size_t off = (size_t)b * blockSize;
        size_t take = blockSize;
        if (out.size() + take > s.size) take = s.size - out.size();
        out.insert(out.end(), data.begin() + off, data.begin() + off + take);
        if (out.size() >= s.size) break;
    }
    return true;
}

// ------------------------------------------------ PE32
bool PE::load(const std::vector<u8>& raw, std::string& err) {
    if (raw.size() < 0x200 || raw[0] != 'M' || raw[1] != 'Z') {
        err = "PE imzasi yok (MZ)"; return false;
    }
    u32 e_lfanew = rd32(raw.data() + 0x3C);
    if (e_lfanew + 0x100 > raw.size() || rd32(raw.data() + e_lfanew) != 0x00004550) {
        err = "PE imzasi yok"; return false;
    }
    u16 nsec = rd16(raw.data() + e_lfanew + 6);
    u16 optsz = rd16(raw.data() + e_lfanew + 20);
    const u8* opt = raw.data() + e_lfanew + 24;
    u16 magic = rd16(opt);
    if (magic == 0x10B) {
        imageBase = rd32(opt + 28);
        sizeOfImage = rd32(opt + 56);
        entryRva = rd32(opt + 16);
    } else if (magic == 0x20B) {
        err = "PE32+ (64-bit) desteklenmiyor - 32-bit exe gerekli";
        return false;
    } else {
        err = "bilinmeyen optional header"; return false;
    }
    const u8* sh = opt + optsz;
    secs.clear();
    for (int i = 0; i < nsec; i++) {
        const u8* e = sh + 40 * i;
        if ((size_t)(e - raw.data()) + 40 > raw.size()) break;
        PESection s;
        char nm[9] = { 0 };
        memcpy(nm, e, 8);
        s.name = nm;
        s.vsz = rd32(e + 8); s.va = rd32(e + 12);
        s.rsz = rd32(e + 16); s.raw = rd32(e + 20);
        s.chars = rd32(e + 36);
        secs.push_back(s);
    }
    if (sizeOfImage == 0 || sizeOfImage > 0x10000000) sizeOfImage = 0x1000000;
    image.assign(sizeOfImage, 0);
    size_t hdr = 0x1000;
    if (raw.size() < hdr) hdr = raw.size();
    memcpy(image.data(), raw.data(), hdr);
    for (auto& s : secs) {
        u32 copy = s.rsz < s.vsz ? s.rsz : s.vsz;
        if (!copy) continue;
        if ((u64)s.va + copy > sizeOfImage) copy = (u32)(sizeOfImage - s.va);
        if ((u64)s.raw + copy > raw.size()) copy = (u32)(raw.size() - s.raw);
        if (s.va + copy <= sizeOfImage)
            memcpy(image.data() + s.va, raw.data() + s.raw, copy);
    }
    return true;
}

// ------------------------------------------------ tip bicimlendirme
static const char* simpleTypeName(u32 t) {
    switch (t & 0xFF) {
    case 0x03: return "void";
    case 0x10: return "char";
    case 0x11: return "short";
    case 0x12: return "int";
    case 0x13: return "__int64";
    case 0x20: return "unsigned char";
    case 0x21: return "unsigned short";
    case 0x22: return "unsigned int";
    case 0x23: return "unsigned __int64";
    case 0x30: return "bool";
    case 0x40: return "float";
    case 0x41: return "double";
    case 0x42: return "long double";
    case 0x68: return "int8";
    case 0x69: return "int16";
    case 0x6a: return "int32";
    case 0x6b: return "int64";
    case 0x70: return "char";
    case 0x71: return "wchar_t";
    case 0x72: return "short";
    case 0x73: return "unsigned short";
    case 0x74: return "int";
    case 0x75: return "unsigned int";
    case 0x76: return "__int64";
    case 0x77: return "unsigned __int64";
    default: return nullptr;
    }
}

std::string PdbData::typeName(u32 idx, int depth) const {
    if (depth > 8) return "...";
    if (idx < 0x1000) {
        u32 mode = (idx >> 8) & 0xFF;
        const char* base = simpleTypeName(idx);
        std::string b = base ? base : ("T_" + hexU32(idx & 0xFF));
        if (mode == 0) return b;
        if (mode == 0x0A || mode == 0x09) return b + " &";
        return b + " *";
    }
    const TypeRec* t = completeType(idx);
    if (!t || !t->valid) return "#" + hexU32(idx);
    switch (t->leaf) {
    case 0x1504: case 0x1505: case 0x1506: case 0x1507:
        return t->name.empty() ? ("#" + hexU32(idx)) : t->name;
    case 0x1002: { // POINTER
        std::string inner = typeName(t->a, depth + 1);
        return inner + " *";
    }
    case 0x1001: { // MODIFIER
        std::string s;
        if (t->attr16 & 1) s += "const ";
        if (t->attr16 & 2) s += "volatile ";
        s += typeName(t->a, depth + 1);
        return s;
    }
    case 0x1503: { // ARRAY
        char sz[32];
        snprintf(sz, sizeof sz, "[%llu]", (unsigned long long)t->size);
        return typeName(t->a, depth + 1) + " " + sz;
    }
    case 0x1205: return typeName(t->baseType, depth + 1); // bitfield
    case 0x1008: case 0x1009: return "<fonksiyon>";
    default: return t->name.empty() ? ("#" + hexU32(idx)) : t->name;
    }
}

// struct icinde delta offset'ine uyan uye yolu (kpacket.atk benzeri)
bool PdbData::resolveMemberPath(u32 tidx, i64 delta, std::string& out, int depth) const {
    if (depth > 3) return false;
    const TypeRec* t = completeType(tidx);
    if (!t || !t->valid) return false;
    if (t->leaf != 0x1504 && t->leaf != 0x1505 && t->leaf != 0x1506) return false;
    // 1) dogrudan eslesme (skalar / isaretci tercih)
    for (auto& m : t->members) {
        if (m.off == delta) {
            const TypeRec* mt = type(m.tidx);
            bool complex = mt && (mt->leaf == 0x1504 || mt->leaf == 0x1505 || mt->leaf == 0x1506);
            if (!complex) { out = m.name; return true; }
        }
    }
    // 2) array elemani
    for (auto& m : t->members) {
        if (m.attr == 0xFFFF || m.attr == 0xFFFE) continue;
        const TypeRec* mt = type(m.tidx);
        if (mt && mt->leaf == 0x1503 && mt->sizeKnown && mt->size > 0) {
            u64 total = mt->size;
            u64 es = 1;
            u32 elemIdx = mt->a;
            if (elemIdx < 0x1000) {
                switch (elemIdx & 0xFF) {
                case 0x10: case 0x20: case 0x70: case 0x68: es = 1; break;
                case 0x11: case 0x21: case 0x71: case 0x72: case 0x73: case 0x69: es = 2; break;
                case 0x12: case 0x22: case 0x74: case 0x75: case 0x40: case 0x6a: es = 4; break;
                case 0x13: case 0x23: case 0x76: case 0x77: case 0x41: case 0x6b: es = 8; break;
                default: es = 4;
                }
            } else {
                const TypeRec* et = type(elemIdx);
                if (et && et->sizeKnown && et->size) es = et->size;
                else if (et && et->leaf == 0x1002) es = 4;
            }
            if (es && delta >= m.off && (u64)(delta - m.off) < total + es && (u64)(delta - m.off) % es == 0) {
                char buf[96];
                snprintf(buf, sizeof buf, "%s[%llu]", m.name.c_str(), (unsigned long long)((delta - m.off) / es));
                out = buf;
                return true;
            }
        }
    }
    // 3) ic ice struct
    for (auto& m : t->members) {
        if (m.attr == 0xFFFF || m.attr == 0xFFFE) continue;
        const TypeRec* mt = type(m.tidx);
        if (mt && (mt->leaf == 0x1504 || mt->leaf == 0x1505 || mt->leaf == 0x1506)) {
            i64 sz = mt->sizeKnown ? (i64)mt->size : 0;
            if (delta > m.off && (sz == 0 || delta < m.off + sz)) {
                std::string sub;
                if (resolveMemberPath(m.tidx, delta - m.off, sub, depth + 1)) {
                    out = m.name + "." + sub;
                    return true;
                }
            }
        }
    }
    return false;
}

std::string PdbData::fullProto(const FuncInfo& f, bool withThis) const {
    if (!f.hasType) return f.name;
    const TypeRec* t = type(f.tidx);
    if (!t || (t->leaf != 0x1009 && t->leaf != 0x1008)) return f.name;
    std::string rv = typeName(t->rvType);
    std::string cls;
    bool isM = (t->leaf == 0x1009);
    bool thiscall = false;
    if (isM) {
        cls = typeName(t->clsType);
        thiscall = (t->callconv == 4 || t->callconv == 10 || t->callconv == 11);
    }
    std::string args;
    const TypeRec* al = type(t->arglist);
    std::vector<u32> ats;
    if (al && al->leaf == 0x1201) ats = al->args;
    // arglist'te 'this' var mi? (nparams ile karsilastir)
    size_t start = 0;
    if (isM && ats.size() == (size_t)t->nparams + 1) start = 1;
    // IDA tarzi: thiscall baslikta "Class *this" ilk parametre olarak gosterilir
    bool showThis = (isM && thiscall && withThis && !cls.empty());
    if (showThis) args = cls + " *this";
    for (size_t i = start; i < ats.size(); i++) {
        if (i > start || showThis) args += ", ";
        args += typeName(ats[i]);
        size_t ai = i - start;
        if (ai < f.argNames.size() && !f.argNames[ai].empty()) { args += " "; args += f.argNames[ai]; }
    }
    if (ats.empty() && !showThis) args = "void";
    const char* conv = "";
    if (isM) {
        switch (t->callconv) {
        case 0: conv = "__cdecl "; break;
        case 4: case 10: case 11: conv = thiscall ? "__thiscall " : "__fastcall "; break;
        case 3: case 5: conv = "__fastcall "; break;
        case 1: case 2: conv = "__pascal "; break;
        case 6: case 7: conv = "__stdcall "; break;
        default: conv = ""; break;
        }
    }
    std::string out = rv + " " + conv;
    if (!cls.empty()) {
        // isim zaten class:: iceriyor mu?
        if (f.name.rfind(cls + "::", 0) != 0 && f.shortName.rfind(cls + "::", 0) != 0) out += cls + "::";
    }
    out += (f.shortName.empty() ? f.name : f.shortName) + "(" + args + ")";
    return out;
}

const FuncInfo* PdbData::findFuncByNameSub(const std::string& sub, int* count) const {
    std::string s = lowerDup(sub);
    if (!count) count = new int(0);
    *count = 0;
    const FuncInfo* first = nullptr;
    for (auto& f : funcs) {
        if (lowerDup(f.name).find(s) != std::string::npos ||
            lowerDup(f.shortName).find(s) != std::string::npos ||
            (!f.mangled.empty() && lowerDup(f.mangled).find(s) != std::string::npos)) {
            if (!first) first = &f;
            (*count)++;
        }
    }
    return first;
}

// ------------------------------------------------ TPI parse
namespace {
struct NumLeaf { i64 val = 0; const u8* next = nullptr; bool ok = false; };
NumLeaf readNum(const u8* p, const u8* end) {
    NumLeaf r;
    if (p + 2 > end) return r;
    u16 v = rd16(p);
    if (v < 0x8000) { r.val = v; r.next = p + 2; r.ok = true; return r; }
    switch (v) {
    case 0x8000: if (p + 3 <= end) { r.val = (i8)p[2]; r.next = p + 3; r.ok = true; } break;
    case 0x8001: if (p + 4 <= end) { r.val = (i16)rd16(p + 2); r.next = p + 4; r.ok = true; } break;
    case 0x8002: if (p + 4 <= end) { r.val = rd16(p + 2); r.next = p + 4; r.ok = true; } break;
    case 0x8003: if (p + 6 <= end) { r.val = rdi32(p + 2); r.next = p + 6; r.ok = true; } break;
    case 0x8004: if (p + 6 <= end) { r.val = (i64)rd32(p + 2); r.next = p + 6; r.ok = true; } break;
    case 0x8009: case 0x800A:
        if (p + 10 <= end) { r.val = (i64)rd64(p + 2); r.next = p + 10; r.ok = true; } break;
    default: r.next = p + 2; break;
    }
    return r;
}
std::string readCStr(const u8* p, const u8* end, const u8** nextOut) {
    const u8* e = p;
    while (e < end && *e) e++;
    std::string s((const char*)p, e - p);
    if (nextOut) *nextOut = e < end ? e + 1 : end;
    return s;
}
} // namespace

static bool parseTpi(PdbData& pdb, const std::vector<u8>& tpi, std::string& err) {
    if (tpi.size() < 64) { err = "TPI cok kucuk"; return false; }
    u32 hdrSize = rd32(tpi.data() + 4);
    if (hdrSize < 28 || hdrSize > tpi.size()) { err = "TPI header bozuk"; return false; }
    pdb.tpiBegin = rd32(tpi.data() + 8);
    struct RawRec { u16 leaf; const u8* body; const u8* end; };
    std::unordered_map<u32, RawRec> raws;
    raws.reserve(200000);
    u32 idx = pdb.tpiBegin;
    size_t p = hdrSize;
    while (p + 4 <= tpi.size()) {
        u16 ln = rd16(tpi.data() + p);
        u16 leaf = rd16(tpi.data() + p + 2);
        if (ln < 2) break;
        if (p + 2 + ln > tpi.size()) break;
        raws[idx] = { leaf, tpi.data() + p + 4, tpi.data() + p + 2 + ln };
        idx++;
        p += 2 + ln;
    }
    pdb.tpiEnd = idx;
    // 1. gecis: kayitlar
    for (auto& kv : raws) {
        u32 id = kv.first;
        const RawRec& r = kv.second;
        TypeRec t;
        t.leaf = r.leaf;
        switch (r.leaf) {
        case 0x1504: case 0x1505:
            if (r.body + 18 <= r.end) {
                t.fieldlist = rd32(r.body + 4);
                NumLeaf n = readNum(r.body + 16, r.end);
                if (n.ok) { t.size = (u64)n.val; t.sizeKnown = true; }
                t.name = readCStr(r.body + 18, r.end, nullptr);
                t.valid = true;
            }
            break;
        case 0x1506:
            if (r.body + 10 <= r.end) {
                t.fieldlist = rd32(r.body + 4);
                NumLeaf n = readNum(r.body + 8, r.end);
                if (n.ok) { t.size = (u64)n.val; t.sizeKnown = true; }
                t.name = readCStr(r.body + 10, r.end, nullptr);
                t.valid = true;
            }
            break;
        case 0x1507:
            if (r.body + 12 <= r.end) {
                t.fieldlist = rd32(r.body + 8);
                t.name = readCStr(r.body + 12, r.end, nullptr);
                t.valid = true;
            }
            break;
        case 0x1001:
            if (r.body + 6 <= r.end) { t.a = rd32(r.body); t.attr16 = rd16(r.body + 4); t.valid = true; }
            break;
        case 0x1002:
            if (r.body + 8 <= r.end) { t.a = rd32(r.body); t.attr16 = (u16)(rd32(r.body + 4) & 0xFFFF); t.valid = true; }
            break;
        case 0x1503:
            if (r.body + 10 <= r.end) {
                t.a = rd32(r.body); t.b = rd32(r.body + 4);
                NumLeaf n = readNum(r.body + 8, r.end);
                if (n.ok) { t.size = (u64)n.val; t.sizeKnown = true; }
                t.valid = true;
            }
            break;
        case 0x1008:
            if (r.body + 12 <= r.end) {
                t.rvType = rd32(r.body); t.callconv = rd16(r.body + 4);
                t.nparams = rd16(r.body + 6); t.arglist = rd32(r.body + 8);
                t.valid = true;
            }
            break;
        case 0x1009:
            if (r.body + 24 <= r.end) {
                t.rvType = rd32(r.body); t.clsType = rd32(r.body + 4); t.thisType = rd32(r.body + 8);
                t.callconv = rd16(r.body + 12); t.nparams = rd16(r.body + 14); t.arglist = rd32(r.body + 16);
                t.valid = true;
            }
            break;
        case 0x1201: {
            if (r.body + 4 <= r.end) {
                u32 n = rd32(r.body);
                for (u32 i = 0; i < n && r.body + 4 + 4 * (i + 1) <= r.end; i++)
                    t.args.push_back(rd32(r.body + 4 + 4 * i));
                t.valid = true;
            }
            break;
        }
        case 0x1203: t.valid = true; break;
        case 0x1205:
            if (r.body + 6 <= r.end) { t.baseType = rd32(r.body); t.bitLen = r.body[4]; t.bitPos = r.body[5]; t.valid = true; }
            break;
        case 0x1510:
            if (r.body + 6 <= r.end) { t.a = rd32(r.body + 2); t.name = readCStr(r.body + 6, r.end, nullptr); t.valid = true; }
            break;
        default: break;
        }
        pdb.types[id] = std::move(t);
    }
    // 2. gecis: fieldlist uyeleri (uzunluk onekli DEGIL: leaf + pad baytlari)
    for (auto& kv : raws) {
        if (kv.second.leaf != 0x1203) continue;
        const u8* q = kv.second.body;
        const u8* end = kv.second.end;
        TypeRec& fr = pdb.types[kv.first];
        int guard = 0;
        while (q + 2 <= end && guard++ < 100000) {
            u16 lf2 = rd16(q);
            const u8* body = q + 2;
            if (lf2 == 0x150D) { // MEMBER: attr(2) tidx(4) off(num) name
                if (body + 8 > end) break;
                Member m;
                m.attr = rd16(body);
                m.tidx = rd32(body + 2);
                NumLeaf n = readNum(body + 6, end);
                const u8* np = nullptr;
                if (n.ok) {
                    m.off = n.val;
                    m.name = readCStr(n.next, end, &np);
                } else {
                    m.name = readCStr(body + 8, end, &np);
                }
                if (m.name.empty() || !np) break;
                fr.members.push_back(std::move(m));
                q = np;
            } else if (lf2 == 0x1502) { // ENUMERATE: attr(2) val(num) name
                if (body + 4 > end) break;
                EnumVal ev;
                ev.val = rd16(body + 2);
                NumLeaf n = readNum(body + 2, end);
                const u8* np = nullptr;
                if (n.ok) {
                    ev.val = n.val;
                    ev.name = readCStr(n.next, end, &np);
                } else {
                    ev.name = readCStr(body + 4, end, &np);
                }
                if (ev.name.empty() || !np) break;
                fr.evals.push_back(std::move(ev));
                q = np;
            } else if (lf2 == 0x1510) { // NESTTYPE: pad(2) tidx(4) name
                if (body + 6 > end) break;
                Member m;
                m.attr = 0xFFFF;
                m.tidx = rd32(body + 2);
                m.off = -1;
                const u8* np = nullptr;
                m.name = readCStr(body + 6, end, &np);
                if (m.name.empty() || !np) break;
                fr.members.push_back(std::move(m));
                q = np;
            } else if (lf2 == 0x1409) { // VFUNCTAB: pad(2) tidx(4)
                if (body + 6 > end) break;
                Member m;
                m.attr = 0xFFFE;
                m.tidx = rd32(body + 2);
                m.off = -1;
                m.name = "`vftable'";
                fr.members.push_back(std::move(m));
                q = body + 6;
            } else if (lf2 == 0x150F) { // METHOD: count(2) mlist(4) name
                if (body + 6 > end) break;
                const u8* np = nullptr;
                std::string nm = readCStr(body + 6, end, &np);
                if (nm.empty() || !np) break;
                q = np;
            } else if (lf2 == 0x1511 || lf2 == 0x150C) { // ONEMETHOD: attr(2) tidx(4) [vbaseoff(4)] name
                if (body + 6 > end) break;
                u16 attr = rd16(body);
                u16 mprop = (attr >> 2) & 0x1F;   // 4=intro virtual, 6=pure intro
                const u8* np = nullptr;
                const u8* npos = body + 6 + ((mprop == 4 || mprop == 6) ? 4 : 0);
                if (npos > end) break;
                std::string nm = readCStr(npos, end, &np);
                if (nm.empty() || !np) break;
                q = np;
            } else if (lf2 == 0x150E) { // STMEMBER: attr(2) tidx(4) name
                if (body + 6 > end) break;
                Member m;
                m.attr = 0xFFFD;                  // static uye isareti
                m.tidx = rd32(body + 2);
                m.off = -1;
                const u8* np = nullptr;
                m.name = readCStr(body + 6, end, &np);
                if (m.name.empty() || !np) break;
                fr.members.push_back(std::move(m));
                q = np;
            } else if (lf2 == 0x1509) { // LF_ENUM (icte tanimlanan enum bildirimi)
                if (body + 12 > end) break;
                Member m;
                m.attr = 0xFFFF;
                m.tidx = rd32(body + 4);          // utype
                m.off = -1;
                const u8* np = nullptr;
                m.name = readCStr(body + 12, end, &np);
                if (m.name.empty() || !np) break;
                fr.members.push_back(std::move(m));
                q = np;
            } else if (lf2 == 0x1400) { // BCLASS: attr(2) tidx(4) off(num)
                if (body + 6 > end) break;
                NumLeaf n = readNum(body + 6, end);
                if (!n.ok) break;
                q = n.next;
            } else if (lf2 == 0x1401 || lf2 == 0x1402) { // VBCLASS/IVBCLASS: attr(2) tidx(4) vbpoff(num) vbindx(num)
                if (body + 6 > end) break;
                NumLeaf n1 = readNum(body + 6, end);
                if (!n1.ok) break;
                NumLeaf n2 = readNum(n1.next, end);
                if (!n2.ok) break;
                q = n2.next;
            } else if (lf2 == 0x1408) { // INDEX: pad(2) tidx(4)
                if (body + 6 > end) break;
                q = body + 6;
            } else if (lf2 == 0x140A) { // VFUNCOFF: pad(2) tidx(4) off(4)
                if (body + 10 > end) break;
                q = body + 10;
            } else {
                break; // bilinmeyen uye - dur
            }
            // pad baytlari (0xF0+n = n atla)
            while (q < end && *q >= 0xF0) q += (*q - 0xF0);
        }
    }
    // 3. gecis: fieldlist -> sahip struct/union/enum baglantisi
    for (auto& kv : pdb.types) {
        TypeRec& t = kv.second;
        if (!t.fieldlist) continue;
        auto fit = pdb.types.find(t.fieldlist);
        if (fit == pdb.types.end()) continue;
        TypeRec& fl = fit->second;
        if (t.leaf == 0x1507) {
            t.evals = fl.evals;
        } else {
            t.members = fl.members;
        }
    }
    // 4. gecis: isim -> en tam kayit (fwdref cozumu icin)
    for (auto& kv : pdb.types) {
        const TypeRec& t = kv.second;
        if (t.name.empty()) continue;
        if (t.leaf != 0x1504 && t.leaf != 0x1505 && t.leaf != 0x1506 && t.leaf != 0x1507) continue;
        auto it = pdb.completeByName.find(t.name);
        if (it == pdb.completeByName.end()) {
            pdb.completeByName[t.name] = kv.first;
        } else {
            const TypeRec& cur = pdb.types[it->second];
            if (t.members.size() > cur.members.size()) pdb.completeByName[t.name] = kv.first;
        }
    }
    return true;
}

// ------------------------------------------------ sembol taramasi
static bool printableName(const u8* p, size_t max, size_t* lenOut) {
    size_t n = 0;
    while (n < max && p[n]) {
        if (p[n] < 0x20 || p[n] > 0x7E) return false;
        n++;
    }
    if (n == 0 || n >= max) return false;
    *lenOut = n;
    return true;
}

static void scanModuleStream(PdbData& pdb, const std::vector<u8>& buf) {
    size_t n = buf.size();
    if (n < 200) return;
    std::vector<size_t> procStarts;
    std::vector<FuncInfo> found;
    for (size_t R = 0; R + 44 <= n; R++) {
        u16 ln = rd16(buf.data() + R);
        u16 kind = rd16(buf.data() + R + 2);
        if (kind != 0x1110 && kind != 0x110F) continue;
        if (ln < 39 || ln > 800 || R + 2 + ln > n) continue;
        const u8* body = buf.data() + R + 4;
        u32 pEnd = rd32(body + 4);
        u32 codesz = rd32(body + 12);
        u32 off = rd32(body + 28);
        u32 seg = rd16(body + 32);
        u32 pParent = rd32(body);
        if (seg < 1 || seg > 8) continue;
        if (off > 0x4000000 || codesz > 0x200000) continue;
        if (pEnd > n) continue;
        if (pParent != 0 && pParent > n) continue;
        size_t nameLen = 0;
        if (!printableName(body + 35, ln - 36, &nameLen)) continue;
        FuncInfo f;
        f.name.assign((const char*)body + 35, nameLen);
        f.seg = seg; f.off = off; f.size = codesz; f.tidx = rd32(body + 24);
        f.hasType = pdb.type(f.tidx) != nullptr;
        found.push_back(std::move(f));
        procStarts.push_back(R);
        R += 2 + ln - 1;
    }
    if (found.empty()) return;
    for (size_t k = 0; k < procStarts.size(); k++) {
        size_t R = procStarts[k];
        u16 ln = rd16(buf.data() + R);
        size_t q = R + 2 + ln;
        size_t pEnd = rd32(buf.data() + R + 4 + 4);
        if (pEnd > n) pEnd = n;
        std::unordered_set<std::string> seen;
        while (q + 4 <= pEnd) {
            u16 ln2 = rd16(buf.data() + q);
            u16 k2 = rd16(buf.data() + q + 2);
            if (ln2 < 2 || q + 2 + ln2 > n) break;
            const u8* body = buf.data() + q + 4;
            const u8* bend = buf.data() + q + 2 + ln2;
            if (k2 == 0x0006) break; // S_END
            if (k2 == 0x110B && body + 12 <= bend) {
                LocalVar v;
                v.off = rdi32(body);
                v.tidx = rd32(body + 4);
                const u8* np = nullptr;
                v.name = readCStr(body + 8, bend, &np);
                v.isArg = v.off >= 8;
                if (!v.name.empty() && seen.insert(v.name).second)
                    found[k].locals.push_back(std::move(v));
            } else if (k2 == 0x1106 && body + 10 <= bend) {
                LocalVar v;
                v.tidx = rd32(body);
                v.reg = rd16(body + 4);
                const u8* np = nullptr;
                v.name = readCStr(body + 6, bend, &np);
                v.isReg = true;
                if (!v.name.empty() && seen.insert(v.name).second)
                    found[k].locals.push_back(std::move(v));
            } else if (k2 == 0x1111 && body + 14 <= bend) {
                LocalVar v;
                v.off = rdi32(body);
                v.tidx = rd32(body + 4);
                v.reg = rd16(body + 8);
                const u8* np = nullptr;
                v.name = readCStr(body + 10, bend, &np);
                v.isArg = v.off >= 8;
                if (!v.name.empty() && seen.insert(v.name).second)
                    found[k].locals.push_back(std::move(v));
            } else if (k2 == 0x113E && body + 10 <= bend) { // S_LOCAL
                LocalVar v;
                v.tidx = rd32(body);
                const u8* np = nullptr;
                v.name = readCStr(body + 6, bend, &np);
                size_t z = q + 2 + ln2;
                bool got = false;
                int guard = 0;
                while (z + 4 <= pEnd && guard++ < 12) {
                    u16 ln3 = rd16(buf.data() + z);
                    u16 k3 = rd16(buf.data() + z + 2);
                    if (ln3 < 2 || z + 2 + ln3 > n) break;
                    if (k3 == 0x113E || k3 == 0x0006) break;
                    if (k3 == 0x1144 && ln3 >= 6) {
                        v.off = rdi32(buf.data() + z + 4);
                        got = true;
                        break;
                    }
                    z += 2 + ln3;
                }
                if (got) {
                    v.isArg = v.off >= 8;
                    if (!v.name.empty() && seen.insert(v.name).second)
                        found[k].locals.push_back(std::move(v));
                }
            }
            q += 2 + ln2;
        }
    }
    for (auto& f : found) pdb.funcs.push_back(std::move(f));
}

static void scanGlobalRecords(PdbData& pdb, const std::vector<u8>& buf) {
    size_t n = buf.size();
    size_t p = 0;
    while (p + 4 <= n) {
        u16 ln = rd16(buf.data() + p);
        u16 kind = rd16(buf.data() + p + 2);
        if (ln < 2 || p + 2 + ln > n) break;
        const u8* body = buf.data() + p + 4;
        const u8* bend = buf.data() + p + 2 + ln;
        if (kind == 0x110E && body + 10 <= bend) { // PUB32
            u32 off = rd32(body + 4);
            u16 seg = rd16(body + 8);
            const u8* np = nullptr;
            std::string nm = readCStr(body + 10, bend, &np);
            if (seg >= 1 && seg <= 8 && off <= 0x4000000 && nm.size() > 2) {
                u64 key = ((u64)seg << 32) | off;
                pdb.pubMangled[(u32)key] = nm; // gecici: seg cakismasi nadir
                pdb.pubSegOff[key] = nm;
            }
        } else if ((kind == 0x110D || kind == 0x110C) && body + 10 <= bend) {
            GlobalSym g;
            g.tidx = rd32(body);
            g.off = rd32(body + 4);
            g.seg = rd16(body + 8);
            const u8* np = nullptr;
            g.name = readCStr(body + 10, bend, &np);
            if (g.seg >= 1 && g.seg <= 8 && g.off <= 0x4000000 && g.name.size() > 1)
                pdb.globals.push_back(std::move(g));
        } else if (kind == 0x1107 && body + 4 <= bend) { // CONSTANT
            NumLeaf v = readNum(body + 4, bend);
            if (v.ok) {
                std::string nm = readCStr(v.next, bend, nullptr);
                if (nm.size() > 1) pdb.consts.push_back({ nm, v.val });
            }
        }
        p += 2 + ln;
    }
}

static bool parseInfoStream(PdbData& pdb, const std::vector<u8>& info) {
    if (info.size() < 32) return false;
    pdb.sigTime = rd32(info.data() + 4);
    pdb.age = rd32(info.data() + 8);
    char guid[48];
    const u8* g = info.data() + 12;
    snprintf(guid, sizeof guid, "%02X%02X%02X%02X-%02X%02X-%02X%02X-%02X%02X%02X%02X%02X%02X%02X%02X",
             g[3], g[2], g[1], g[0], g[5], g[4], g[7], g[6], g[8], g[9], g[10], g[11], g[12], g[13], g[14], g[15]);
    pdb.guidStr = guid;
    return true;
}

bool PdbData::parse(const std::vector<u8>& raw, std::string& err) {
    if (!msf.load(raw, err)) return false;
    {
        std::vector<u8> info;
        if (msf.streamBytes(1, info)) parseInfoStream(*this, info);
    }
    {
        std::vector<u8> tpi;
        if (!msf.streamBytes(2, tpi)) { err = "TPI stream yok"; return false; }
        if (!parseTpi(*this, tpi, err)) return false;
    }
    for (size_t i = 5; i < msf.streams.size(); i++) {
        std::vector<u8> buf;
        if (!msf.streamBytes(i, buf)) continue;
        if (buf.size() < 200) continue;
        scanModuleStream(*this, buf);
    }
    {
        size_t best = 0; size_t bestCount = 0;
        std::vector<u8> bestBuf;
        for (size_t i = 5; i < msf.streams.size(); i++) {
            std::vector<u8> buf;
            if (!msf.streamBytes(i, buf)) continue;
            if (buf.size() < 4096) continue;
            size_t cnt = 0;
            size_t p = 0;
            while (p + 4 <= buf.size()) {
                u16 ln = rd16(buf.data() + p);
                u16 kind = rd16(buf.data() + p + 2);
                if (ln < 2 || p + 2 + ln > buf.size()) break;
                if (kind == 0x110E && ln >= 12) {
                    const u8* body = buf.data() + p + 4;
                    u16 seg = rd16(body + 8);
                    if (seg >= 1 && seg <= 8) cnt++;
                }
                p += 2 + ln;
            }
            if (cnt > bestCount) { bestCount = cnt; best = i; bestBuf = std::move(buf); }
        }
        if (bestCount > 100) scanGlobalRecords(*this, bestBuf);
    }
    return true;
}

void resolveVAs(PdbData& pdb, const PE* pe) {
    for (auto& f : pdb.funcs) {
        if (pe) f.va = pe->imageBase + pe->secRva((int)f.seg) + f.off;
        else f.va = f.off;
    }
    std::sort(pdb.funcs.begin(), pdb.funcs.end(), [](const FuncInfo& a, const FuncInfo& b) {
        if (a.va != b.va) return a.va < b.va;
        return a.size > b.size;
    });
    for (size_t i = 0; i < pdb.funcs.size(); i++)
        pdb.funcByVa[pdb.funcs[i].va] = (int)i;
    for (auto& g : pdb.globals) {
        g.va = pe ? pe->imageBase + pe->secRva((int)g.seg) + g.off : g.off;
    }
    std::sort(pdb.globals.begin(), pdb.globals.end(), [](const GlobalSym& a, const GlobalSym& b) { return a.va < b.va; });
    for (size_t i = 0; i < pdb.globals.size(); i++)
        pdb.globByVa[pdb.globals[i].va] = (int)i;
    // pub mangled -> func
    if (pe) {
        for (auto& kv : pdb.pubSegOff) {
            u64 key = kv.first;
            u16 seg = (u16)(key >> 32);
            u32 off = (u32)(key & 0xFFFFFFFF);
            u32 va = pe->imageBase + pe->secRva(seg) + off;
            auto it = pdb.funcByVa.find(va);
            if (it != pdb.funcByVa.end() && pdb.funcs[it->second].mangled.empty())
                pdb.funcs[it->second].mangled = kv.second;
            else
                pdb.pubMangled[va] = kv.second;
        }
    } else {
        for (auto& kv : pdb.pubSegOff) {
            u32 off = (u32)(kv.first & 0xFFFFFFFF);
            auto it = pdb.funcByVa.find(off);
            if (it != pdb.funcByVa.end() && pdb.funcs[it->second].mangled.empty())
                pdb.funcs[it->second].mangled = kv.second;
        }
    }
    // prototipler + kisa isimler
    for (auto& f : pdb.funcs) {
        // ?A@B@C@@... -> C::B::A (dekorasyon isim zinciri)
        {
            const std::string& m = !f.mangled.empty() ? f.mangled : f.name;
            if (m.size() > 3 && m[0] == '?' && m[1] == '?') {
                // ozel isimler: ??2 operator new, ??3 operator delete, ??_U/??_V, ??0/??1 kurucu/yikici
                static const std::pair<const char*, const char*> SP[] = {
                    { "2@", "operator new" }, { "3@", "operator delete" },
                    { "_U@", "operator new[]" }, { "_V@", "operator delete[]" },
                };
                bool hit = false;
                for (auto& sp : SP) {
                    if (m.compare(2, strlen(sp.first), sp.first) == 0) {
                        f.shortName = sp.second;
                        hit = true;
                        break;
                    }
                }
                if (!hit && (m[2] == '0' || m[2] == '1')) {
                    std::vector<std::string> ids;
                    size_t i = 3;
                    while (i < m.size()) {
                        size_t j = m.find('@', i);
                        if (j == std::string::npos || j == i) break;
                        ids.push_back(m.substr(i, j - i));
                        i = j + 1;
                    }
                    if (!ids.empty()) {
                        std::string cls;
                        for (size_t k = ids.size(); k-- > 0;) {
                            if (!cls.empty()) cls += "::";
                            cls += ids[k];
                        }
                        f.shortName = cls + "::" + (m[2] == '0' ? ids.back() : "~" + ids.back());
                    }
                }
            }
            if (f.shortName.empty()) {
                const std::string& m = !f.mangled.empty() ? f.mangled : f.name;
                if (!m.empty() && m[0] == '?') {
                    std::vector<std::string> ids;
                    size_t i = 1;
                    while (i < m.size()) {
                        size_t j = m.find('@', i);
                        if (j == std::string::npos) break;
                        if (j == i) break;      // "@@" zincir sonu
                        ids.push_back(m.substr(i, j - i));
                        i = j + 1;
                    }
                    if (!ids.empty()) {
                        std::string r;
                        for (size_t k = ids.size(); k-- > 0;) {
                            if (!r.empty()) r += "::";
                            r += ids[k];
                        }
                        f.shortName = r;
                    }
                }
            }
        }
        const TypeRec* t = pdb.type(f.tidx);
        if (t && (t->leaf == 0x1009 || t->leaf == 0x1008)) {
            f.hasType = true;
            f.isThiscall = (t->leaf == 0x1009);
            if (t->leaf == 0x1009) {
                u32 cls = t->clsType;
                const TypeRec* ct = pdb.type(cls);
                if (ct && ct->leaf == 0x1002) cls = ct->a;
                f.thisClassIdx = cls;
            }
            // konumsal esleme: [ebp+8]=arg0, [ebp+C]=arg1, ...
            const TypeRec* al0 = pdb.type(t->arglist);
            size_t nargs = (al0 && al0->leaf == 0x1201) ? al0->args.size() : 0;
            size_t skip = (t->leaf == 0x1009 && nargs == (size_t)t->nparams + 1) ? 1 : 0;
            f.argNames.resize(nargs > skip ? nargs - skip : 0);
            for (auto& v : f.locals) {
                if (v.isReg || v.off < 8) continue;
                size_t ai = (size_t)((v.off - 8) / 4) + 0;
                if (ai < f.argNames.size() && f.argNames[ai].empty())
                    f.argNames[ai] = v.name;
            }
        }
        f.proto = pdb.fullProto(f);
    }
}

// ------------------------------------------------ string literalleri
std::string strLabel14(const std::string& s) {
    std::string r = "a";
    int k = 0;
    for (char ch : s) {
        if (isalnum((unsigned char)ch)) { r += ch; if (++k >= 14) break; }
    }
    return r;
}

std::vector<StrLit> scanStrings(const PE& pe, size_t maxResults) {
    std::vector<StrLit> out;
    if (!pe.image.size()) return out;
    std::unordered_set<std::string> labels;
    for (auto& s : pe.secs) {
        if (!(s.chars & 0x40)) continue;                    // IMAGE_SCN_CNT_INITIALIZED_DATA
        u32 n = s.rsz < s.vsz ? s.rsz : s.vsz;
        if (n < 5) continue;
        const u8* p = pe.ptr(pe.imageBase + s.va, n);
        if (!p) continue;
        u32 i = 0;
        while (i < n && out.size() < maxResults) {
            if (p[i] < 0x20 || p[i] > 0x7E) { i++; continue; }
            u32 j = i;
            while (j < n && p[j] >= 0x20 && p[j] <= 0x7E) j++;
            u32 len = j - i;
            if (j < n && p[j] == 0 && len >= 4 && len <= 4096) {
                StrLit sl;
                sl.va = pe.imageBase + s.va + i;
                sl.text.assign((const char*)p + i, len > 160 ? 160 : len);
                sl.label = strLabel14(sl.text);
                if (labels.count(sl.label)) {               // ayni etiket: son ekle
                    for (int k = 2;; k++) {
                        char b[24]; snprintf(b, sizeof b, "_%d", k);
                        std::string t = sl.label + b;
                        if (!labels.count(t)) { sl.label = t; break; }
                    }
                }
                labels.insert(sl.label);
                out.push_back(std::move(sl));
                i = j + 1;
            } else {
                i = (j > i) ? j : i + 1;
            }
        }
        if (out.size() >= maxResults) break;
    }
    return out;
}
