#!/bin/bash
# PDBScope v2.0.0 kapsamlı regresyon testi
# Kullanım: tests/regression.sh <pdbscope-ikilisi> <testdata-dizini>
BIN="${1:-./build-native/pdbscope}"
DATA="${2:-../../recovered/tests/data}"
CRAFT="tests/data/crafted"   # bu ağaçtaki üretilmiş test dosyaları
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PASS=0; FAIL=0

t() { # t <ad> <beklenen> <komut...>
    local name="$1"; shift
    local expect="$1"; shift
    local out
    # hedef dosya (ilk dosya argümanı) yoksa atla (paket ortamında dış test verisi olmayabilir)
    for a in "$@"; do
        case "$a" in
            --*) continue ;;
            *) if [ ! -f "$a" ]; then echo "  ATLA $name (dosya yok: $a)"; return; fi ;;
        esac
        break
    done
    out=$("$BIN" "$@" 2>&1)
    if echo "$out" | grep -q "$expect"; then
        PASS=$((PASS+1)); echo "  OK   $name"
    else
        FAIL=$((FAIL+1)); echo "  FAIL $name (beklenen: '$expect')"
        echo "$out" | head -4 | sed 's/^/       /'
    fi
}

echo "== v1 geriye dönük uyumluluk =="
t "PDB sembolleri"        "YAXXZ" semboller "$DATA/big-read.pdb" --tur func --limit 20
t "PDB bilgi"             "PDB üstverisi" bilgi "$DATA/big-read.pdb"
t "PE bölümleri"          ".text" bolum "$DATA/crafted/testlib.dll"
t "Export tablosu"        "add_cdecl" disa "$DATA/crafted/testlib.dll"
t "Import tablosu"        "KERNEL32\|api-ms-win" ice "$DATA/crafted/testlib.dll"
t "MSVC map"              "__ENCDBList" semboller "$DATA/sample-msvc.map"
t "GNU/lld map"           "add_cdecl" semboller "$SCRIPT_DIR/testapp.map"
t "empty.pdb"             "_main" semboller "$DATA/empty.pdb"
t "nearest"               "Sembol" enyakin "$DATA/big-read.pdb" 0x13a2

echo "== v2 PDB özellikleri =="
t "İmza sütunu"           "__cdecl" semboller "$DATA/big-read.pdb" --tur func --imza --limit 10
t "Satır sütunu"          "test.cpp" semboller "$DATA/big-read.pdb" --tur func --satirlar --limit 10
t "satir komutu"          "Satır" satir "$DATA/big-read.pdb" 0x13a2
t "kaynaklar"             "kaynak dosya" kaynaklar "$DATA/big-read.pdb"
t "turler"                "kullanıcı tipi" turler "$DATA/big-read.pdb"
t "turler filtre"         "type_info" turler "$DATA/big-read.pdb" --filtre type_info
t "inline semboller"      "inline" semboller "$DATA/big-read.pdb" --tur inline
t "bilgi derleyici"       "Optimizing Compiler" bilgi "$DATA/big-read.pdb"
t "bilgi FPO"             "FPO çerçeve" bilgi "$DATA/big-read.pdb"
t "bilgi satır özeti"     "Satır bilgisi" bilgi "$DATA/big-read.pdb"
t "JSON çıktısı"          "\"symbols\"" semboller "$DATA/big-read.pdb" --format json --limit 5
t "CSV çıktısı"           "rva,va,seg" semboller "$DATA/big-read.pdb" --format csv --limit 5
t "MAP çıktısı"           "Preferred load address\|Publics by Value" semboller "$DATA/big-read.pdb" --format map --limit 5

echo "== v2 pdbless =="
t "x86 üretilmiş"         "CPythonNetworkStream" pdbless "$CRAFT/metin2sim_x86.exe"
t "x86 export"            "foo" pdbless "$CRAFT/metin2sim_x86.exe"
t "x86 SafeSEH"           "SafeSEH" pdbless "$CRAFT/metin2sim_x86.exe"
t "x86 vftable"            "CPythonPlayer" vftable "$CRAFT/metin2sim_x86.exe"
t "x64 dll pdata"         "Pdata\|pdata" pdbless "$DATA/crafted/testlib.dll"
t "x64 dll export"        "fib" pdbless "$DATA/crafted/testlib.dll"
t "x64 dll COFF"          "COFF\|DllMain" pdbless "$DATA/crafted/testlib.dll"
t "x64 exe gerçek"        "CERTAIN" pdbless "$DATA/sysint/du64.exe"
t "x86 exe gerçek"        "CERTAIN" pdbless "$DATA/sysint/du.exe"
t "pdbless CSV"           "confidence" pdbless "$DATA/crafted/testlib.dll" --format csv
t "pdbless JSON"          "\"functions\"" pdbless "$DATA/crafted/testlib.dll" --format json
t "enyakin pdbless"       "pdbless" enyakin "$DATA/sysint/du.exe" 0x401000
t "dizgiler"              "ascii" dizgiler "$CRAFT/metin2sim_x86.exe"

echo
echo "SONUÇ: $PASS geçti, $FAIL kaldı"
[ $FAIL -eq 0 ]
