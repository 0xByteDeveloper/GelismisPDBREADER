#!/usr/bin/env python3
"""Metin2 benzeri x86 PE üretir: RTTI type_info/COL/vftable, sanal fonksiyonlar,
SafeSEH, export'lar, E8 çağrı grafı, int3 dolguları, MSVC prologları.
PDB'siz analiz motorunu (pdbless) sınamak için.
"""
import struct

def u8(v):  return struct.pack('<B', v & 0xFF)
def u16(v): return struct.pack('<H', v & 0xFFFF)
def u32(v): return struct.pack('<I', v & 0xFFFFFFFF)

IMAGE_BASE = 0x400000
text = bytearray()
rdata = bytearray()
data = bytearray()
reloc = bytearray()

SEC = [
    ('.text',  0x1000, 0x60000020),
    ('.rdata', 0x3000, 0x40000040),
    ('.data',  0x4000, 0xC0000040),
    ('.reloc', 0x5000, 0x42000040),
]
TEXT_VA = 0x1000
RDATA_VA = 0x3000
DATA_VA = 0x4000
RELOC_VA = 0x5000

def rva_t(): return TEXT_VA + len(text)
def rva_r(): return RDATA_VA + len(rdata)
def rva_d(): return DATA_VA + len(data)

funcs = {}

def emit_func(name, prologue=b'\x55\x8B\xEC', body=b'\x90', align=0x10):
    while len(text) % align:
        text.append(0xCC)
    start = rva_t()
    funcs[name] = start
    text.extend(prologue)
    text.extend(body)
    text.append(0xC3)
    text.extend(b'\xCC\xCC\xCC')
    return start

# --- type_info vftable fonksiyonları ---
ti_vt_funcs = [emit_func('__ti_vfunc%d' % i, body=b'\xC3') for i in range(3)]

# --- RTTI sınıfları ---
class RttiClass:
    pass

def make_class(mangled, n_methods):
    cls = RttiClass()
    cls.mangled = mangled
    cls.name = mangled[4:-2].replace('@@', '::')
    cls.methods = []
    for i in range(n_methods):
        pro = b'\x56\x8B\xF1' if i % 2 else b'\x55\x8B\xEC'
        rva = emit_func('%s.m%d' % (cls.name, i), prologue=pro, body=b'\x90' * (4 + i))
        cls.methods.append(rva)
    return cls

classes = [
    make_class('.?AVCPythonNetworkStream@@', 4),
    make_class('.?AVCPythonPlayer@@', 3),
    make_class('.?AVCPythonSafeBox@@', 2),
    make_class('.?AVCEterItemIterator@@', 1),
]

# --- sıradan fonksiyonlar + çağrı grafı ---
# çağrı gövdeleri: E8 hedefleri bilinmediği için iki aşamalı yaz
call_plan = []  # (çağıran_fonksiyon_adı, hedef_rva)

rva_foo = emit_func('foo', body=b'\xB8\x2A\x00\x00\x00')
rva_bar = emit_func('bar', prologue=b'\x8B\xFF\x55\x8B\xEC', body=b'\x81\xEC\x80\x00\x00\x00' + b'\x90' * 8)
rva_baz = emit_func('baz', prologue=b'\x55\x8B\xEC\x83\xEC\x40', body=b'\x90' * 10)
rva_seh = emit_func('with_seh', prologue=b'\x6A\xFF\x68\x00\x30\x00\x40\x64\xA1\x00\x00\x00\x00', body=b'\x90' * 10)
rva_fpo = emit_func('fpo_func', prologue=b'\x83\xEC\x20', body=b'\x90' * 6)
rva_std = emit_func('stdcall_func', prologue=b'\x55\x8B\xEC', body=b'\x90' * 4)
# (C2 ret 8 ekleyelim: gövdenin son C3'ünü C2 08 00 yap — basitlik: bırak)
rva_entry = emit_func('WinMainCRTStartup', prologue=b'\x55\x8B\xEC\x6A\x00', body=b'\x90' * 6)

# çağrı fonksiyonu: gövde E8'lerle dolacak
call_body_len = 5 * 6
rva_calls = emit_func('direct_calls', prologue=b'\x55\x8B\xEC',
                      body=b'\x90' * call_body_len)
# gövdeyi geri doldur
body_start = rva_calls - TEXT_VA + 3  # prolog 3 bayt
targets = [rva_foo, rva_bar, rva_baz, rva_seh, rva_fpo, rva_std]
off = 0
for t in targets:
    e8_rva = TEXT_VA + body_start + off
    rel = t - (e8_rva + 5)
    text[body_start + off:body_start + off + 5] = b'\xE8' + struct.pack('<i', rel)
    off += 5

# koşullu dal (JCC hedefi fonksiyon ortası değil — fonksiyon başına dal)
# with_seh içinden baz'a bir test dalı ekle
rva_test = emit_func('test_branchy', prologue=b'\x55\x8B\xEC',
                     body=b'\x90' * (2 + 6 + 8))
tb_body = rva_test - TEXT_VA + 3
# 74 xx (je +2), 0F 84 xx xx xx xx (je near baz)
text[tb_body:tb_body+2] = b'\x74\x06'
near = rva_baz - (TEXT_VA + tb_body + 8)
text[tb_body+2:tb_body+8] = b'\x0F\x84' + struct.pack('<i', near)

# --- .rdata ---------------------------------------------------------------
def rdata_align():
    while len(rdata) % 4:
        rdata.append(0)

ti_vftable_rva = None
rdata_align()
ti_vftable_rva = rva_r()
for f in ti_vt_funcs:
    rdata.extend(u32(IMAGE_BASE + f))

# type_info'nun kendi TD'si
rdata_align()
rdata.extend(u32(IMAGE_BASE + ti_vftable_rva))
rdata.extend(u32(0))
rdata.extend(b'.?AVtype_info@@\x00')

reloc_locs = [ti_vftable_rva + 4 * i for i in range(len(ti_vt_funcs))]

for cls in classes:
    rdata_align()
    cls.td_rva = rva_r()
    rdata.extend(u32(IMAGE_BASE + ti_vftable_rva))
    rdata.extend(u32(0))
    rdata.extend(cls.mangled.encode() + b'\x00')
    # COL x86: {sig=0, off=0, pTD(VA), pCHD(VA), self}
    rdata_align()
    cls.col_rva = rva_r()
    rdata.extend(u32(0))
    rdata.extend(u32(0))
    rdata.extend(u32(IMAGE_BASE + cls.td_rva))
    rdata.extend(u32(IMAGE_BASE + RDATA_VA))  # sahte CHD
    rdata.extend(u32(0))
    # vftable: [pCOL][vf...]
    rdata_align()
    cls.vt_rva = rva_r()
    rdata.extend(u32(IMAGE_BASE + cls.col_rva))
    reloc_locs.append(cls.vt_rva)
    for m in cls.methods:
        rdata.extend(u32(IMAGE_BASE + m))
        reloc_locs.append(cls.vt_rva + 4 + 4 * cls.methods.index(m))

# SafeSEH: yük yapılandırması + işleyici tablosu
rdata_align()
lc_rva = rva_r()
lc = bytearray(0x78)
struct.pack_into('<I', lc, 0, len(lc))
seh_handlers = [rva_seh]
struct.pack_into('<I', lc, 0x44, IMAGE_BASE + (rva_r() + len(lc) + 3) & ~3)
struct.pack_into('<I', lc, 0x48, len(seh_handlers))
rdata.extend(lc)
rdata_align()
seh_table_rva = rva_r()
for h in seh_handlers:
    rdata.extend(u32(IMAGE_BASE + h))
    reloc_locs.append(seh_table_rva + 4 * seh_handlers.index(h))

# export tablosu
rdata_align()
exp_dir_rva = rva_r()
export_names = [('foo', rva_foo), ('bar', rva_bar), ('baz', rva_baz)]
n = len(export_names)

rdata.extend(b'\x00' * 40)             # başlık (geri doldurulacak)
eat_rva = rva_r()
for _, r in export_names:
    rdata.extend(u32(r))  # EAT (PE şartnamesi: RVA)
enp_rva = rva_r()
enp_pos = len(rdata)
for i in range(n):
    rdata.extend(u32(0))               # ENP yer tutucular
eot_rva = rva_r()
for i in range(n):
    rdata.extend(u16(i))               # EOT (0 tabanli indeks)
name_rvas = []
for nm, _ in export_names:
    name_rvas.append(rva_r())
    rdata.extend(nm.encode() + b'\x00')
dllname_rva = rva_r()
rdata.extend(b'metin2sim.exe\x00')

# ENP'yi geri doldur
for i in range(n):
    struct.pack_into('<I', rdata, enp_pos + 4 * i, name_rvas[i])
# başlığı doldur (IMAGE_EXPORT_DIRECTORY düzeni):
#   +12 Name, +16 Base, +20 NumberOfFunctions, +24 NumberOfNames,
#   +28 AddressOfFunctions, +32 AddressOfNames, +36 AddressOfNameOrdinals
h = exp_dir_rva - RDATA_VA
struct.pack_into('<I', rdata, h + 12, dllname_rva)
struct.pack_into('<I', rdata, h + 16, 1)          # Base (ordinal tabanı)
struct.pack_into('<I', rdata, h + 20, n)          # NumberOfFunctions
struct.pack_into('<I', rdata, h + 24, n)          # NumberOfNames
struct.pack_into('<I', rdata, h + 28, eat_rva)    # EAT
struct.pack_into('<I', rdata, h + 32, enp_rva)    # ENP
struct.pack_into('<I', rdata, h + 36, eot_rva)    # EOT
exp_dir_size = (dllname_rva - exp_dir_rva) + 14

# --- .data: relocation hedefli kod işaretçileri ---
g1 = rva_d()
data.extend(u32(IMAGE_BASE + rva_calls))
g2 = rva_d()
data.extend(u32(IMAGE_BASE + funcs['WinMainCRTStartup']))
reloc_locs += [g1, g2]

# --- .reloc ---
reloc_locs.sort()
pages = {}
for loc in reloc_locs:
    pages.setdefault(loc & ~0xFFF, []).append((loc & 0xFFF, 0x3000))
for page, entries in sorted(pages.items()):
    ent = b''.join(u16(t | o) for o, t in entries)
    while len(ent) % 4:
        ent += u16(0)
    reloc.extend(u32(page))
    reloc.extend(u32(8 + len(ent)))
    reloc.extend(ent)

# --- PE başlıkları ---
IMAGE_SIZE = 0x400
image = bytearray(IMAGE_SIZE)
image[0:2] = b'MZ'
struct.pack_into('<I', image, 0x3C, 0x80)
image[0x80:0x84] = b'PE\x00\x00'
fh = 0x84
struct.pack_into('<H', image, fh + 0, 0x14C)
struct.pack_into('<H', image, fh + 2, len(SEC))
struct.pack_into('<I', image, fh + 4, 0x66C6F6F)
struct.pack_into('<H', image, fh + 16, 0xE0)
struct.pack_into('<H', image, fh + 18, 0x0102)
opt = fh + 20
struct.pack_into('<H', image, opt + 0, 0x10B)
struct.pack_into('<I', image, opt + 16, rva_entry)
struct.pack_into('<I', image, opt + 20, TEXT_VA)
struct.pack_into('<I', image, opt + 28, IMAGE_BASE)
struct.pack_into('<I', image, opt + 56, 0x1000)
struct.pack_into('<I', image, opt + 60, 0x200)
struct.pack_into('<H', image, opt + 68, 3)

blobs = {'.text': text, '.rdata': rdata, '.data': data, '.reloc': reloc}
raw_ptrs = {'.text': 0x400, '.rdata': None, '.data': None, '.reloc': None}
# ham yerleşimi hesapla
cur = 0x400
raw_sizes = {}
for nm, va, ch in SEC:
    size = 0x200 * ((len(blobs[nm]) + 0x1FF) // 0x200)
    raw_sizes[nm] = max(size, 0x200)
    raw_ptrs[nm] = cur
    cur += raw_sizes[nm]

# bölümleri tabloya yaz
st = opt + 0xE0
for i, (nm, va, ch) in enumerate(SEC):
    e = st + i * 40
    image[e:e+8] = nm.encode().ljust(8, b'\x00')
    vsize = (len(blobs[nm]) + 0xFFF) & ~0xFFF
    struct.pack_into('<I', image, e + 8, max(vsize, 4))
    struct.pack_into('<I', image, e + 12, va)
    struct.pack_into('<I', image, e + 16, raw_sizes[nm])
    struct.pack_into('<I', image, e + 20, raw_ptrs[nm])
    struct.pack_into('<I', image, e + 36, ch)

soi = RELOC_VA + raw_sizes['.reloc']
struct.pack_into('<I', image, opt + 56, soi)
struct.pack_into('<I', image, opt + 92, soi)
struct.pack_into('<I', image, opt + 96, IMAGE_SIZE)

def set_dir(idx, rva, size):
    struct.pack_into('<I', image, opt + 96 + idx * 8, rva)
    struct.pack_into('<I', image, opt + 96 + idx * 8 + 4, size)

set_dir(0, exp_dir_rva, exp_dir_size)
set_dir(5, RELOC_VA, len(reloc))
set_dir(10, lc_rva, len(lc))

out = bytearray(image)
for nm, va, ch in SEC:
    while len(out) < raw_ptrs[nm]:
        out.append(0)
    out.extend(blobs[nm])

path = '/home/z/my-project/dev/PDBScope/tests/data/crafted/metin2sim_x86.exe'
with open(path, 'wb') as f:
    f.write(bytes(out))

print("uretildi:", path, "(%d bayt)" % len(out))
print("beklenen fonksiyonlar (%d):" % len(funcs))
for name, rva in sorted(funcs.items(), key=lambda kv: kv[1]):
    print("  0x%08x %s" % (rva, name))
print("beklenen vftable'lar:")
for cls in classes:
    print("  0x%08x %s (%d vf)" % (cls.vt_rva, cls.name, len(cls.methods)))
print("export'lar: foo=0x%x bar=0x%x baz=0x%x" % (rva_foo, rva_bar, rva_baz))
