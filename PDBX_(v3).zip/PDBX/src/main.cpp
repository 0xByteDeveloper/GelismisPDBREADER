// PDBX - konsol PDB okuyucu + IDA tarzi disassembler
// Kullanim: pdbx_win32.exe <dosya.pdb> [--exe <dosya.exe>] <komut> [arguman]
#include "pdbx.h"
#include "disasm.h"
#include <cctype>

static void printHelp() {
    printf(
        "PDBX v2.0 - PDB okuyucu + IDA tarzi disassembler + Web GUI (Metin2 PVP icin)\n\n"
        "Kullanim:\n"
        "  pdbx_win32.exe <dosya.pdb> [--exe <dosya.exe>] [--bytes] <komut> [arguman]\n\n"
        "Komutlar:\n"
        "  info               PDB/exe ozet bilgisi (GUID, sayim)\n"
        "  funcs [filtre]     fonksiyon listesi (adres, boyut, isim)\n"
        "  func <isim>        fonksiyon detayi (prototip, arglar, local degiskenler)\n"
        "  structs [filtre]   struct/class/union listesi\n"
        "  struct <isim>      struct uyeleri + offsetleri (kPacketAtk tipi gibi)\n"
        "  globals [filtre]   global degisken listesi\n"
        "  strings [filtre]   exe icindeki string literalleri (aSendBattle... )\n"
        "  xrefs <isim>       fonksiyonu cagiran yerler (CODE XREF)\n"
        "  find <metin>       her yerde ara\n"
        "  disasm <isim|addr> IDA tarzi disassembly (ebp+arg, this->uye, isimler, XREF)\n"
        "  dump <dosya>       her seyi metin dosyasina dok (funcs+structs+globals)\n"
        "  serve [port]       WEB GUI baslat (tarayici: http://127.0.0.1:PORT)\n"
        "  help               bu yardim\n\n"
        "Notlar:\n"
        "  --bytes  disasm satirlarinda makine kodu baytlarini da gosterir\n"
        "  serve varsayilan port: 27042  (ornek: serve 8080)\n\n"
        "Ornek:\n"
        "  pdbx_win32.exe metin2client.pdb --exe metin2client.exe disasm CPythonNetworkStream::SendAttackPacket\n"
        "  pdbx_win32.exe metin2client.pdb --exe metin2client.exe serve\n");
}

static std::string vaStr(u32 va, const PE* pe) {
    static char bufs[8][16];
    static int rot = 0;
    char* b = bufs[rot++ & 7];
    if (!pe) { snprintf(b, 16, "seg:off"); return std::string(b); }
    snprintf(b, 16, "%08X", va);
    return std::string(b);
}

static std::string pad(const std::string& s, size_t w) {
    if (s.size() >= w) return s;
    return s + std::string(w - s.size(), ' ');
}

int main(int argc, char** argv) {
    if (argc < 2) { printHelp(); return 1; }
    std::string pdbPath, exePath, cmd, arg1, arg2;
    pdbPath = argv[1];
    std::vector<std::string> rest;
    for (int i = 2; i < argc; i++) {
        std::string a = argv[i];
        if (a == "--exe" && i + 1 < argc) { exePath = argv[++i]; continue; }
        if (a == "--bytes") { disasm::setShowBytes(true); continue; }
        rest.push_back(a);
    }
    if (!rest.empty()) { cmd = rest[0]; if (rest.size() > 1) arg1 = rest[1]; if (rest.size() > 2) arg2 = rest[2]; }
    if (cmd.empty()) cmd = "help";

    std::string err;
    std::vector<u8> pdbRaw;
    if (!readFile(pdbPath.c_str(), pdbRaw, err)) { printf("HATA: %s\n", err.c_str()); return 2; }

    PE pe; bool havePe = false;
    if (!exePath.empty()) {
        std::vector<u8> exeRaw;
        if (!readFile(exePath.c_str(), exeRaw, err)) { printf("HATA: %s\n", err.c_str()); return 2; }
        if (!pe.load(exeRaw, err)) { printf("HATA: %s\n", err.c_str()); return 2; }
        havePe = true;
    }

    PdbData pdb;
    printf("PDB okunuyor...\n");
    if (!pdb.parse(pdbRaw, err)) { printf("HATA: %s\n", err.c_str()); return 3; }
    resolveVAs(pdb, havePe ? &pe : nullptr);
    printf("OK: %u fonksiyon, %u tip, %u global, %u public\n\n",
           (unsigned)pdb.funcs.size(), (unsigned)pdb.types.size(), (unsigned)pdb.globals.size(), (unsigned)pdb.pubMangled.size());

    std::string lc = lowerDup(cmd);

    if (lc == "help" || lc == "?") { printHelp(); return 0; }

    if (lc == "info") {
        printf("PDB   : %s\n", pdbPath.c_str());
        printf("GUID  : %s  age=%u\n", pdb.guidStr.c_str(), pdb.age);
        printf("Exe   : %s  ImageBase=%08X\n", exePath.empty() ? "(verilmedi)" : exePath.c_str(), pe.imageBase);
        if (havePe) {
            printf("Bolumler:\n");
            for (auto& s : pe.secs)
                printf("  %-8s VA=%06X VSz=%06X Raw=%06X\n", s.name.c_str(), s.va, s.vsz, s.raw);
        }
        printf("Stream: %u adet\n", (unsigned)pdb.msf.streams.size());
        printf("TPI   : %u tip (0x%X..0x%X)\n", pdb.tpiEnd - pdb.tpiBegin, pdb.tpiBegin, pdb.tpiEnd);
        printf("Fonksiyon : %u\n", (unsigned)pdb.funcs.size());
        printf("Global    : %u\n", (unsigned)pdb.globals.size());
        printf("Public    : %u\n", (unsigned)pdb.pubMangled.size());
        printf("Sabit     : %u\n", (unsigned)pdb.consts.size());
        return 0;
    }

    if (lc == "funcs") {
        printf("%-4s %-10s %-8s %s\n", "#", "adres", "boyut", "isim");
        u32 n = 0;
        for (auto& f : pdb.funcs) {
            if (!arg1.empty()) {
                std::string a = lowerDup(arg1);
                if (lowerDup(f.name).find(a) == std::string::npos &&
                    lowerDup(f.shortName).find(a) == std::string::npos &&
                    lowerDup(f.mangled).find(a) == std::string::npos) continue;
            }
            std::string nm = !f.shortName.empty() ? f.shortName : (!f.mangled.empty() ? f.mangled : f.name);
            printf("%-4u %-10s %-8u %s\n", n++, vaStr(f.va, havePe ? &pe : nullptr).c_str(), f.size, nm.c_str());
        }
        printf("toplam: %u fonksiyon\n", n);
        return 0;
    }

    if (lc == "func" || lc == "function") {
        if (arg1.empty()) { printf("Kullanim: func <isim-parcasi>\n"); return 1; }
        int cnt = 0;
        const FuncInfo* f = pdb.findFuncByNameSub(arg1, &cnt);
        if (!f) { printf("fonksiyon bulunamadi: %s\n", arg1.c_str()); return 1; }
        if (cnt > 1) printf("(%d eslesme, ilk gosteriliyor)\n", cnt);
        printf("adres : %s  boyut: %u\n", vaStr(f->va, havePe ? &pe : nullptr).c_str(), f->size);
        printf("prototip: %s\n", f->proto.c_str());
        printf("\narg/local degiskenler:\n");
        std::vector<LocalVar> vs = f->locals;
        std::sort(vs.begin(), vs.end(), [](const LocalVar& a, const LocalVar& b) {
            if (a.isReg != b.isReg) return !a.isReg;
            return a.off < b.off;
        });
        for (auto& v : vs) {
            if (v.isReg) {
                static const char* RN[8] = { "eax", "ecx", "edx", "ebx", "esp", "ebp", "esi", "edi" };
                const char* rn = (v.reg >= 17 && v.reg <= 24) ? RN[v.reg - 17] : "?";
                printf("  %-22s = register (%s) %s\n", v.name.c_str(), rn, pdb.typeName(v.tidx).c_str());
            } else {
                char b[64];
                if (v.off >= 0) snprintf(b, sizeof b, "[ebp+%Xh]", v.off);
                else snprintf(b, sizeof b, "[ebp-%Xh]", -v.off);
                printf("  %-22s %s\n", b, pdb.typeName(v.tidx).c_str());
            }
        }
        return 0;
    }

    if (lc == "structs") {
        printf("%-4s %-8s %-8s %s\n", "#", "boyut", "uye", "isim");
        u32 n = 0;
        for (auto& kv : pdb.types) {
            const TypeRec& t = kv.second;
            if (t.leaf != 0x1504 && t.leaf != 0x1505 && t.leaf != 0x1506 && t.leaf != 0x1507) continue;
            if (t.name.empty()) continue;
            bool bad = false;
            for (unsigned char c : t.name) if (c < 0x20) { bad = true; break; }
            if (bad) continue;
            if (!arg1.empty() && lowerDup(t.name).find(lowerDup(arg1)) == std::string::npos) continue;
            printf("%-4u %-8llu %-8zu %s%s\n", n++, (unsigned long long)t.size, t.members.size() + t.evals.size(), t.name.c_str(),
                   t.leaf == 0x1506 ? " (union)" : t.leaf == 0x1507 ? " (enum)" : "");
        }
        printf("toplam: %u\n", n);
        return 0;
    }

    if (lc == "struct" || lc == "enum") {
        if (arg1.empty()) { printf("Kullanim: struct <isim>\n"); return 1; }
        std::string want = lowerDup(arg1);
        const TypeRec* found = nullptr;
        const TypeRec* partial = nullptr;
        int pcnt = 0;
        for (auto& kv : pdb.types) {
            const TypeRec& t = kv.second;
            if (t.leaf != 0x1504 && t.leaf != 0x1505 && t.leaf != 0x1506 && t.leaf != 0x1507) continue;
            if (lowerDup(t.name) == want) {
                // tam kaydi tercih et (fwdref degil)
                if (!found || (t.members.size() > found->members.size())) found = &t;
                continue;
            }
            if (!partial && lowerDup(t.name).find(want) != std::string::npos) partial = &t;
            else if (partial && lowerDup(t.name).find(want) != std::string::npos) pcnt++;
        }
        if (!found) {
            found = partial;
            if (pcnt) printf("(%d eslesme, ilk gosteriliyor)\n", pcnt + 1);
        }
        if (!found) { printf("struct bulunamadi: %s\n", arg1.c_str()); return 1; }
        const TypeRec& t = *found;
        printf("%s%s  boyut: %llu bayt\n", t.name.c_str(),
               t.leaf == 0x1506 ? " (union)" : t.leaf == 0x1507 ? " (enum)" : "",
               (unsigned long long)t.size);
        if (t.leaf == 0x1507) {
            for (auto& ev : t.evals)
                printf("  %-4lld %s\n", (long long)ev.val, ev.name.c_str());
            return 0;
        }
        for (auto& m : t.members) {
            if (m.attr == 0xFFFF) { // nesttype / ic enum
                printf("  [ic tip] %s : %s\n", m.name.c_str(), pdb.typeName(m.tidx).c_str());
                continue;
            }
            if (m.attr == 0xFFFE) {
                printf("  +0x??  %s\n", m.name.c_str());
                continue;
            }
            if (m.attr == 0xFFFD) { // static uye
                printf("  [static] %-24s %s\n", m.name.c_str(), pdb.typeName(m.tidx).c_str());
                continue;
 }
            std::string tn = pdb.typeName(m.tidx);
            const TypeRec* mt = pdb.type(m.tidx);
            if (mt && (mt->leaf == 0x1504 || mt->leaf == 0x1505 || mt->leaf == 0x1506))
                tn += " {struct}";
            printf("  +0x%-4llX %-28s %s\n", (unsigned long long)m.off, m.name.c_str(), tn.c_str());
        }
        return 0;
    }

    if (lc == "globals") {
        printf("%-10s %-24s %s\n", "adres", "tip", "isim");
        u32 n = 0;
        for (auto& g : pdb.globals) {
            if (!arg1.empty() && lowerDup(g.name).find(lowerDup(arg1)) == std::string::npos) continue;
            printf("%-10s %-24s %s\n", vaStr(g.va, havePe ? &pe : nullptr).c_str(),
                   pdb.typeName(g.tidx).substr(0, 24).c_str(), g.name.c_str());
            if (++n >= 4000) break;
        }
        printf("toplam: %u\n", n);
        return 0;
    }

    if (lc == "find") {
        if (arg1.empty()) { printf("Kullanim: find <metin>\n"); return 1; }
        std::string w = lowerDup(arg1);
        printf("== fonksiyonlar ==\n");
        u32 n = 0;
        for (auto& f : pdb.funcs) {
            std::string dn = !f.shortName.empty() ? f.shortName : f.name;
            if (lowerDup(dn).find(w) != std::string::npos) {
                printf("  %-10s %s\n", vaStr(f.va, havePe ? &pe : nullptr).c_str(), dn.c_str());
                if (++n >= 100) { printf("  ...\n"); break; }
            }
        }
        printf("== structlar ==\n");
        n = 0;
        for (auto& kv : pdb.types) {
            const TypeRec& t = kv.second;
            if ((t.leaf == 0x1504 || t.leaf == 0x1505 || t.leaf == 0x1506 || t.leaf == 0x1507) && !t.name.empty() &&
                lowerDup(t.name).find(w) != std::string::npos) {
                printf("  %-8llu %s\n", (unsigned long long)t.size, t.name.c_str());
                if (++n >= 100) { printf("  ...\n"); break; }
            }
        }
        printf("== globaller ==\n");
        n = 0;
        for (auto& g : pdb.globals) {
            if (lowerDup(g.name).find(w) != std::string::npos) {
                printf("  %-10s %s\n", vaStr(g.va, havePe ? &pe : nullptr).c_str(), g.name.c_str());
                if (++n >= 100) { printf("  ...\n"); break; }
            }
        }
        return 0;
    }

    if (lc == "disasm" || lc == "d") {
        if (arg1.empty()) { printf("Kullanim: disasm <fonksiyon-ismi|0xAdres>\n"); return 1; }
        const FuncInfo* f = nullptr;
        u64 a = 0;
        if (arg1.size() > 2 && (arg1[0] == '0') && (arg1[1] == 'x' || arg1[1] == 'X')) {
            a = strtoull(arg1.c_str() + 2, nullptr, 16);
            if (!havePe) a += 0; // adres direkt VA
        } else if (arg1.find_first_not_of("0123456789abcdefABCDEF") == std::string::npos && arg1.size() >= 6) {
            a = strtoull(arg1.c_str(), nullptr, 16);
        }
        u32 va32 = (u32)a;
        if (va32) {
            auto it = pdb.funcByVa.find(va32);
            if (it != pdb.funcByVa.end()) f = &pdb.funcs[it->second];
        }
        if (!f && !arg1.empty()) {
            int cnt = 0;
            f = pdb.findFuncByNameSub(arg1, &cnt);
            if (f && cnt > 1) printf("(%d eslesme, ilk gosteriliyor)\n", cnt);
        }
        if (!f) { printf("fonksiyon bulunamadi: %s\n", arg1.c_str()); return 1; }
        if (!havePe) { printf("HATA: disassembly icin --exe gerekli\n"); return 1; }
        fputs(disasm::disassemble(pdb, &pe, *f).c_str(), stdout);
        return 0;
    }

    if (lc == "strings") {
        if (!havePe) { printf("HATA: strings icin --exe gerekli\n"); return 1; }
        auto list = scanStrings(pe, 100000);
        printf("%-10s %-16s %s\n", "adres", "etiket", "icerik");
        u32 n = 0;
        for (auto& s : list) {
            if (!arg1.empty() &&
                lowerDup(s.label).find(lowerDup(arg1)) == std::string::npos &&
                lowerDup(s.text).find(lowerDup(arg1)) == std::string::npos) continue;
            printf("%-10s %-16s \"%.120s\"\n", vaStr(s.va, &pe).c_str(), s.label.c_str(), s.text.c_str());
            if (++n >= 2000) { printf("... (cok fazla, filtre ver: strings <metin>)\n"); break; }
        }
        printf("toplam: %u string\n", n);
        return 0;
    }

    if (lc == "xrefs") {
        if (!havePe) { printf("HATA: xrefs icin --exe gerekli\n"); return 1; }
        if (arg1.empty()) { printf("Kullanim: xrefs <fonksiyon-ismi>\n"); return 1; }
        int cnt = 0;
        const FuncInfo* f = pdb.findFuncByNameSub(arg1, &cnt);
        if (!f) { printf("fonksiyon bulunamadi: %s\n", arg1.c_str()); return 1; }
        printf("hedef: %s  (%s)\n", disasm::funcLabel(*f).c_str(), vaStr(f->va, &pe).c_str());
        u32 n = 0;
        for (auto& s : disasm::callSites(pdb, pe)) {
            if (s.target != f->va) continue;
            const FuncInfo* cf = disasm::findFuncContaining(pdb, s.site);
            char off[64] = "";
            if (cf) snprintf(off, sizeof off, "%s+%X", disasm::funcLabel(*cf).c_str(), s.site - cf->va);
            printf("  %-10s %c  %s\n", vaStr(s.site, &pe).c_str(), s.kind, off);
            n++;
        }
        printf("toplam: %u xref\n", n);
        return 0;
    }

    if (lc == "serve" || lc == "web") {
        u16 port = 27042;
        if (!arg1.empty()) {
            int p = atoi(arg1.c_str());
            if (p > 0 && p < 65536) port = (u16)p;
        }
        if (!havePe) printf("UYARI: --exe verilmedi; disassembly/string ozellikleri kapali olur\n");
        return serveWeb(pdb, havePe ? &pe : nullptr, pdbPath, exePath, port);
    }

    if (lc == "dump") {
        std::string outPath = arg1.empty() ? "pdbx_dump.txt" : arg1;
        FILE* fp = fopen(outPath.c_str(), "w");
        if (!fp) { printf("dosya acilamadi: %s\n", outPath.c_str()); return 1; }
        fprintf(fp, "PDBX dump - %s\n", pdbPath.c_str());
        fprintf(fp, "GUID: %s age=%u\n\n", pdb.guidStr.c_str(), pdb.age);
        fprintf(fp, "==================== FONKSIYONLAR (%u) ====================\n\n", (unsigned)pdb.funcs.size());
        for (auto& f : pdb.funcs) {
            fprintf(fp, "%s  boyut=%u  %s\n", vaStr(f.va, havePe ? &pe : nullptr).c_str(), f.size, f.proto.c_str());
        }
        fprintf(fp, "\n==================== STRUCTLAR ====================\n\n");
        for (auto& kv : pdb.types) {
            const TypeRec& t = kv.second;
            if ((t.leaf != 0x1504 && t.leaf != 0x1505 && t.leaf != 0x1506 && t.leaf != 0x1507) || t.name.empty()) continue;
            fprintf(fp, "%s%s  boyut=%llu\n", t.name.c_str(), t.leaf == 0x1506 ? " (union)" : "", (unsigned long long)t.size);
            for (auto& m : t.members) {
                if (m.attr == 0xFFFF || m.attr == 0xFFFE) {
                    fprintf(fp, "  [ic tip] %s : %s\n", m.name.c_str(), pdb.typeName(m.tidx).c_str());
                    continue;
                }
                if (m.attr == 0xFFFD) {
                    fprintf(fp, "  [static] %s : %s\n", m.name.c_str(), pdb.typeName(m.tidx).c_str());
                    continue;
                }
                fprintf(fp, "  +0x%-4llX %-28s %s\n", (unsigned long long)m.off, m.name.c_str(), pdb.typeName(m.tidx).c_str());
            }
            for (auto& ev : t.evals)
                fprintf(fp, "  = %-4lld %s\n", (long long)ev.val, ev.name.c_str());
            fprintf(fp, "\n");
        }
        fprintf(fp, "==================== GLOBALLER ====================\n\n");
        for (auto& g : pdb.globals)
            fprintf(fp, "%s  %s  %s\n", vaStr(g.va, havePe ? &pe : nullptr).c_str(), pdb.typeName(g.tidx).c_str(), g.name.c_str());
        fclose(fp);
        printf("dump yazildi: %s\n", outPath.c_str());
        return 0;
    }

    printf("bilinmeyen komut: %s\n", cmd.c_str());
    printHelp();
    return 1;
}
