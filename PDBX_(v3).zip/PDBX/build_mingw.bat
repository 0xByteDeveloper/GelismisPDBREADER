; mingw-w64 ile derleme (i686 = 32-bit Windows)
@echo off
cd /d "%~dp0"
i686-w64-mingw32-g++ -O2 -std=c++17 -static -o pdbx_win32.exe src/*.cpp -lws2_32
x86_64-w64-mingw32-g++ -O2 -std=c++17 -static -o pdbx_x64.exe src/*.cpp -lws2_32
echo OK: pdbx_win32.exe + pdbx_x64.exe
